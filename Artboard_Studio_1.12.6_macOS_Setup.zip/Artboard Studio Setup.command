#!/bin/bash
set -u

SELF_DIR="$(cd "$(dirname "$0")" && pwd)"
MODE="install"
for arg in "$@"; do
  if [ "$arg" = "--uninstall" ]; then MODE="uninstall"; fi
done

if [ -d "$SELF_DIR/../Resources/payload" ]; then
  RES_DIR="$(cd "$SELF_DIR/../Resources" && pwd)"
elif [ -d "$SELF_DIR/payload" ]; then
  RES_DIR="$SELF_DIR"
elif [ -d "$SELF_DIR/Artboard Studio Setup.app/Contents/Resources/payload" ]; then
  RES_DIR="$SELF_DIR/Artboard Studio Setup.app/Contents/Resources"
else
  RES_DIR="$SELF_DIR"
fi

export ABS_RES_DIR="$RES_DIR"
export ABS_MODE="$MODE"
export ABS_VERSION="1.12.6"

# Remove quarantine silently on local payload if present
xattr -dr com.apple.quarantine "$RES_DIR" >/dev/null 2>&1 || true

PORT_FILE="/tmp/abs_setup_port_$$.txt"
QUIT_FILE="/tmp/abs_setup_quit_$$.txt"
rm -f "$PORT_FILE" "$QUIT_FILE"
export ABS_QUIT_FILE="$QUIT_FILE"

/usr/bin/perl -e '
use strict;
use warnings;
use IO::Socket::INET;

my $res_dir = $ENV{"ABS_RES_DIR"} || ".";
my $mode    = $ENV{"ABS_MODE"} || "install";
my $ver     = $ENV{"ABS_VERSION"} || "1.12.6";
my $home    = $ENV{"HOME"} || "/tmp";
my $cep_dir = "$home/Library/Application Support/Adobe/CEP/extensions";
my $app_sup = "$home/Library/Application Support/Artboard Studio";
my $ui_file = "$res_dir/setup_ui.html";
my $pay_dir = "$res_dir/payload";

my $srv = IO::Socket::INET->new(
    LocalAddr => "127.0.0.1",
    LocalPort => 0,
    Proto     => "tcp",
    Listen    => 16,
    ReuseAddr => 1
) or die "Cannot bind loopback socket: $!";

my $port = $srv->sockport();
open(my $pf, ">", $ARGV[0]) and do { print $pf $port; close($pf); };

sub read_file {
    my ($path) = @_;
    open(my $fh, "<:raw", $path) or return "";
    local $/;
    my $data = <$fh>;
    close($fh);
    return $data;
}

sub write_file {
    my ($path, $data) = @_;
    open(my $fh, ">:raw", $path) or return 0;
    print $fh $data;
    close($fh);
    return 1;
}

sub send_resp {
    my ($c, $status, $ctype, $body) = @_;
    my $len = length($body);
    print $c "HTTP/1.1 $status\r\nContent-Type: $ctype\r\nContent-Length: $len\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n$body";
}

sub json_escape {
    my ($s) = @_;
    $s =~ s/\\/\\\\/g;
    $s =~ s/"/\\"/g;
    $s =~ s/\r//g;
    $s =~ s/\n/\\n/g;
    return $s;
}

sub find_ai_app {
    my ($y) = @_;
    for my $p (
        "/Applications/Adobe Illustrator $y/Adobe Illustrator.app",
        "/Applications/Adobe Illustrator $y/Adobe Illustrator $y.app",
        "/Applications/Adobe Illustrator $y",
        "/Applications/Adobe Illustrator CC $y/Adobe Illustrator.app"
    ) {
        return $p if -e $p;
    }
    return "";
}

sub get_info_json {
    my @det;
    my @inst;
    my $inst_ver = "";
    for my $y (2024, 2025, 2026, 2027) {
        push @det, $y if find_ai_app($y) ne "";
        my $ex = "$cep_dir/com.rafat.artboardstudio.ai$y";
        if (-d $ex) {
            push @inst, $y;
            if ($inst_ver eq "" && -f "$ex/version.js") {
                my $vtxt = read_file("$ex/version.js");
                if ($vtxt =~ /ARTBOARD_STUDIO_VERSION\s*=\s*\x27([^\x27]+)\x27/) {
                    $inst_ver = $1;
                }
            }
        }
    }
    my $running = (system("pgrep -xi \"Adobe Illustrator\" >/dev/null 2>&1") == 0) ? "true" : "false";
    return "{\"detected\":[" . join(",", @det) . "],\"installedYears\":[" . join(",", @inst) . "],\"installedVer\":\"" . json_escape($inst_ver) . "\",\"aiRunning\":$running,\"mode\":\"$mode\"}";
}

sub shell_q {
    my ($s) = @_;
    $s =~ s/\x27/\x27\\\x27\x27/g;
    return "\x27$s\x27";
}

sub do_install {
    my ($body) = @_;
    my $lang = "ar";
    if ($body =~ /"lang"\s*:\s*"([a-z]{2})"/) { $lang = $1; }
    my @years = (2024, 2025, 2026, 2027);
    if ($body =~ /"years"\s*:\s*\[([^\]]+)\]/) {
        my @parsed = ($1 =~ /(202[4-7])/g);
        @years = @parsed if @parsed;
    }

    system("mkdir", "-p", $cep_dir);
    system("mkdir", "-p", $app_sup);

    for my $y (@years) {
        my $src = "$pay_dir/Illustrator_$y/ArtboardStudio_$y";
        if (!-d $src) { return "{\"ok\":false,\"error\":\"Missing payload for Illustrator $y\"}"; }
        my $dst = "$cep_dir/com.rafat.artboardstudio.ai$y";
        system("rm", "-rf", $dst);
        my $rc = system("cp", "-R", $src, $dst);
        return "{\"ok\":false,\"error\":\"Copy failed for Illustrator $y\"}" if $rc != 0;
        system("xattr", "-dr", "com.apple.quarantine", $dst);

        my $stamp = time() . "0000000";
        my $dl = "// Artboard Studio — Default Language Configuration (written by Setup)\nwindow.ARTBOARD_STUDIO_DEFAULT_LANG = \x27$lang\x27;\nwindow.ARTBOARD_STUDIO_INSTALL_STAMP = \x27$stamp\x27;\n";
        write_file("$dst/default-lang.js", $dl);

        if (!-f "$dst/CSXS/manifest.xml" || !-f "$dst/index.html") {
            return "{\"ok\":false,\"error\":\"Verification failed for Illustrator $y\"}";
        }
    }

    for my $csxs (11, 12, 13, 14) {
        system("defaults", "write", "com.adobe.CSXS.$csxs", "PlayerDebugMode", "1");
    }

    # Write Mac Uninstaller command
    my $un_cmd = "$app_sup/Uninstall Artboard Studio.command";
    my $un_body = "#!/bin/bash\nrm -rf " . join(" ", map { shell_q("$cep_dir/com.rafat.artboardstudio.ai$_") } (2024..2027)) . "\nrm -rf " . shell_q($app_sup) . "\nosascript -e \x27display notification \"Artboard Studio uninstalled successfully.\" with title \"Artboard Studio\"\x27 >/dev/null 2>&1 || true\necho \"Artboard Studio uninstalled successfully.\"\n";
    write_file($un_cmd, $un_body);
    chmod(0755, $un_cmd);

    return "{\"ok\":true}";
}

sub do_uninstall {
    for my $y (2024, 2025, 2026, 2027) {
        system("rm", "-rf", "$cep_dir/com.rafat.artboardstudio.ai$y");
    }
    system("rm", "-rf", $app_sup);
    return "{\"ok\":true}";
}

my $running = 1;
while ($running && (my $c = $srv->accept())) {
    binmode($c);
    my $req = "";
    while (my $line = <$c>) {
        $req .= $line;
        last if $line =~ /^\r?\n$/;
    }
    my ($method, $path) = ($req =~ /^([A-Z]+)\s+([^\s\?]+)/);
    $method ||= "GET";
    $path   ||= "/";
    my $clen = 0;
    if ($req =~ /Content-Length:\s*(\d+)/i) { $clen = int($1); }
    my $body = "";
    if ($clen > 0) { read($c, $body, $clen); }

    if ($path eq "/") {
        my $html = read_file($ui_file);
        $html =~ s/1.12.6/$ver/g;
        send_resp($c, "200 OK", "text/html; charset=utf-8", $html);
    } elsif ($path eq "/api/info") {
        send_resp($c, "200 OK", "application/json; charset=utf-8", get_info_json());
    } elsif ($path eq "/api/install") {
        send_resp($c, "200 OK", "application/json; charset=utf-8", do_install($body));
    } elsif ($path eq "/api/uninstall") {
        send_resp($c, "200 OK", "application/json; charset=utf-8", do_uninstall());
    } elsif ($path eq "/api/kill-ai") {
        system("osascript -e \x27tell application \"Adobe Illustrator\" to quit\x27 >/dev/null 2>&1");
        send_resp($c, "200 OK", "application/json", "{\"ok\":true}");
    } elsif ($path eq "/api/launch-ai") {
        for my $y (2027, 2026, 2025, 2024) {
            my $app = find_ai_app($y);
            if ($app ne "") { system("open", $app); last; }
        }
        send_resp($c, "200 OK", "application/json", "{\"ok\":true}");
    } elsif ($path eq "/api/quit") {
        if ($ENV{"ABS_QUIT_FILE"}) { write_file($ENV{"ABS_QUIT_FILE"}, "1"); }
        send_resp($c, "200 OK", "application/json", "{\"ok\":true}");
        $running = 0;
    } else {
        send_resp($c, "404 Not Found", "text/plain", "Not Found");
    }
    close($c);
}
' "$PORT_FILE" &
SRV_PID=$!

cleanup() {
  rm -f "$PORT_FILE" "$QUIT_FILE" >/dev/null 2>&1 || true
  kill "$SRV_PID" >/dev/null 2>&1 || true
}
trap cleanup EXIT INT TERM

PORT=""
for i in $(seq 1 40); do
  if [ -s "$PORT_FILE" ]; then
    PORT="$(cat "$PORT_FILE")"
    break
  fi
  sleep 0.05
done

if [ -z "$PORT" ]; then
  exit 1
fi

URL="http://127.0.0.1:$PORT/"

# Try launching inside a clean native Cocoa WKWebView window (980x640 centered, matching Windows Setup.exe)
/usr/bin/osascript -l JavaScript <<JXA_EOF 2>/dev/null
ObjC.import('Cocoa');
ObjC.import('WebKit');
(function () {
  var app = $.NSApplication.sharedApplication;
  app.setActivationPolicy($.NSApplicationActivationPolicyRegular);

  var W = 980, H = 640;
  var scr = $.NSScreen.mainScreen.frame;
  var x = (scr.size.width - W) / 2;
  var y = (scr.size.height - H) / 2;
  var style = $.NSWindowStyleMaskTitled | $.NSWindowStyleMaskClosable | $.NSWindowStyleMaskMiniaturizable;
  var win = $.NSWindow.alloc.initWithContentRectStyleMaskBackingDefer(
    $.NSMakeRect(x, y, W, H), style, $.NSBackingStoreBuffered, false
  );
  win.title = 'Artboard Studio 1.12.6 — Setup';
  win.backgroundColor = $.NSColor.colorWithRedGreenBlueAlpha(0.055, 0.039, 0.122, 1.0);

  ObjC.registerSubclass({
    name: 'ABSWinDelegate',
    methods: {
      'windowWillClose:': {
        types: ['void', ['id']],
        implementation: function () { $.NSApp.terminate(null); }
      }
    }
  });
  var del = $.ABSWinDelegate.alloc.init;
  win.delegate = del;

  var cfg = $.WKWebViewConfiguration.alloc.init;
  var wv = $.WKWebView.alloc.initWithFrameConfiguration($.NSMakeRect(0, 0, W, H), cfg);
  wv.autoresizingMask = $.NSViewWidthSizable | $.NSViewHeightSizable;
  var req = $.NSURLRequest.requestWithURL($.NSURL.URLWithString('$URL'));
  wv.loadRequest(req);
  win.contentView = wv;

  var fm = $.NSFileManager.defaultManager;
  $.NSTimer.scheduledTimerWithTimeIntervalRepeatsBlock(0.2, true, function () {
    if (fm.fileExistsAtPath('$QUIT_FILE')) { $.NSApp.terminate(null); }
  });

  win.makeKeyAndOrderFront(null);
  app.activateIgnoringOtherApps(true);
  app.run;
})();
JXA_EOF

EXIT_CODE=$?
if [ "$EXIT_CODE" -ne 0 ]; then
  open "$URL"
  wait "$SRV_PID"
fi
