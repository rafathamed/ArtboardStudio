# Artboard Studio 1.12.6 — المثبّت المتحرك لنظام macOS

## طريقة التثبيت
1. فك ضغط هذا الأرشيف على جهاز Mac (بالنقر المزدوج من Finder).
2. شغّل **`Artboard Studio Setup.app`** (أو **`Artboard Studio Setup.command`** — عند أول فتح على macOS اختر كليك يمين ▸ **Open**).
3. اختر لغتك المفضلة (العربية، الإنجليزية، الروسية، الهندية، الصينية، اليابانية) ثم اضغط **تثبيت الآن** (أو **تخصيص** لاختيار إصدارات Illustrator `2024–2027`).
4. افتح Adobe Illustrator ثم انتقل إلى:
   **Window ▸ Extensions (Legacy) ▸ Artboard Studio**

---
## الإزالة (Uninstall)
بعد التثبيت يُنشأ مزيل التثبيت تلقائيًا في:
`~/Library/Application Support/Artboard Studio/Uninstall Artboard Studio.command`
