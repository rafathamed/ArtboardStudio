# Artboard Studio 1.12.6 — نسخة macOS

اختر مجلد إصدار Illustrator المناسب (2024 / 2025 / 2026 / 2027) واتبع ملف README_Mac_AR.md بداخله.
المثبّت: Install_Illustrator_XXXX.command (كليك يمين ‹ Open في أول مرة).
