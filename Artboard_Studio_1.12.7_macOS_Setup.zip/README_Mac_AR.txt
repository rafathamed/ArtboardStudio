Artboard Studio 1.12.7 - macOS
==========================
1) انقر مرتين على Artboard_Studio_1.12.7_macOS_Setup.command (أول مرة: كليك يمين > Open ثم Open).
   Double-click the .command file (first time: right-click > Open).
2) أغلق Illustrator بالكامل قبل التثبيت. Quit Illustrator completely first.
3) افتح Illustrator: Window > Extensions (Legacy) > Artboard Studio.
   نافذتا «تعديل الصور» و«تحويل الصورة» تُفتحان من اللوحة الرئيسية.
الإزالة / Uninstall: Uninstall_Artboard_Studio.command
إن ظهر "permission denied": افتح Terminal ونفّذ: chmod +x *.command
