#!/bin/bash
cd "$(dirname "$0")"; exec bash "./Artboard_Studio_1.12.7_macOS_Setup.command" uninstall
