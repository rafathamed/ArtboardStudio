/* Local QR encoder: Byte mode, ECC-M & ECC-H, QR versions 1-10, optimal mask 0-7, optional center icon cutout. Zero network calls. */
(function (root) {
  'use strict';

  /* ISO/IEC 18004 Tables for Versions 1-10 (ECC-M and ECC-H) */
  var VERSIONS = {
    M: [
      null,
      { data: 16,  ecc: 10, g1B: 1, g1D: 16, g2B: 0, g2D: 0,  align: [] },
      { data: 28,  ecc: 16, g1B: 1, g1D: 28, g2B: 0, g2D: 0,  align: [6, 18] },
      { data: 44,  ecc: 26, g1B: 1, g1D: 44, g2B: 0, g2D: 0,  align: [6, 22] },
      { data: 64,  ecc: 18, g1B: 2, g1D: 32, g2B: 0, g2D: 0,  align: [6, 26] },
      { data: 86,  ecc: 24, g1B: 2, g1D: 43, g2B: 0, g2D: 0,  align: [6, 30] },
      { data: 108, ecc: 16, g1B: 4, g1D: 27, g2B: 0, g2D: 0,  align: [6, 34] },
      { data: 124, ecc: 18, g1B: 4, g1D: 31, g2B: 0, g2D: 0,  align: [6, 22, 38] },
      { data: 154, ecc: 22, g1B: 2, g1D: 38, g2B: 2, g2D: 39, align: [6, 24, 42] },
      { data: 182, ecc: 22, g1B: 3, g1D: 36, g2B: 2, g2D: 37, align: [6, 26, 46] },
      { data: 216, ecc: 26, g1B: 4, g1D: 43, g2B: 1, g2D: 44, align: [6, 28, 50] }
    ],
    H: [
      null,
      { data: 9,   ecc: 17, g1B: 1, g1D: 9,  g2B: 0, g2D: 0,  align: [] },
      { data: 16,  ecc: 28, g1B: 1, g1D: 16, g2B: 0, g2D: 0,  align: [6, 18] },
      { data: 26,  ecc: 22, g1B: 2, g1D: 13, g2B: 0, g2D: 0,  align: [6, 22] },
      { data: 36,  ecc: 16, g1B: 4, g1D: 9,  g2B: 0, g2D: 0,  align: [6, 26] },
      { data: 46,  ecc: 22, g1B: 2, g1D: 11, g2B: 2, g2D: 12, align: [6, 30] },
      { data: 60,  ecc: 28, g1B: 4, g1D: 15, g2B: 0, g2D: 0,  align: [6, 34] },
      { data: 66,  ecc: 26, g1B: 4, g1D: 13, g2B: 1, g2D: 14, align: [6, 22, 38] },
      { data: 86,  ecc: 26, g1B: 4, g1D: 14, g2B: 2, g2D: 15, align: [6, 24, 42] },
      { data: 100, ecc: 24, g1B: 4, g1D: 12, g2B: 4, g2D: 13, align: [6, 26, 46] },
      { data: 122, ecc: 28, g1B: 6, g1D: 15, g2B: 2, g2D: 16, align: [6, 28, 50] }
    ]
  };

  function utf8Bytes(str) {
    if (typeof TextEncoder !== 'undefined') return Array.prototype.slice.call(new TextEncoder().encode(str));
    var encoded = unescape(encodeURIComponent(str));
    var out = [];
    for (var i = 0; i < encoded.length; i++) out.push(encoded.charCodeAt(i));
    return out;
  }

  function gfMul(x, y) {
    var z = 0;
    for (var i = 7; i >= 0; i--) {
      z = (z << 1) ^ ((z >>> 7) * 0x11D);
      if ((y >>> i) & 1) z ^= x;
    }
    return z;
  }

  function gfPow(power) {
    var x = 1;
    for (var i = 0; i < power; i++) x = gfMul(x, 2);
    return x;
  }

  var RS_CACHE = {};
  function rsGenerator(degree) {
    if (RS_CACHE[degree]) return RS_CACHE[degree];
    var p = [1];
    for (var i = 0; i < degree; i++) {
      var next = new Array(p.length + 1);
      for (var z = 0; z < next.length; z++) next[z] = 0;
      var root = gfPow(i);
      for (var j = 0; j < p.length; j++) {
        next[j] ^= p[j];
        next[j + 1] ^= gfMul(p[j], root);
      }
      p = next;
    }
    RS_CACHE[degree] = p;
    return p;
  }

  function rsRemainder(data, degree) {
    var gen = rsGenerator(degree);
    var rem = data.slice();
    for (var i = 0; i < degree; i++) rem.push(0);
    for (var k = 0; k < data.length; k++) {
      var factor = rem[k];
      if (factor) for (var j = 0; j < gen.length; j++) rem[k + j] ^= gfMul(gen[j], factor);
    }
    return rem.slice(data.length);
  }

  function pushBits(out, value, count) {
    for (var i = count - 1; i >= 0; i--) out.push((value >>> i) & 1);
  }

  function makeCodewords(bytes, cfg, version) {
    var bits = [];
    pushBits(bits, 4, 4); // Byte mode
    pushBits(bits, bytes.length, version < 10 ? 8 : 16);
    for (var i = 0; i < bytes.length; i++) pushBits(bits, bytes[i], 8);
    var maxBits = cfg.data * 8;
    if (bits.length > maxBits) throw new Error('النص أطول من سعة QR المتاحة.');
    for (i = 0; i < Math.min(4, maxBits - bits.length); i++) bits.push(0);
    while (bits.length % 8) bits.push(0);
    var data = [];
    for (i = 0; i < bits.length; i += 8) {
      var val = 0;
      for (var b = 0; b < 8; b++) val = (val << 1) | bits[i + b];
      data.push(val);
    }
    var pad = [0xEC, 0x11], p = 0;
    while (data.length < cfg.data) data.push(pad[p++ & 1]);

    var blocks = [], offset = 0;
    for (i = 0; i < cfg.g1B; i++) {
      var part1 = data.slice(offset, offset + cfg.g1D);
      offset += cfg.g1D;
      blocks.push({ data: part1, ecc: rsRemainder(part1, cfg.ecc) });
    }
    for (i = 0; i < cfg.g2B; i++) {
      var part2 = data.slice(offset, offset + cfg.g2D);
      offset += cfg.g2D;
      blocks.push({ data: part2, ecc: rsRemainder(part2, cfg.ecc) });
    }

    var out = [];
    var maxDataLen = Math.max(cfg.g1D, cfg.g2D);
    for (i = 0; i < maxDataLen; i++) {
      for (var k = 0; k < blocks.length; k++) {
        if (i < blocks[k].data.length) out.push(blocks[k].data[i]);
      }
    }
    for (i = 0; i < cfg.ecc; i++) {
      for (k = 0; k < blocks.length; k++) out.push(blocks[k].ecc[i]);
    }
    return out;
  }

  function maskBit(mask, r, c) {
    switch (mask) {
      case 0: return (r + c) % 2 === 0;
      case 1: return r % 2 === 0;
      case 2: return c % 3 === 0;
      case 3: return (r + c) % 3 === 0;
      case 4: return ((r >>> 1) + Math.floor(c / 3)) % 2 === 0;
      case 5: return ((r * c) % 2) + ((r * c) % 3) === 0;
      case 6: return ((((r * c) % 2) + ((r * c) % 3)) % 2) === 0;
      default: return ((((r + c) % 2) + ((r * c) % 3)) % 2) === 0;
    }
  }

  function addFinder(m, r0, c0) {
    var n = m.length;
    for (var dr = -1; dr <= 7; dr++) {
      for (var dc = -1; dc <= 7; dc++) {
        var r = r0 + dr, c = c0 + dc;
        if (r < 0 || r >= n || c < 0 || c >= n) continue;
        var dark = (dr >= 0 && dr <= 6 && dc >= 0 && dc <= 6) &&
          (dr === 0 || dr === 6 || dc === 0 || dc === 6 || (dr >= 2 && dr <= 4 && dc >= 2 && dc <= 4));
        m[r][c] = dark;
      }
    }
  }

  function addAlignment(m, r0, c0) {
    for (var dr = -2; dr <= 2; dr++) {
      for (var dc = -2; dc <= 2; dc++) {
        var d = Math.max(Math.abs(dr), Math.abs(dc));
        m[r0 + dr][c0 + dc] = (d === 2 || d === 0);
      }
    }
  }

  function writeFormat(m, mask, eccLevel) {
    var n = m.length;
    var ecBits = eccLevel === 'H' ? 2 : 0; // M = 00, H = 10
    var data = (ecBits << 3) | mask;
    var rem = data;
    for (var i = 0; i < 10; i++) rem = (rem << 1) ^ (((rem >>> 9) & 1) ? 0x537 : 0);
    var bits = ((data << 10) | rem) ^ 0x5412;
    function bit(idx) { return ((bits >>> idx) & 1) !== 0; }
    for (i = 0; i <= 5; i++) m[i][8] = bit(i);
    m[7][8] = bit(6); m[8][8] = bit(7); m[8][7] = bit(8);
    for (i = 9; i < 15; i++) m[8][14 - i] = bit(i);
    for (i = 0; i < 8; i++) m[8][n - 1 - i] = bit(i);
    for (i = 8; i < 15; i++) m[n - 15 + i][8] = bit(i);
    m[n - 8][8] = true;
  }

  function writeVersion(m, version) {
    if (version < 7) return;
    var n = m.length;
    var rem = version;
    for (var i = 0; i < 12; i++) rem = (rem << 1) ^ (((rem >>> 11) & 1) ? 0x1F25 : 0);
    var bits = (version << 12) | rem;
    for (i = 0; i < 18; i++) {
      var mod = ((bits >>> i) & 1) !== 0;
      var a = Math.floor(i / 3), b = (i % 3) + n - 11;
      m[a][b] = mod;
      m[b][a] = mod;
    }
  }

  function buildTemplate(cfg, version) {
    var n = version * 4 + 17;
    var m = new Array(n);
    for (var r = 0; r < n; r++) {
      m[r] = new Array(n);
      for (var c = 0; c < n; c++) m[r][c] = null;
    }
    addFinder(m, 0, 0);
    addFinder(m, 0, n - 7);
    addFinder(m, n - 7, 0);

    for (var i = 8; i < n - 8; i++) {
      if (m[6][i] === null) m[6][i] = (i % 2 === 0);
      if (m[i][6] === null) m[i][6] = (i % 2 === 0);
    }

    var positions = cfg.align;
    var plen = positions.length;
    for (var ai = 0; ai < plen; ai++) {
      for (var aj = 0; aj < plen; aj++) {
        if ((ai === 0 && aj === 0) || (ai === 0 && aj === plen - 1) || (ai === plen - 1 && aj === 0)) continue;
        addAlignment(m, positions[ai], positions[aj]);
      }
    }

    // Reserve format-info & version-info cells before data placement.
    for (i = 0; i <= 5; i++) { m[i][8] = false; m[8][i] = false; }
    m[7][8] = false; m[8][8] = false; m[8][7] = false;
    for (i = 0; i < 8; i++) m[8][n - 1 - i] = false;
    for (i = 0; i < 8; i++) m[n - 8 + i][8] = false;
    if (version >= 7) {
      for (i = 0; i < 6; i++) {
        for (var k = 0; k < 3; k++) {
          m[i][n - 11 + k] = false;
          m[n - 11 + k][i] = false;
        }
      }
    }
    return m;
  }

  function applyMask(template, codewords, version, mask, eccLevel) {
    var n = template.length;
    var m = new Array(n);
    for (var r = 0; r < n; r++) m[r] = template[r].slice();

    var bitIndex = 0, totalBits = codewords.length * 8;
    for (var right = n - 1; right >= 1; right -= 2) {
      if (right === 6) right = 5;
      for (var vert = 0; vert < n; vert++) {
        var row = ((right + 1) & 2) === 0 ? n - 1 - vert : vert;
        for (var j = 0; j < 2; j++) {
          var col = right - j;
          if (m[row][col] !== null) continue;
          var val = bitIndex < totalBits ? ((codewords[bitIndex >>> 3] >>> (7 - (bitIndex & 7))) & 1) !== 0 : false;
          if (maskBit(mask, row, col)) val = !val;
          m[row][col] = val;
          bitIndex++;
        }
      }
    }
    writeFormat(m, mask, eccLevel);
    writeVersion(m, version);
    return m;
  }

  function penaltyScore(m) {
    var n = m.length, score = 0, r, c, run, last;
    // N1: 5+ same-color modules in row/col
    for (r = 0; r < n; r++) {
      run = 1; last = m[r][0];
      for (c = 1; c < n; c++) {
        if (m[r][c] === last) { run++; if (run === 5) score += 3; else if (run > 5) score += 1; }
        else { last = m[r][c]; run = 1; }
      }
    }
    for (c = 0; c < n; c++) {
      run = 1; last = m[0][c];
      for (r = 1; r < n; r++) {
        if (m[r][c] === last) { run++; if (run === 5) score += 3; else if (run > 5) score += 1; }
        else { last = m[r][c]; run = 1; }
      }
    }
    // N2: 2x2 same-color blocks
    for (r = 0; r < n - 1; r++) {
      for (c = 0; c < n - 1; c++) {
        var b = m[r][c];
        if (m[r][c + 1] === b && m[r + 1][c] === b && m[r + 1][c + 1] === b) score += 3;
      }
    }
    // N3: finder-like 1:1:3:1:1:4 ratios
    function isP1(arr) {
      return arr[0] && !arr[1] && arr[2] && arr[3] && arr[4] && !arr[5] && arr[6];
    }
    for (r = 0; r < n; r++) {
      for (c = 0; c <= n - 11; c++) {
        var rowS = [m[r][c], m[r][c+1], m[r][c+2], m[r][c+3], m[r][c+4], m[r][c+5], m[r][c+6]];
        if (isP1(rowS) && ((!m[r][c+7] && !m[r][c+8] && !m[r][c+9] && !m[r][c+10]) || (c >= 4 && !m[r][c-1] && !m[r][c-2] && !m[r][c-3] && !m[r][c-4]))) score += 40;
        var colS = [m[c][r], m[c+1][r], m[c+2][r], m[c+3][r], m[c+4][r], m[c+5][r], m[c+6][r]];
        if (isP1(colS) && ((!m[c+7][r] && !m[c+8][r] && !m[c+9][r] && !m[c+10][r]) || (c >= 4 && !m[c-1][r] && !m[c-2][r] && !m[c-3][r] && !m[c-4][r]))) score += 40;
      }
    }
    // N4: dark ratio balance
    var dark = 0;
    for (r = 0; r < n; r++) for (c = 0; c < n; c++) if (m[r][c]) dark++;
    var pct = Math.floor(Math.abs(dark * 100 / (n * n) - 50) / 5);
    score += pct * 10;
    return score;
  }

  function computeCutoutModules(n) {
    // Keep cutout safely inside 20-23% of grid width (odd count >= 5, never overlapping alignment/finder patterns)
    var target = Math.floor(n * 0.23);
    if (target % 2 === 0) target--;
    if (n <= 21) return 5;
    if (n <= 25) return 5;
    if (n <= 29) return 7;
    return Math.max(7, Math.min(13, target));
  }

  function clearCenterForIcon(matrix, cutout) {
    var n = matrix.length;
    var pad = Math.floor((n - cutout) / 2);
    for (var r = pad; r < pad + cutout; r++) {
      for (var c = pad; c < pad + cutout; c++) {
        matrix[r][c] = false;
      }
    }
  }

  function chooseVersion(byteLength, eccLevel, minVersion) {
    var table = VERSIONS[eccLevel];
    var start = Math.max(1, minVersion || 1);
    for (var v = start; v <= 10; v++) {
      var lenBits = v < 10 ? 8 : 16;
      var required = 4 + lenBits + byteLength * 8;
      if (required <= table[v].data * 8) return v;
    }
    throw new Error('النص أو الرابط أطول من سعة QR المدعومة (' + table[10].data + ' بايت في وضع ' + eccLevel + '). اختصر الرابط وحاول مجددًا.');
  }

  function encode(text, options) {
    var opts = options || {};
    var eccLevel = (opts.ecc === 'H' || opts.icon) ? 'H' : 'M';
    var minV = opts.minVersion || (opts.icon ? 3 : 1);
    var bytes = utf8Bytes(String(text));
    var version = chooseVersion(bytes.length, eccLevel, minV);
    var cfg = VERSIONS[eccLevel][version];
    var codewords = makeCodewords(bytes, cfg, version);
    var template = buildTemplate(cfg, version);

    var bestMask = 0, bestScore = 1e9, bestMatrix = null;
    for (var mask = 0; mask < 8; mask++) {
      var candidate = applyMask(template, codewords, version, mask, eccLevel);
      var s = penaltyScore(candidate);
      if (s < bestScore) { bestScore = s; bestMask = mask; bestMatrix = candidate; }
    }

    var cutout = 0;
    if (opts.icon) {
      cutout = computeCutoutModules(bestMatrix.length);
      clearCenterForIcon(bestMatrix, cutout);
    }
    return {
      version: version,
      ecc: eccLevel,
      mask: bestMask,
      cutout: cutout,
      matrix: bestMatrix,
      bytes: bytes.length
    };
  }

  function toSvg(text, pixels, options) {
    var result = encode(text, options), matrix = result.matrix;
    var n = matrix.length, quiet = 4, full = n + quiet * 2;
    var path = [];
    for (var r = 0; r < n; r++) {
      var start = -1;
      for (var c = 0; c <= n; c++) {
        var isBlack = c < n && matrix[r][c];
        if (isBlack && start < 0) start = c;
        if ((!isBlack || c === n) && start >= 0) {
          path.push('M' + (start + quiet) + ' ' + (r + quiet) + 'h' + (c - start) + 'v1h-' + (c - start) + 'z');
          start = -1;
        }
      }
    }
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" width="' + pixels + '" height="' + pixels + '" viewBox="0 0 ' + full + ' ' + full + '"><rect width="100%" height="100%" fill="#fff"/><path d="' + path.join('') + '" fill="#000"/></svg>';
    return { svg: svg, version: result.version, ecc: result.ecc, cutout: result.cutout, bytes: result.bytes };
  }

  root.ArtboardStudioQR = { encode: encode, toSvg: toSvg, computeCutoutModules: computeCutoutModules };
}(this));
