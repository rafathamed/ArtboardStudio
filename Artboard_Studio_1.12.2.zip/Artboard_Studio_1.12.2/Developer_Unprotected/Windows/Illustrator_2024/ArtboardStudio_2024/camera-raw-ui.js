/* Artboard Studio - "تعديل الصور" tab (Camera-Raw-style editing for images in Illustrator).
   Flow: selected image -> exported to a temp PNG (no extra window when the host supports it) ->
   every change is rendered at preview size and pushed to a linked placeholder ON the artwork
   (single-flight, latest-wins) -> after release a sharper settled frame is pushed ->
   "apply" renders full resolution and places it back. */
(function () {
  'use strict';
  var E = window.ABSCameraRaw;
  if (!E) return;
  var $ = function (id) { return document.getElementById(id); };

  var PREVIEW_MAX = 420, LIVE_HI = 960, PROXY_MAX = 480, SETTLE_MS = 180;
  var state = { info: null, full: null, prevCtx: null, prevSrc: null, hasAlpha: false, params: E.defaults(), busy: false, mixMode: 'hue', rafPending: false, live: null, hiCtx: null, comparing: false, settleTimer: 0 };
  var rows = [];      // {key, idx, input, output, row, def, fmt}
  var mixRows = [];

  var SCHEMA = [
    { id: 'light', title: 'الضوء', open: true, items: [
      ['exposure', 'التعريض', -5, 5, 0.05, 0, 'ev'], ['contrast', 'التباين', -100, 100, 1, 0],
      ['highlights', 'الإضاءات العالية', -100, 100, 1, 0], ['shadows', 'الظلال', -100, 100, 1, 0],
      ['whites', 'الأبيض', -100, 100, 1, 0], ['blacks', 'الأسود', -100, 100, 1, 0] ] },
    { id: 'color', title: 'اللون', open: true, items: [
      ['temp', 'حرارة اللون', -100, 100, 1, 0, '', 'cr-temp'], ['tint', 'الصبغة', -100, 100, 1, 0, '', 'cr-tint'],
      ['vibrance', 'الحيوية', -100, 100, 1, 0], ['saturation', 'التشبع', -100, 100, 1, 0] ] },
    { id: 'mixer', title: 'خلاط الألوان', open: false, mixer: true },
    { id: 'effects', title: 'التأثيرات', open: false, items: [
      ['texture', 'الملمس', -100, 100, 1, 0], ['clarity', 'الوضوح', -100, 100, 1, 0], ['dehaze', 'إزالة الضباب', -100, 100, 1, 0],
      ['vignette', 'تظليل الحواف', -100, 100, 1, 0], ['vigMid', 'منتصف التظليل', 0, 100, 1, 50], ['vigFeather', 'نعومة التظليل', 0, 100, 1, 50],
      ['grain', 'الحبيبات', 0, 100, 1, 0], ['grainSize', 'حجم الحبيبات', 0, 100, 1, 25] ] },
    { id: 'detail', title: 'التفاصيل', open: false, items: [
      ['sharpen', 'الحدّة', 0, 150, 1, 0], ['sharpenRadius', 'نصف القطر', 0.5, 3, 0.1, 1, 'dec1'],
      ['nrLum', 'تقليل الضوضاء (السطوع)', 0, 100, 1, 0], ['nrColor', 'تقليل الضوضاء (اللون)', 0, 100, 1, 0] ] }
  ];
  var BANDS = [['الأحمر', '#e5484d'], ['البرتقالي', '#f08a24'], ['الأصفر', '#e8c21a'], ['الأخضر', '#3fb950'],
               ['السماوي', '#1fc2c2'], ['الأزرق', '#3b82f6'], ['البنفسجي', '#8b5cf6'], ['الأرجواني', '#d946ef']];

  function fmt(v, kind) {
    if (kind === 'ev') return (v > 0 ? '+' : '') + v.toFixed(2);
    if (kind === 'dec1') return v.toFixed(1);
    return (v > 0 ? '+' : '') + Math.round(v);
  }
  function status(msg, type) {
    var el = $('crStatus'); if (!el) return;
    el.className = 'cr-status' + (type ? ' ' + type : '');
    var raw = msg || '';
    el.setAttribute('data-i18n-ar', raw);
    el.textContent = (window.ABSi18n && raw) ? window.ABSi18n.tr(raw) : raw;
  }
  function hostApi() { return window.__adobe_cep__ && typeof window.__adobe_cep__.evalScript === 'function' ? window.__adobe_cep__ : null; }
  function hostEval(expr, cb, timeoutMs) {
    var api = hostApi();
    if (!api) { cb(false, 'لوحة Illustrator غير جاهزة بعد.'); return; }
    var done = false;
    var ms = timeoutMs || 18000;
    var timer = window.setTimeout(function () {
      if (done) return;
      done = true;
      cb(false, 'انتهت مهلة استجابة Illustrator. أعد المحاولة وتأكد من عدم وجود نافذة حوار مفتوحة في البرنامج.');
    }, ms);
    try {
      api.evalScript(expr, function (res) {
        if (done) return;
        done = true;
        window.clearTimeout(timer);
        res = String(res || '');
        if (res === 'EvalScript error.') {
          cb(false, 'تعذّر تنفيذ الأمر داخل Illustrator. تأكد من فتح مستند وتحديد صورة صالحة.');
          return;
        }
        var ok = res.indexOf('OK|') === 0, body = res.indexOf('|') >= 0 ? res.substring(res.indexOf('|') + 1) : res;
        cb(ok, body);
      });
    } catch (e) {
      if (done) return;
      done = true;
      window.clearTimeout(timer);
      cb(false, e.message || String(e));
    }
  }

  function kickPaint() {
    try {
      document.body.style.transform = 'translateZ(0)';
      void document.body.offsetHeight;
      window.setTimeout(function () {
        try { document.body.style.transform = ''; void document.body.offsetHeight; } catch (e2) {}
      }, 16);
    } catch (e) {}
  }

  /* ---------- non-trapping status overlay (auto-clears & dismisses on click) ---------- */
  (function () {
    window.ABSSession = window.ABSSession || { owner: null };
    if (window.ABSBusy) return;
    var el = null, depth = 0, autoTimer = 0;
    function trText(t) { return (window.ABSi18n && t) ? window.ABSi18n.tr(t) : t; }
    function build() {
      el = document.createElement('div'); el.className = 'abs-busy hidden'; el.setAttribute('role', 'status'); el.setAttribute('aria-live', 'polite');
      el.innerHTML = '<div class="abs-busy-box"><div class="abs-busy-title">Artboard Studio</div><div class="abs-busy-msg" id="absBusyMsg"></div><div class="abs-busy-bar"><i></i></div><div class="abs-busy-hint" id="absBusyHint"></div></div>';
      el.addEventListener('click', function () { window.ABSBusy.hide(); });
      document.body.appendChild(el);
    }
    window.ABSBusy = {
      show: function (msg) {
        if (!el) build();
        depth++;
        if (autoTimer) window.clearTimeout(autoTimer);
        document.getElementById('absBusyMsg').textContent = trText(msg || 'جارٍ التحميل…');
        var hint = document.getElementById('absBusyHint');
        if (hint) hint.textContent = trText('الرجاء الانتظار لحظات…');
        el.classList.remove('hidden'); document.body.classList.add('abs-is-busy');
        autoTimer = window.setTimeout(function () { window.ABSBusy.hide(); }, 3500);
        kickPaint();
      },
      hide: function () {
        depth = 0;
        if (autoTimer) { window.clearTimeout(autoTimer); autoTimer = 0; }
        if (!el) return;
        el.classList.add('hidden');
        document.body.classList.remove('abs-is-busy');
        kickPaint();
      },
      isOn: function () { return !!el && !el.classList.contains('hidden'); }
    };
  })();

  function jsq(str) { // ASCII-only JS string literal (safe through the evalScript text channel)
    return JSON.stringify(String(str)).replace(/[\u007f-\uffff]/g, function (c) { return '\\u' + ('0000' + c.charCodeAt(0).toString(16)).slice(-4); });
  }
  function fsOk() { return window.cep && window.cep.fs && window.cep.encoding; }

  /* ---------- UI construction ---------- */
  function buildRow(container, key, label, min, max, step, def, kind, cls, arrKey, idx, color) {
    var row = document.createElement('div'); row.className = 'cr-row' + (cls ? ' ' + cls : '');
    var lab = document.createElement('label'); lab.textContent = label;
    if (color) { var dot = document.createElement('i'); dot.className = 'cr-dot'; dot.style.background = color; lab.insertBefore(dot, lab.firstChild); }
    var input = document.createElement('input'); input.type = 'range'; input.min = min; input.max = max; input.step = step; input.value = def; input.setAttribute('dir', 'ltr');
    input.setAttribute('aria-label', label);
    var out = document.createElement('output'); out.textContent = fmt(def, kind);
    row.appendChild(lab); row.appendChild(input); row.appendChild(out); container.appendChild(row);
    var rec = { key: key, arrKey: arrKey, idx: idx, input: input, output: out, row: row, def: def, kind: kind };
    function setFromInput() {
      var v = parseFloat(input.value);
      if (arrKey) state.params[arrKey][idx] = v; else state.params[key] = v;
      out.textContent = fmt(v, kind); row.classList.toggle('changed', v !== def);
      schedule();
    }
    input.addEventListener('input', setFromInput);
    var reset = function () { input.value = def; setFromInput(); };
    lab.addEventListener('dblclick', reset); out.addEventListener('dblclick', reset);
    return rec;
  }

  function buildUI() {
    var host = $('crSections'); if (!host || host.getAttribute('data-built')) return;
    host.setAttribute('data-built', '1');
    SCHEMA.forEach(function (sec) {
      var d = document.createElement('details'); d.className = 'cr-sec'; if (sec.open) d.open = true;
      var sum = document.createElement('summary'); sum.textContent = sec.title; d.appendChild(sum);
      var body = document.createElement('div'); body.className = 'cr-sec-body'; d.appendChild(body);
      if (sec.mixer) buildMixer(body);
      else sec.items.forEach(function (it) { rows.push(buildRow(body, it[0], it[1], it[2], it[3], it[4], it[5], it[6] || '', it[7] || '')); });
      host.appendChild(d);
    });
  }

  function buildMixer(body) {
    var seg = document.createElement('div'); seg.className = 'cr-seg';
    [['hue', 'درجة اللون'], ['sat', 'التشبع'], ['lum', 'السطوع']].forEach(function (m) {
      var b = document.createElement('button'); b.type = 'button'; b.textContent = m[1]; b.setAttribute('data-mode', m[0]);
      if (m[0] === state.mixMode) b.className = 'active';
      b.addEventListener('click', function () { state.mixMode = m[0]; refreshMixer(); });
      seg.appendChild(b);
    });
    body.appendChild(seg);
    var bw = document.createElement('label'); bw.className = 'cr-check';
    var cb = document.createElement('input'); cb.type = 'checkbox'; cb.id = 'crBw';
    cb.addEventListener('change', function () { state.params.bw = cb.checked; schedule(); });
    bw.appendChild(cb); bw.appendChild(document.createTextNode(' أبيض وأسود (السطوع يتحكم بدرجات الرمادي لكل لون)'));
    body.appendChild(bw);
    var wrap = document.createElement('div'); wrap.id = 'crMixRows'; body.appendChild(wrap);
    refreshMixer();
  }

  function refreshMixer() {
    var wrap = $('crMixRows'); if (!wrap) return;
    var seg = wrap.parentNode.querySelectorAll('.cr-seg button');
    for (var i = 0; i < seg.length; i++) seg[i].classList.toggle('active', seg[i].getAttribute('data-mode') === state.mixMode);
    wrap.innerHTML = ''; mixRows = [];
    for (var b = 0; b < 8; b++) {
      var rec = buildRow(wrap, state.mixMode, BANDS[b][0], -100, 100, 1, 0, '', '', state.mixMode, b, BANDS[b][1]);
      rec.input.value = state.params[state.mixMode][b]; rec.output.textContent = fmt(state.params[state.mixMode][b], '');
      rec.row.classList.toggle('changed', state.params[state.mixMode][b] !== 0);
      mixRows.push(rec);
    }
  }

  function syncUI() { // push state.params into all controls
    rows.forEach(function (r) {
      var v = state.params[r.key]; r.input.value = v; r.output.textContent = fmt(v, r.kind); r.row.classList.toggle('changed', v !== r.def);
    });
    refreshMixer();
    var cb = $('crBw'); if (cb) cb.checked = !!state.params.bw;
  }

  /* ---------- rendering (direct on-canvas, no panel canvas preview) ---------- */
  function schedule() {
    if (!state.prevCtx) return;
    window.clearTimeout(state.settleTimer);
    state.settleTimer = window.setTimeout(settle, SETTLE_MS);
    if (state.rafPending) return;
    state.rafPending = true;
    (window.requestAnimationFrame || window.setTimeout)(function () { state.rafPending = false; render(); });
  }

  function render() {
    if (!state.prevCtx) return;
    if (state.comparing) return;
    if (E.isNeutral(state.params) && (!state.live || !state.live.on)) return;
    var w = state.prevCtx.w, h = state.prevCtx.h;
    var out = E.process(state.prevCtx, state.params);
    sendFrame(out, w, h);
  }

  /* sharper frame for the artwork once the user stops dragging */
  function settle() {
    var L = state.live;
    if (!L || !L.on || !state.full || state.comparing) return;
    var full = state.full, fm = Math.max(full.width, full.height);
    if (fm <= PREVIEW_MAX * 1.15) return;
    if (!state.hiCtx) {
      var f = Math.min(1, LIVE_HI / fm), hw = Math.max(1, Math.round(full.width * f)), hh = Math.max(1, Math.round(full.height * f));
      var a = document.createElement('canvas'); a.width = full.width; a.height = full.height; a.getContext('2d').putImageData(full, 0, 0);
      var b = document.createElement('canvas'); b.width = hw; b.height = hh;
      var bg = b.getContext('2d'); bg.imageSmoothingQuality = 'high'; bg.drawImage(a, 0, 0, hw, hh);
      state.hiCtx = E.createContext(bg.getImageData(0, 0, hw, hh), { fullMax: fm });
    }
    sendFrame(E.process(state.hiCtx, state.params), state.hiCtx.w, state.hiCtx.h);
  }

  /* ---------- live frames on the artwork ---------- */
  function tmpDir() { var p = state.info.outPath, i = Math.max(p.lastIndexOf('\\'), p.lastIndexOf('/')); return { dir: p.substring(0, i), sep: p.charAt(i) }; }
  function writeFrame(rgba, w, h) {
    var L = state.live, cv = L.cv || (L.cv = document.createElement('canvas')); cv.width = w; cv.height = h;
    cv.getContext('2d').putImageData(new ImageData(rgba, w, h), 0, 0);
    var useJpg = !state.hasAlpha;
    var b64 = (useJpg ? cv.toDataURL('image/jpeg', 0.88) : cv.toDataURL('image/png')).split(',')[1], d = tmpDir();
    var path = d.dir + d.sep + 'abs_live_' + L.stamp + '_' + (++L.n) + (useJpg ? '.jpg' : '.png');
    var wr = window.cep.fs.writeFile(path, b64, window.cep.encoding.Base64);
    if (!wr || wr.err !== 0) return null;
    return path;
  }
  function liveLabel(on) {
    var el = $('crLiveState'); if (!el) return;
    el.className = 'cr-livestate' + (on ? ' on' : '');
    var raw = on ? 'مباشر على الصورة في Illustrator' : 'معاينة داخل اللوحة فقط';
    el.setAttribute('data-i18n-ar', raw);
    el.textContent = window.ABSi18n ? window.ABSi18n.tr(raw) : raw;
  }
  function dropFile(p) { if (p) try { window.cep.fs.deleteFile(p); } catch (e) {} }

  function sendFrame(rgba, w, h) {
    var cb = $('crLive');
    if ((!cb || !cb.checked) || !state.info) return;
    var L = state.live;
    if (!L) {
      L = { on: false, starting: true, inflight: true, pending: false, n: 0, stamp: new Date().getTime(), last: null, cv: null };
      state.live = L;
      var firstPath = writeFrame(rgba, w, h);
      if (!firstPath) { state.live = null; return; }
      hostEval('AIArtboardStudio.liveBegin(' + jsq(firstPath) + ',' + JSON.stringify(state.info.bounds) + ')', function (ok, msg) {
        L.starting = false; L.inflight = false;
        if (!ok) {
          dropFile(firstPath);
          if (state.live === L) state.live = null;
          $('crWorkspace').classList.remove('live-on'); liveLabel(false);
          return;
        }
        L.on = true; L.last = firstPath;
        $('crWorkspace').classList.add('live-on'); liveLabel(true);
        if (L.pending) { L.pending = false; window.setTimeout(schedule, 30); }
      }, 10000);
      return;
    }
    if (L.starting || L.inflight || !L.on) { L.pending = true; return; }
    var path = writeFrame(rgba, w, h);
    if (!path) { stopLive('تعذّرت كتابة إطار المعاينة؛ استمر التعديل داخل اللوحة فقط.'); return; }
    L.inflight = true; L.pending = false;
    hostEval('AIArtboardStudio.liveFrame(' + jsq(path) + ')', function (ok, msg) {
      L.inflight = false; dropFile(L.last); L.last = path;
      if (!ok) { stopLive('توقفت المعاينة المباشرة: ' + msg + ' — يمكنك متابعة التعديل داخل اللوحة ثم «تطبيق».'); return; }
      if (L.pending) { L.pending = false; if (state.comparing && state.prevSrc) sendFrame(state.prevSrc.data, state.prevSrc.width, state.prevSrc.height); else window.setTimeout(schedule, 50); }
    });
  }

  function startLive(done) {
    state.live = null;
    try {
      var cb = $('crLive');
      if (!cb || !cb.checked || !state.prevSrc || !state.info) { $('crWorkspace').classList.remove('live-on'); liveLabel(false); return done && done(false); }
      var L = { on: false, starting: true, inflight: true, pending: false, n: 0, stamp: new Date().getTime(), last: null, cv: null };
      state.live = L;
      var path = writeFrame(state.prevSrc.data, state.prevSrc.width, state.prevSrc.height);
      if (!path) { state.live = null; return done && done(false); }
      hostEval('AIArtboardStudio.liveBegin(' + jsq(path) + ',' + JSON.stringify(state.info.bounds) + ')', function (ok, msg) {
        L.starting = false; L.inflight = false;
        if (!ok) {
          dropFile(path);
          if (state.live === L) state.live = null;
          $('crWorkspace').classList.remove('live-on');
          status('تعذّر بدء المعاينة على الصورة (' + msg + ')؛ سيتم التعديل داخل اللوحة.', 'error');
          return done && done(false);
        }
        L.on = true; L.last = path; $('crWorkspace').classList.add('live-on'); liveLabel(true); if (done) done(true);
      }, 10000);
    } catch (e) {
      state.live = null;
      $('crWorkspace').classList.remove('live-on');
      liveLabel(false);
      if (done) done(false);
    }
  }

  /* leaves the session (restores the original image); cb(ok) */
  function endLive(cb) {
    var L = state.live; state.live = null; window.clearTimeout(state.settleTimer);
    $('crWorkspace').classList.remove('live-on'); liveLabel(false);
    if (!L || (!L.on && !L.starting)) { if (L) dropFile(L.last); return cb && cb(true); }
    hostEval('AIArtboardStudio.liveEnd()', function (ok, msg) {
      dropFile(L.last);
      if (ok && state.info) { try { var r = JSON.parse(msg); if (r && r.bounds && r.bounds.length === 4) state.info.bounds = r.bounds; } catch (e) {} }
      if (cb) cb(ok, msg);
    }, 10000);
  }
  function stopLive(msg) { endLive(function () { status(msg, 'error'); }); }

  function showOriginal(on) {
    if (!state.prevSrc) return;
    state.comparing = !!on;
    if (on) {
      if (state.live && state.live.on) sendFrame(state.prevSrc.data, state.prevSrc.width, state.prevSrc.height);
    } else { render(); schedule(); }
  }

  function detectAlpha(id) {
    var d = id.data, n = d.length, step = Math.max(4, ((n / 4 / 2000) | 0) * 4);
    for (var i = 3; i < n; i += step) if (d[i] < 252) return true;
    return false;
  }

  function pathToFileUrl(fsPath) {
    var p = String(fsPath || '').replace(/\\/g, '/');
    if (!p) return '';
    if (p.charAt(0) !== '/') p = '/' + p;
    return 'file://' + encodeURI(p).replace(/#/g, '%23').replace(/\?/g, '%3F');
  }

  /* ---------- loading the selected image ---------- */
  function reset(clearImage) {
    state.params = E.defaults(); if (clearImage) { state.full = null; state.prevCtx = null; state.prevSrc = null; state.info = null; }
    syncUI(); var ps = $('crPreset'); if (ps) ps.value = 'none';
  }

  /* acquires the selected image directly (disk file when possible, otherwise fast host proxy export) and decodes it */
  function exportAndDecode(ppi, maxSide, cb) {
    var timeoutMs = maxSide > 1600 ? 45000 : 18000;
    hostEval('AIArtboardStudio.exportImageForEdit(' + ppi + ',' + maxSide + ')', function (ok, body) {
      if (!ok) return cb(body);
      var info; try { info = JSON.parse(body); } catch (e) { return cb('استجابة غير مفهومة من Illustrator.'); }
      var filePath = info.path;
      var removeAfterDecode = !info.isDirect;
      var settled = false, decodeTimer = 0;

      function doneOnce(err, outInfo, imgData) {
        if (settled) return;
        settled = true;
        if (decodeTimer) { window.clearTimeout(decodeTimer); decodeTimer = 0; }
        if (removeAfterDecode) dropFile(filePath);
        cb(err, outInfo, imgData);
      }

      function finishDecode(img) {
        if (settled) return;
        try {
          var w = img.naturalWidth, h = img.naturalHeight;
          if (!w || !h) return doneOnce('أبعاد الصورة غير صالحة للقراءة.');
          var targetW = w, targetH = h;
          if (maxSide > 0 && Math.max(w, h) > maxSide) {
            var s = maxSide / Math.max(w, h);
            targetW = Math.max(1, Math.round(w * s));
            targetH = Math.max(1, Math.round(h * s));
          }
          var cv = document.createElement('canvas'); cv.width = targetW; cv.height = targetH;
          var g = cv.getContext('2d'); g.imageSmoothingQuality = 'high';
          g.drawImage(img, 0, 0, targetW, targetH);
          var id = g.getImageData(0, 0, targetW, targetH);
          doneOnce(null, info, id);
        } catch (e2) {
          doneOnce('تعذّر فتح الصورة: ' + (e2.message || e2));
        }
      }

      function decodeViaBase64(allowFileFallback) {
        if (settled) return;
        if (decodeTimer) { window.clearTimeout(decodeTimer); decodeTimer = 0; }
        try {
          var rd = window.cep.fs.readFile(filePath, window.cep.encoding.Base64);
          if (!rd || rd.err !== 0 || !rd.data) {
            if (allowFileFallback) return decodeViaFileUrl(false);
            return doneOnce('تعذّرت قراءة الصورة (رمز ' + (rd && rd.err) + ').');
          }
          var ext = String(filePath).toLowerCase().split('.').pop();
          var mime = (ext === 'jpg' || ext === 'jpeg') ? 'image/jpeg' : (ext === 'webp' ? 'image/webp' : (ext === 'gif' ? 'image/gif' : 'image/png'));
          var img2 = new Image();
          decodeTimer = window.setTimeout(function () {
            if (allowFileFallback) decodeViaFileUrl(false);
            else doneOnce('انتهت مهلة فك ترميز الصورة.');
          }, 5500);
          img2.onload = function () { finishDecode(img2); };
          img2.onerror = function () {
            if (allowFileFallback) decodeViaFileUrl(false);
            else doneOnce('تعذّر فك ترميز الصورة.');
          };
          img2.src = 'data:' + mime + ';base64,' + rd.data;
        } catch (e3) {
          if (allowFileFallback) decodeViaFileUrl(false);
          else doneOnce('تعذّرت قراءة الصورة: ' + (e3.message || e3));
        }
      }

      function decodeViaFileUrl(allowB64Fallback) {
        if (settled) return;
        if (decodeTimer) { window.clearTimeout(decodeTimer); decodeTimer = 0; }
        try {
          var img = new Image();
          decodeTimer = window.setTimeout(function () {
            if (allowB64Fallback) decodeViaBase64(false);
            else doneOnce('انتهت مهلة تحميل ملف الصورة.');
          }, 3000);
          img.onload = function () { finishDecode(img); };
          img.onerror = function () {
            if (allowB64Fallback) decodeViaBase64(false);
            else doneOnce('تعذّر تحميل ملف الصورة.');
          };
          img.src = pathToFileUrl(filePath);
        } catch (e4) {
          if (allowB64Fallback) decodeViaBase64(false);
          else doneOnce('تعذّر تحميل ملف الصورة: ' + (e4.message || e4));
        }
      }

      // Always decode via native CEP readFile(Base64) first so CEP file:// security/encoding never stalls.
      decodeViaBase64(true);
    }, timeoutMs);
  }

  function loadImage() {
    if (state.busy) return;
    ABSBusy.hide();
    if (window.ABSSession.owner && window.ABSSession.owner !== 'cr') { status('أنهِ أو ألغِ جلسة «تحويل الصورة» أولًا ثم ابدأ هنا.', 'error'); return; }
    if (state.live) { endLive(function () { loadImage(); }); return; }
    if (!fsOk()) { status('هذه الميزة تعمل داخل Illustrator فقط (لا يتوفر الوصول إلى الملفات المؤقتة).', 'error'); return; }
    var ppi = parseFloat($('crPpi').value); if (!isFinite(ppi) || ppi < 36 || ppi > 600) { status('أدخل دقة بين 36 و600 ppi.', 'error'); return; }
    if ($('crLive')) $('crLive').checked = true;
    state.busy = true; $('crLoad').disabled = true;
    status('جارٍ فتح أدوات تعديل الصورة المحددة…');
    exportAndDecode(ppi, PROXY_MAX, function (err, info, id) {
      if (err) return fail(err);
      try {
        var w = id.width, h = id.height;
        state.full = id;
        state.hasAlpha = detectAlpha(id);
        var f = Math.min(1, PREVIEW_MAX / Math.max(w, h)), pw = Math.max(1, Math.round(w * f)), ph = Math.max(1, Math.round(h * f));
        if (f < 1) {
          var cv = document.createElement('canvas'); cv.width = w; cv.height = h; cv.getContext('2d').putImageData(id, 0, 0);
          var pc = document.createElement('canvas'); pc.width = pw; pc.height = ph;
          var pg = pc.getContext('2d'); pg.imageSmoothingQuality = 'high'; pg.drawImage(cv, 0, 0, pw, ph);
          state.prevSrc = pg.getImageData(0, 0, pw, ph);
        } else {
          state.prevSrc = id;
        }
        state.prevCtx = E.createContext(state.prevSrc, { fullMax: Math.max(w, h) });
        state.info = info;
        if ($('crPpiInfo')) $('crPpiInfo').textContent = info.name + ' — تعديل مباشر على Illustrator';
        state.hiCtx = null; state.comparing = false; state.live = null;
        reset(false);
        var ws = $('crWorkspace');
        ws.classList.remove('hidden');
        var liveOn = !!($('crLive') && $('crLive').checked);
        ws.classList.toggle('live-on', liveOn);
        liveLabel(liveOn);
        window.ABSSession.owner = 'cr';
      } catch (err2) { return fail('تعذّر بدء التعديل: ' + (err2.message || err2)); }
      ABSBusy.hide(); state.busy = false; $('crLoad').disabled = false;
      status('التعديل المباشر نشط: حرّك الأشرطة وشاهد النتيجة فورًا على الصورة داخل Illustrator.', 'success');
      kickPaint();
    });
    function fail(msg) { ABSBusy.hide(); state.busy = false; $('crLoad').disabled = false; status(msg, 'error'); kickPaint(); }
  }

  /* ---------- applying the result back to Illustrator ---------- */
  function applyToIllustrator() {
    if (state.busy || !state.full || !state.info) return;
    if (E.isNeutral(state.params)) { status('لم تُجرِ أي تعديل بعد.', 'error'); return; }
    var mode = $('crMode').value;
    if (mode === 'replace' && !ABSDialog.gate('crApply', 'سيُستبدل الأصل بنسخة معدّلة مضمّنة في الملف (لا يتغير الملف الأصلي على القرص، ويمكنك التراجع بـ Ctrl+Z). هل تريد المتابعة؟', applyToIllustrator, { title: 'تطبيق التعديل', ok: 'تطبيق' })) return;
    state.busy = true; $('crApply').disabled = true; $('crLoad').disabled = true; $('crCancel').disabled = true;
    status('جارٍ تطبيق التعديلات بالدقة الكاملة…');
    ABSBusy.show('جارٍ تطبيق التعديلات على الصورة…');
    var hadLive = !!state.live, ppi = parseFloat($('crPpi').value) || 300, params = JSON.parse(JSON.stringify(state.params)), outPath = state.info.outPath;
    endLive(function () {
      status('جارٍ تجهيز الدقة الكاملة…');
      window.setTimeout(function () {
        exportAndDecode(ppi, 4096, function (err, info, full) {
          if (err) return finish(false, err);
          state.info.bounds = info.bounds; status('جارٍ تطبيق التعديلات بالدقة الكاملة…');
          window.setTimeout(function () { run(full, params); }, 16);
        });
      }, 16);
    });
    function run(full, params) {
      try {
        var ctx = E.createContext(full, { noCache: true, fullMax: Math.max(full.width, full.height) });
        var out = E.process(ctx, params);
        var cv = document.createElement('canvas'); cv.width = full.width; cv.height = full.height;
        cv.getContext('2d').putImageData(new ImageData(out, full.width, full.height), 0, 0);
        var b64 = cv.toDataURL('image/png').split(',')[1];
        var wr = window.cep.fs.writeFile(outPath, b64, window.cep.encoding.Base64);
        if (!wr || wr.err !== 0) throw new Error('تعذّرت كتابة الملف المؤقت (رمز ' + (wr && wr.err) + ').');
      } catch (e) { return finish(false, 'فشلت المعالجة: ' + (e.message || e)); }
      hostEval('AIArtboardStudio.applyEditedImage(' + jsq(outPath) + ',' + JSON.stringify(state.info.bounds) + ',' + jsq(mode) + ')', function (ok, msg) {
        dropFile(outPath);
        finish(ok, msg);
      }, 60000);
    }
    function finish(ok, msg) {
      ABSBusy.hide();
      state.busy = false; $('crApply').disabled = false; $('crLoad').disabled = false; $('crCancel').disabled = false;
      if (ok) { state.full = null; state.prevCtx = null; state.prevSrc = null; state.info = null; state.hiCtx = null; $('crWorkspace').classList.add('hidden'); status(msg, 'success'); }
      else if (hadLive) { status(msg + ' — أُعيدت المعاينة المباشرة.', 'error'); startLive(function () { schedule(); }); }
      else status(msg, 'error');
    }
  }

  /* ---------- wiring ---------- */
  function init() {
    if (!$('panel-cr') || $('panel-cr').getAttribute('data-ready')) return;
    $('panel-cr').setAttribute('data-ready', '1');
    buildUI();
    var sel = $('crPreset');
    E.presets.forEach(function (p) { var o = document.createElement('option'); o.value = p.id; o.textContent = p.name; sel.appendChild(o); });
    sel.addEventListener('change', function () {
      var p = E.presets.filter(function (x) { return x.id === sel.value; })[0];
      state.params = E.normalize(p ? p.params : {}); syncUI(); schedule();
    });
    $('crAuto').addEventListener('click', function () {
      if (!state.prevSrc) return; state.params = E.normalize(E.autoParams(state.prevSrc)); syncUI(); sel.value = 'none'; schedule();
    });
    $('crReset').addEventListener('click', function () { reset(false); schedule(); });
    ['crCompare', 'crCompare2'].forEach(function (id) { var cmp = $(id);
      ['mousedown', 'touchstart'].forEach(function (ev) { cmp.addEventListener(ev, function (e) { e.preventDefault(); showOriginal(true); }); });
      ['mouseup', 'mouseleave', 'touchend', 'touchcancel'].forEach(function (ev) { cmp.addEventListener(ev, function () { showOriginal(false); }); }); });
    $('crLoad').addEventListener('click', loadImage);
    try { new MutationObserver(function () { var h = $('crWorkspace').classList.contains('hidden'); $('crCancel').classList.toggle('hidden', h); if (h && window.ABSSession.owner === 'cr') window.ABSSession.owner = null; }).observe($('crWorkspace'), { attributes: true, attributeFilter: ['class'] }); } catch (e) {}
    $('crCancel').addEventListener('click', function () {
      if (state.busy) return;
      endLive(function () { state.full = null; state.prevCtx = null; state.prevSrc = null; state.info = null; state.hiCtx = null; $('crWorkspace').classList.add('hidden'); status('أُلغي التعديل وأُعيدت الصورة الأصلية كما كانت.', 'success'); });
    });
    $('crLive').addEventListener('change', function () {
      if (!state.prevSrc || state.busy) return;
      if (this.checked) startLive(function (ok) { if (ok) { schedule(); status('المعاينة المباشرة تعمل.', 'success'); } });
      else endLive(function () { status('أُوقف التحديث المباشر؛ حرّك الإعدادات ثم اضغط «تطبيق» لتحديث الصورة في Illustrator.', 'success'); });
    });
    window.addEventListener('beforeunload', function () { if (state.live && state.live.on) { try { window.__adobe_cep__.evalScript('AIArtboardStudio.liveEnd()'); } catch (e) {} } });
    $('crApply').addEventListener('click', applyToIllustrator);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
  window.ABSCRShared = { hostEval: hostEval, jsq: jsq, exportAndDecode: exportAndDecode, fsOk: fsOk, dropFile: dropFile, detectAlpha: detectAlpha };
  window.ABSCameraRawUI = { _state: state, _render: render, _settle: settle, loadImage: loadImage, apply: applyToIllustrator, cancel: function () { $('crCancel').click(); } };
}());