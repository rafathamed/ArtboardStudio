(function () {
  'use strict';
  var config = window.ARTBOARD_STUDIO_LICENSE_CONFIG || {};
  var baseUrl = String(config.serverUrl || '').replace(/\/+$/, '');
  var product = config.product || 'artboard-studio';
  var TOKEN_KEY = 'artboardStudio.licenseToken.v1';
  var DEVICE_KEY = 'artboardStudio.deviceId.v1';
  var STAMP_KEY = 'artboardStudio.lastVerified.v1';
  var OFFLINE_GRACE_MS = 14 * 24 * 3600 * 1000; // an already-activated device keeps working this long without reaching the server
  var $ = function (id) { return document.getElementById(id); };

  function status(message, kind) {
    var el = $('licenseStatus');
    if (!el) return;
    el.className = 'license-status' + (kind ? ' ' + kind : '');
    var raw = message || '';
    el.setAttribute('data-i18n-ar', raw);
    el.textContent = (window.ABSi18n && raw) ? window.ABSi18n.tr(raw) : raw;
  }
  function isLocalServer() {
    return /^https?:\/\/(127\.0\.0\.1|localhost)(:\d+)?$/i.test(baseUrl);
  }
  function serverHint() {
    var el = $('licenseServerHint');
    if (el) el.textContent = 'Server: ' + (baseUrl || 'لم يتم ضبط الرابط');
  }
  function connectionHelp() {
    if (isLocalServer()) {
      return 'خادم التفعيل المحلي غير متاح. شغّل start_windows.bat من مجلد Licensing_Admin\\server على نفس الكمبيوتر، واترك نافذة الخادم مفتوحة. ثم اختبر: ' + baseUrl + '/health';
    }
    return 'تعذّر الوصول إلى خادم التفعيل. تأكد من صحة رابط الخادم، وأنه يعمل عبر HTTPS، وأن المسار /health متاح.';
  }
  function randomId() {
    var bytes = new Uint8Array(16);
    try {
      if (window.crypto && window.crypto.getRandomValues) window.crypto.getRandomValues(bytes);
      else throw new Error('no crypto');
      var out = '';
      for (var i = 0; i < bytes.length; i++) out += ('0' + bytes[i].toString(16)).slice(-2);
      return out;
    } catch (e) {
      return String(new Date().getTime()) + '-' + String(Math.random()).slice(2) + '-' + String(Math.random()).slice(2);
    }
  }
  function deviceId() {
    try {
      var existing = localStorage.getItem(DEVICE_KEY);
      if (existing) return existing;
      var created = randomId();
      localStorage.setItem(DEVICE_KEY, created);
      return created;
    } catch (e) { return randomId(); }
  }
  function netErr(msg) { var e = new Error(msg); e.network = true; return e; }
  function readStamp() { try { return parseInt(localStorage.getItem(STAMP_KEY) || '0', 10) || 0; } catch (e) { return 0; } }
  function writeStamp(t) { try { localStorage.setItem(STAMP_KEY, String(t)); } catch (e) {} }
  function request(path, payload, callback) {
    if (!baseUrl || baseUrl.indexOf('YOUR_') >= 0) {
      callback(new Error('لم يتم إعداد رابط خادم التفعيل. راجع ملف license-config.js.'));
      return;
    }
    var xhr = new XMLHttpRequest();
    xhr.open('POST', baseUrl + path, true);
    xhr.timeout = 10000;
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onreadystatechange = function () {
      if (xhr.readyState !== 4) return;
      var data = {};
      try { data = JSON.parse(xhr.responseText || '{}'); } catch (e) {}
      if (xhr.status >= 200 && xhr.status < 300 && data.ok) callback(null, data);
      else if (xhr.status === 0) callback(netErr(connectionHelp()));
      else if (xhr.status >= 500) callback(netErr('الخادم غير متاح مؤقتًا (HTTP ' + xhr.status + ').'));
      else callback(new Error(data.message || ('تعذّر التحقق من السريال (HTTP ' + xhr.status + '). تحقق من مسارات API في الخادم.')));
    };
    xhr.onerror = function () { callback(netErr(connectionHelp())); };
    xhr.ontimeout = function () { callback(netErr('انتهت مهلة الاتصال بخادم التفعيل بعد 10 ثوانٍ. ' + connectionHelp())); };
    try { xhr.send(JSON.stringify(payload)); }
    catch (e) { callback(new Error('تعذّر إرسال طلب التفعيل: ' + (e.message || e))); }
  }
  function healthCheck() {
    var button = $('checkLicenseServer');
    if (button) button.disabled = true;
    status('جارٍ اختبار الاتصال بخادم التفعيل…', '');
    if (!baseUrl) {
      status('رابط خادم التفعيل غير مضبوط. راجع license-config.js.', 'error');
      if (button) button.disabled = false;
      return;
    }
    var xhr = new XMLHttpRequest();
    xhr.open('GET', baseUrl + '/health', true);
    xhr.timeout = 8000;
    xhr.onreadystatechange = function () {
      if (xhr.readyState !== 4) return;
      if (button) button.disabled = false;
      var data = {};
      try { data = JSON.parse(xhr.responseText || '{}'); } catch (e) {}
      if (xhr.status >= 200 && xhr.status < 300 && data.ok && data.product === product) {
        status('الاتصال ناجح. خادم Artboard Studio يعمل ويمكن متابعة التفعيل.', 'success');
      } else if (xhr.status === 0) {
        status(connectionHelp(), 'error');
      } else {
        status('تم الوصول إلى العنوان لكن استجابة الخادم غير صحيحة (HTTP ' + xhr.status + '). تأكد أنك تستخدم خادم Artboard Studio الصحيح.', 'error');
      }
    };
    xhr.onerror = function () {
      if (button) button.disabled = false;
      status(connectionHelp(), 'error');
    };
    xhr.ontimeout = function () {
      if (button) button.disabled = false;
      status('انتهت مهلة اختبار الخادم. ' + connectionHelp(), 'error');
    };
    try { xhr.send(null); }
    catch (e) {
      if (button) button.disabled = false;
      status('تعذّر بدء اختبار الاتصال: ' + (e.message || e), 'error');
    }
  }
  var _sessionUnlocked = false;
  var _sessionToken = '';

  function __absGetHostJsxPath() {
    try {
      var p = decodeURIComponent(String(window.location.pathname || '')).replace(/\\/g, '/');
      if (/^\/[A-Za-z]:\//.test(p)) p = p.slice(1);
      return p.replace(/\/[^\/]*$/, '/host/host.jsx');
    } catch (e) { return ''; }
  }

  function __absUnlockBridge() {
    if (!_sessionUnlocked || !_sessionToken) return;
    try {
      if (window.__adobe_cep__ && typeof window.__adobe_cep__.evalScript === 'function') {
        if (!window.__adobe_cep__.__absWrapped) {
          var origEval = window.__adobe_cep__.evalScript.bind(window.__adobe_cep__);
          window.__adobe_cep__.evalScript = function (expr, cb) {
            var prefix = '';
            if (_sessionUnlocked && _sessionToken && String(expr || '').indexOf('AIArtboardStudio.') >= 0 && String(expr || '').indexOf('AIArtboardStudio._unlock') < 0) {
              var hp = __absGetHostJsxPath();
              var loadGuard = hp ? ('if((typeof AIArtboardStudio==="undefined"||AIArtboardStudio._buildVersion!=="1.12.2")&&typeof $!=="undefined"&&$.evalFile){try{$.evalFile(' + JSON.stringify(hp) + ');}catch(_e){}} ') : '';
              prefix = loadGuard + 'AIArtboardStudio._unlock(' + JSON.stringify(_sessionToken) + '); ';
            }
            return origEval(prefix + expr, cb);
          };
          window.__adobe_cep__.__absWrapped = true;
        }
        var hp0 = __absGetHostJsxPath();
        var initGuard = hp0 ? ('if((typeof AIArtboardStudio==="undefined"||AIArtboardStudio._buildVersion!=="1.12.2")&&typeof $!=="undefined"&&$.evalFile){try{$.evalFile(' + JSON.stringify(hp0) + ');}catch(_e){}} ') : '';
        window.__adobe_cep__.evalScript(initGuard + 'AIArtboardStudio._unlock(' + JSON.stringify(_sessionToken) + ')');
      }
    } catch (e) {}
  }

  function enforceLicenseSurface() {
    var gate = $('licenseGate'), app = $('appRoot');
    if (!_sessionUnlocked) {
      window.ArtboardStudioLicensed = false;
      if (app && !app.classList.contains('hidden')) app.classList.add('hidden');
      if (gate && gate.classList.contains('hidden')) gate.classList.remove('hidden');
    }
  }

  function showApp(token, offline) {
    if (!token || String(token).length < 8) return;
    _sessionToken = String(token);
    _sessionUnlocked = true;
    try { localStorage.setItem(TOKEN_KEY, token); } catch (e) {}
    if (!offline) writeStamp(Date.now());
    window.ArtboardStudioLicensed = true;
    __absUnlockBridge();
    var gate = $('licenseGate'), app = $('appRoot');
    if (gate) gate.classList.add('hidden');
    if (app) app.classList.remove('hidden');
    dismissBootSplash();
    var raf = window.requestAnimationFrame || function (fn) { window.setTimeout(fn, 16); };
    raf(function () { raf(function () { if (window.ArtboardStudioRefresh) window.setTimeout(window.ArtboardStudioRefresh, 120); }); });
  }

  function dismissBootSplash() { var splash = $('bootSplash'); if (splash) splash.classList.add('hidden'); }

  function ensureStartupSurface() {
    var gate = $('licenseGate'), app = $('appRoot');
    if (_sessionUnlocked && window.ArtboardStudioLicensed) {
      if (gate) gate.classList.add('hidden');
      if (app) app.classList.remove('hidden');
    } else {
      if (app) app.classList.add('hidden');
      if (gate) gate.classList.remove('hidden');
    }
    dismissBootSplash();
  }

  function verifyCached() {
    var token = '';
    try { token = localStorage.getItem(TOKEN_KEY) || ''; } catch (e) {}
    if (!token) {
      status('أدخل السريال ثم اضغط تفعيل. استخدم اختبار الاتصال عند ظهور مشكلة في الخادم.', '');
      return;
    }
    var now = Date.now(), last = readStamp();
    if (!last) { last = now; writeStamp(now); }
    var withinGrace = (now >= last - 3600000 && now - last <= OFFLINE_GRACE_MS);
    if (withinGrace) {
      showApp(token, true);
    } else {
      status('جارٍ التحقق من الترخيص…', '');
    }
    window.setTimeout(function () {
      request('/api/verify', { token: token, deviceId: deviceId(), product: product }, function (err, result) {
        if (err) {
          if (err.network) {
            if (withinGrace) { scheduleRecheck(token); return; }
            status('انتهت مدة العمل بدون إنترنت (14 يومًا). اتصل بالإنترنت مرة واحدة للتحقق من الترخيص.', 'error'); return;
          }
          try { localStorage.removeItem(TOKEN_KEY); localStorage.removeItem(STAMP_KEY); } catch (e) {}
          window.ArtboardStudioLicensed = false;
          ensureStartupSurface();
          status(err.message, 'error'); return;
        }
        writeStamp(Date.now());
        if (!withinGrace) showApp(result.token || token);
        else if (result && result.token) {
          try { localStorage.setItem(TOKEN_KEY, result.token); } catch (e) {}
        }
      });
    }, 150);
  }
  function scheduleRecheck(token) {
    window.setTimeout(function () {
      request('/api/verify', { token: token, deviceId: deviceId(), product: product }, function (err, result) {
        if (!err) { writeStamp(Date.now()); if (result && result.token) { try { localStorage.setItem(TOKEN_KEY, result.token); } catch (e) {} } return; }
        if (err.network) { scheduleRecheck(token); return; }
        try { localStorage.removeItem(TOKEN_KEY); localStorage.removeItem(STAMP_KEY); } catch (e) {}   // server explicitly rejected the licence
        window.location.reload();
      });
    }, 120000);
  }
  function activate() {
    var button = $('activateLicense');
    var input = $('licenseKey');
    var key = String(input && input.value || '').toUpperCase().replace(/\s+/g, '');
    if (!key) { status('أدخل سريال التفعيل أولًا.', 'error'); return; }
    if (!/^AS26-(?:[A-Z2-9]{4}-){5}[A-Z2-9]{4}$/.test(key)) {
      status('صيغة السريال غير صحيحة. تأكد من نسخه كاملًا.', 'error'); return;
    }
    if (button) button.disabled = true;
    status('جارٍ تفعيل السريال وربطه بهذا الجهاز…', '');
    request('/api/activate', { key: key, deviceId: deviceId(), product: product, build: window.ARTBOARD_STUDIO_BUILD || '1.12.1' }, function (err, result) {
      if (button) button.disabled = false;
      if (err) { status(err.message, 'error'); return; }
      status('تم تفعيل Artboard Studio بنجاح.', 'success');
      showApp(result.token);
    });
  }
  function cleanKeyText(val) {
    return String(val || '').replace(/[\r\n\s]+/g, '').toUpperCase();
  }
  function copySerialFromInput() {
    var input = $('licenseKey');
    var val = String(input && input.value || '').trim();
    if (!val) { status('لا يوجد سريال لنسخه.', 'error'); return; }
    var ok = false;
    try {
      input.focus();
      input.select();
      if (input.setSelectionRange) input.setSelectionRange(0, val.length);
      ok = !!document.execCommand('copy');
    } catch (e) {}
    if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
      navigator.clipboard.writeText(val).then(function () {
        status('تم نسخ السريال.', 'success');
      }, function () {
        status(ok ? 'تم نسخ السريال.' : 'تعذّر نسخ السريال تلقائيًا — اضغط Ctrl+C.', ok ? 'success' : 'error');
      });
    } else {
      status(ok ? 'تم نسخ السريال.' : 'تعذّر نسخ السريال تلقائيًا — اضغط Ctrl+C.', ok ? 'success' : 'error');
    }
  }
  function applyPastedSerial(raw) {
    var input = $('licenseKey');
    var cleaned = cleanKeyText(raw);
    if (!cleaned) { status('الحافظة فارغة أو لا تحتوي نصًا.', 'error'); return false; }
    if (input) {
      input.value = cleaned;
      input.focus();
    }
    status('تم لصق السريال بنجاح.', 'success');
    return true;
  }
  function execPasteFallback() {
    try {
      var ta = document.createElement('textarea');
      ta.style.cssText = 'position:fixed;left:-9999px;top:0;opacity:0;';
      document.body.appendChild(ta);
      ta.focus();
      var ok = document.execCommand('paste');
      var txt = ta.value;
      document.body.removeChild(ta);
      if (ok && txt) return txt;
    } catch (e) {}
    return '';
  }
  function pasteSerialToInput() {
    var input = $('licenseKey');
    if (navigator.clipboard && typeof navigator.clipboard.readText === 'function') {
      navigator.clipboard.readText().then(function (txt) {
        if (txt) { applyPastedSerial(txt); return; }
        var fb = execPasteFallback();
        if (fb) applyPastedSerial(fb);
        else status('الحافظة فارغة.', 'error');
      }, function () {
        var fb = execPasteFallback();
        if (fb) applyPastedSerial(fb);
        else {
          if (input) { input.focus(); input.select(); }
          status('الحافظة محمية في المتصفح — اضغط Ctrl+V (أو Cmd+V) داخل الخانة.', 'error');
        }
      });
    } else {
      var fb = execPasteFallback();
      if (fb) applyPastedSerial(fb);
      else {
        if (input) { input.focus(); input.select(); }
        status('اضغط Ctrl+V (أو Cmd+V) للصق السريال داخل الخانة.', 'error');
      }
    }
  }
  function init() {
    var activateButton = $('activateLicense');
    if (activateButton) activateButton.addEventListener('click', activate);
    var pasteBtn = $('pasteLicenseBtn');
    if (pasteBtn) pasteBtn.addEventListener('click', pasteSerialToInput);
    var pasteInline = $('pasteLicenseInline');
    if (pasteInline) pasteInline.addEventListener('click', pasteSerialToInput);
    var copyInline = $('copyLicenseInline');
    if (copyInline) copyInline.addEventListener('click', copySerialFromInput);
    var healthButton = $('checkLicenseServer');
    if (healthButton) healthButton.addEventListener('click', healthCheck);
    var purchaseLink = $('purchaseWhatsApp');
    if (purchaseLink) purchaseLink.addEventListener('click', function (event) {
      event.preventDefault();
      var targetUrl = this.getAttribute('href');
      try {
        if (window.cep && window.cep.util && typeof window.cep.util.openURLInDefaultBrowser === 'function') {
          window.cep.util.openURLInDefaultBrowser(targetUrl); return;
        }
      } catch (e) {}
      window.open(targetUrl, '_blank');
    });
    var keyInput = $('licenseKey');
    if (keyInput) keyInput.addEventListener('keydown', function (event) { if (event.key === 'Enter') activate(); });
    serverHint();
    window.setInterval(enforceLicenseSurface, 600);
    verifyCached();
    ensureStartupSurface();
    window.setTimeout(ensureStartupSurface, 1200);
    window.addEventListener('pageshow', function () { ensureStartupSurface(); });
  }
  var licenseInitialized = false;
  function startLicense() {
    if (licenseInitialized) return;
    licenseInitialized = true;
    init();
  }
  if (document.readyState === 'complete') startLicense();
  else {
    window.addEventListener('load', startLicense);
    document.addEventListener('DOMContentLoaded', function () { window.setTimeout(startLicense, 80); });
    window.setTimeout(startLicense, 900);
  }
}());