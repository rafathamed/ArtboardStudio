/* Artboard Studio host bridge for Adobe Illustrator (ExtendScript / ES3). */
#target illustrator

if (typeof $ !== 'undefined' && $.global && $.global.AIArtboardStudio) {
    var AIArtboardStudio = $.global.AIArtboardStudio;
} else if (typeof AIArtboardStudio === 'undefined') {
    var AIArtboardStudio = {};
}
if (typeof $ !== 'undefined' && $.global) {
    $.global.AIArtboardStudio = AIArtboardStudio;
}

AIArtboardStudio._unlocked = false;
AIArtboardStudio._unlock = function (token) {
    var t = String(token || '');
    if (t.length >= 8) {
        AIArtboardStudio._unlocked = true;
        return 'OK|1';
    }
    return 'ERR|0';
};
AIArtboardStudio._buildVersion = '1.12.2';

AIArtboardStudio._result = function (ok, message) {
    var s = String(message || '').replace(/[\r\n]+/g, ' ');
    return (ok ? 'OK|' : 'ERR|') + s;
};

AIArtboardStudio._doc = function () {
    if (!AIArtboardStudio._unlocked) throw new Error('يجب تفعيل الإضافة بالسريال أولًا لإتمام هذه العملية.');
    if (app.documents.length < 1) throw new Error('افتح مستندًا في Illustrator أولًا.');
    return app.activeDocument;
};

AIArtboardStudio._artboard = function (doc) {
    var index = doc.artboards.getActiveArtboardIndex();
    return doc.artboards[index].artboardRect;
};

AIArtboardStudio._itemBounds = function (item) {
    try { return item.visibleBounds; } catch (e1) {
        try { return item.geometricBounds; } catch (e2) {
            try { return item.controlBounds; } catch (e3) { return null; }
        }
    }
};

AIArtboardStudio._rectsIntersect = function (a, b) {
    if (!a || !b) return false;
    var eps = 0.05;
    return a[2] > b[0] + eps && a[0] < b[2] - eps && a[1] > b[3] + eps && a[3] < b[1] - eps;
};

AIArtboardStudio._rectInside = function (a, b) {
    if (!a || !b) return false;
    var eps = 0.25;
    return a[0] >= b[0] - eps && a[2] <= b[2] + eps && a[1] <= b[1] + eps && a[3] >= b[3] - eps;
};

AIArtboardStudio._quietStart = function () {
    var prev = null;
    try { prev = app.userInteractionLevel; app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS; } catch (e) {}
    return prev;
};

AIArtboardStudio._quietEnd = function (prev) {
    try { if (prev !== null && prev !== undefined) app.userInteractionLevel = prev; } catch (e) {}
};

AIArtboardStudio._directItems = function (layer) {
    var out = [];
    var items = layer.pageItems;
    for (var i = 0; i < items.length; i++) {
        var item = items[i];
        try {
            if (item.parent == layer && !item.guides) out.push(item);
        } catch (e) {}
    }
    return out;
};

AIArtboardStudio._collectLayers = function (layers, out) {
    for (var i = 0; i < layers.length; i++) {
        var layer = layers[i];
        out.push(layer);
        if (layer.layers && layer.layers.length) AIArtboardStudio._collectLayers(layer.layers, out);
    }
};

AIArtboardStudio._layerFromItem = function (item) {
    var current = item;
    while (current) {
        try {
            if (current.typename == 'Layer') return current;
            current = current.parent;
        } catch (e) { break; }
    }
    return null;
};

AIArtboardStudio._pushUniqueLayer = function (list, layer) {
    if (!layer || layer.typename != 'Layer') return;
    for (var i = 0; i < list.length; i++) if (list[i] == layer) return;
    list.push(layer);
};

/* scope='all': every document layer (including nested layers).
   scope='selected': the active layer plus layers containing selected artwork. */
AIArtboardStudio._targetLayers = function (doc, scope) {
    var all = [];
    AIArtboardStudio._collectLayers(doc.layers, all);
    scope = String(scope || 'all').toLowerCase();
    if (scope != 'selected') return all;

    var targets = [], foundSelectedArtwork = false;
    try {
        var selection = doc.selection;
        if (selection && typeof selection.length == 'number') {
            for (var i = 0; i < selection.length; i++) {
                var ownerLayer = AIArtboardStudio._layerFromItem(selection[i]);
                if (ownerLayer) {
                    AIArtboardStudio._pushUniqueLayer(targets, ownerLayer);
                    foundSelectedArtwork = true;
                }
            }
        }
    } catch (selectionError) {}

    /* If no artwork is selected, use the layer currently active in Illustrator. */
    if (!foundSelectedArtwork) {
        try { AIArtboardStudio._pushUniqueLayer(targets, doc.activeLayer); } catch (activeError) {}
    }

    if (!targets.length) throw new Error('لم يتم العثور على طبقة مستهدفة. حدد عناصر داخل الطبقات المطلوبة أو اختر الطبقة النشطة من لوحة Layers.');
    return targets;
};

/* Normalize a selected Illustrator object to the nearest editable object
   whose parent is a Layer or GroupItem. This keeps compound paths/text selections
   as one logical artwork item instead of targeting an internal sub-part. */
AIArtboardStudio._normalizeSelectedElement = function (item) {
    var current = item, guard = 0;
    while (current && guard++ < 60) {
        var parent = null;
        try { parent = current.parent; } catch (e) { return null; }
        if (!parent) return null;
        if (parent.typename == 'Layer' || parent.typename == 'GroupItem') return current;
        if (parent.typename == 'Document') return null;
        current = parent;
    }
    return null;
};

AIArtboardStudio._isDescendantOf = function (item, ancestor) {
    var current = null, guard = 0;
    try { current = item.parent; } catch (e) { return false; }
    while (current && guard++ < 60) {
        if (current == ancestor) return true;
        if (current.typename == 'Document' || current.typename == 'Layer') return false;
        try { current = current.parent; } catch (e2) { return false; }
    }
    return false;
};

AIArtboardStudio._addBatch = function (batches, parent, layer, item) {
    var batch = null;
    for (var i = 0; i < batches.length; i++) {
        if (batches[i].parent == parent) { batch = batches[i]; break; }
    }
    if (!batch) {
        batch = { parent: parent, layer: layer, items: [] };
        batches.push(batch);
    }
    for (var j = 0; j < batch.items.length; j++) if (batch.items[j] == item) return;
    batch.items.push(item);
};

/* scope='all': all top-level artwork objects in every document layer (nested
   groups remain intact as one object). scope='selected': only actual objects in
   doc.selection; no fallback to the active layer. Batches are split by parent
   container because Illustrator cannot safely group objects across containers. */
AIArtboardStudio._elementBatches = function (doc, scope, includeHidden) {
    var batches = [];
    scope = String(scope || 'all').toLowerCase();
    if (scope != 'selected') {
        var activeRect = AIArtboardStudio._artboard(doc);
        var allLayers = [];
        AIArtboardStudio._collectLayers(doc.layers, allLayers);
        for (var i = 0; i < allLayers.length; i++) {
            var layer = allLayers[i];
            if (AIArtboardStudio._shouldSkipLayer(layer, includeHidden)) continue;
            var items = AIArtboardStudio._directItems(layer);
            var activeItems = [];
            for (var vi = 0; vi < items.length; vi++) {
                var hiddenOrLocked = false;
                if (!includeHidden) {
                    try { if (items[vi].hidden || items[vi].locked) hiddenOrLocked = true; } catch (visibilityError) {}
                }
                if (hiddenOrLocked) continue;
                var ib = AIArtboardStudio._itemBounds(items[vi]);
                if (!AIArtboardStudio._rectsIntersect(ib, activeRect)) continue;
                activeItems.push(items[vi]);
            }
            if (activeItems.length) batches.push({ parent: layer, layer: layer, items: activeItems });
        }
        return batches;
    }

    var selection = null, selected = [];
    try { selection = doc.selection; } catch (selectionError) {}
    if (selection && selection.typename == 'TextRange') {
        /* Illustrator can return a TextRange instead of an array when text is active. */
        var textFrame = null;
        try { textFrame = selection.parent; } catch (textParentError) {}
        var textElement = textFrame ? AIArtboardStudio._normalizeSelectedElement(textFrame) : null;
        if (textElement) selected.push(textElement);
    } else if (selection && typeof selection.length == 'number') {
        for (var s = 0; s < selection.length; s++) {
            var normalized = AIArtboardStudio._normalizeSelectedElement(selection[s]);
            if (!normalized) continue;
            var duplicate = false;
            for (var d = 0; d < selected.length; d++) if (selected[d] == normalized) { duplicate = true; break; }
            if (!duplicate) selected.push(normalized);
        }
    } else if (selection && selection.typename) {
        var single = AIArtboardStudio._normalizeSelectedElement(selection);
        if (single) selected.push(single);
    }
    if (!selected.length) throw new Error('حدد عنصرًا واحدًا أو أكثر داخل مساحة العمل أولًا، ثم اختر «العناصر المحددة فقط».');

    /* If a selected group contains another selected object, process the group only. */
    var filtered = [];
    for (var a = 0; a < selected.length; a++) {
        var covered = false;
        for (var b = 0; b < selected.length; b++) {
            if (a != b && AIArtboardStudio._isDescendantOf(selected[a], selected[b])) { covered = true; break; }
        }
        if (!covered) filtered.push(selected[a]);
    }

    for (var k = 0; k < filtered.length; k++) {
        var element = filtered[k], parent = null, ownerLayer = null;
        try { parent = element.parent; } catch (parentError) {}
        ownerLayer = AIArtboardStudio._layerFromItem(element);
        if (!parent || !ownerLayer || (parent.typename != 'Layer' && parent.typename != 'GroupItem')) continue;
        AIArtboardStudio._addBatch(batches, parent, ownerLayer, element);
    }
    if (!batches.length) throw new Error('تعذّر تحديد عناصر قابلة للمعالجة. اختر عناصر رسومية مباشرة داخل لوحة الرسم.');
    return batches;
};

AIArtboardStudio._unlockBatchObjects = function (batch) {
    var refs = [], states = [];
    function add(ref) {
        if (!ref) return;
        for (var x = 0; x < refs.length; x++) if (refs[x] == ref) return;
        refs.push(ref);
    }
    add(batch.parent);
    for (var i = 0; i < batch.items.length; i++) add(batch.items[i]);
    for (var j = 0; j < refs.length; j++) {
        var ref = refs[j], state = { ref: ref, locked: null, hidden: null };
        try { if (typeof ref.locked == 'boolean') { state.locked = ref.locked; ref.locked = false; } } catch (lockError) {}
        try { if (typeof ref.hidden == 'boolean') { state.hidden = ref.hidden; ref.hidden = false; } } catch (hiddenError) {}
        states.push(state);
    }
    return states;
};

AIArtboardStudio._restoreBatchObjects = function (states) {
    for (var i = states.length - 1; i >= 0; i--) {
        var state = states[i];
        try { if (state.locked !== null) state.ref.locked = state.locked; } catch (lockError) {}
        try { if (state.hidden !== null) state.ref.hidden = state.hidden; } catch (hiddenError) {}
    }
};

AIArtboardStudio._shouldSkipLayer = function (layer, includeHidden) {
    if (includeHidden) return false;
    var current = layer;
    while (current && current.typename == 'Layer') {
        try { if (!current.visible || current.locked) return true; } catch (e) { return true; }
        current = current.parent;
    }
    return false;
};

AIArtboardStudio._openLayerChain = function (layer) {
    var chain = [], current = layer;
    while (current && current.typename == 'Layer') {
        chain.push({ ref: current, visible: current.visible, locked: current.locked });
        current.visible = true;
        current.locked = false;
        current = current.parent;
    }
    return chain;
};

AIArtboardStudio._restoreLayerChain = function (chain) {
    for (var i = chain.length - 1; i >= 0; i--) {
        try { chain[i].ref.visible = chain[i].visible; } catch (e) {}
        try { chain[i].ref.locked = chain[i].locked; } catch (e2) {}
    }
};

AIArtboardStudio.getDocumentInfo = function () {
    try {
        var doc = AIArtboardStudio._doc();
        var r = AIArtboardStudio._artboard(doc);
        var layers = [];
        AIArtboardStudio._collectLayers(doc.layers, layers);
        return AIArtboardStudio._result(true, 'المستند: ' + doc.name + ' — لوحات الرسم: ' + doc.artboards.length + ' — الطبقات: ' + layers.length + ' — لوحة الرسم النشطة: ' + (r[2] - r[0]).toFixed(1) + ' × ' + (r[1] - r[3]).toFixed(1) + ' pt');
    } catch (e) {
        return AIArtboardStudio._result(false, e.message || e);
    }
};

AIArtboardStudio._hexColor = function (hex, doc) {
    var value = String(hex || '#919BAA').replace('#', '');
    if (!/^[0-9a-fA-F]{6}$/.test(value)) throw new Error('لون HEX غير صالح.');
    var rr = parseInt(value.substr(0, 2), 16), gg = parseInt(value.substr(2, 2), 16), bb = parseInt(value.substr(4, 2), 16);
    if (doc.documentColorSpace == DocumentColorSpace.CMYK) {
        var rgb = new RGBColor(); rgb.red = rr; rgb.green = gg; rgb.blue = bb;
        return rgb;
    }
    var color = new RGBColor(); color.red = rr; color.green = gg; color.blue = bb; return color;
};

AIArtboardStudio.addArtboardShape = function (strokeWidth, hexColor, style) {
    var layer = null, relock = false, rehide = false;
    try {
        var doc = AIArtboardStudio._doc();
        var r = AIArtboardStudio._artboard(doc);
        var left = r[0], top = r[1], width = r[2] - r[0], height = r[1] - r[3];
        // Draw on the layer that is already active - never create a new layer.
        layer = doc.activeLayer;
        try { if (layer.locked) { layer.locked = false; relock = true; } } catch (e1) {}
        try { if (!layer.visible) { layer.visible = true; rehide = true; } } catch (e2) {}
        var rect = layer.pathItems.rectangle(top, left, width, height);
        rect.name = 'Artboard Size';
        var color = AIArtboardStudio._hexColor(hexColor, doc);
        style = String(style || 'fill');
        var sw = Number(strokeWidth); if (!(sw >= 0)) sw = 0;
        rect.filled = (style == 'fill' || style == 'both');
        rect.stroked = ((style == 'stroke' || style == 'both') && sw > 0);
        if (rect.filled) rect.fillColor = color;
        if (rect.stroked) { rect.strokeColor = color; rect.strokeWidth = sw; }
        doc.selection = null;
        rect.selected = true;
        try { if (relock) layer.locked = true; } catch (e3) {}
        try { if (rehide) layer.visible = false; } catch (e4) {}
        return AIArtboardStudio._result(true, 'تم إنشاء مستطيل مطابق لمقاس لوحة الرسم داخل اللير الحالي (' + layer.name + ').');
    } catch (e) {
        try { if (layer && relock) layer.locked = true; } catch (e5) {}
        return AIArtboardStudio._result(false, e.message || e);
    }
};

AIArtboardStudio.maskAllLayers = function (includeHidden, scope) {
    var doc, originalLayer, batches, processed = 0, elementCount = 0, skipped = 0, errors = [], lvl = null;
    try {
        lvl = AIArtboardStudio._quietStart();
        doc = AIArtboardStudio._doc();
        originalLayer = doc.activeLayer;
        var r = AIArtboardStudio._artboard(doc);
        var left = r[0], top = r[1], width = r[2] - r[0], height = r[1] - r[3];
        batches = AIArtboardStudio._elementBatches(doc, scope, includeHidden);

        for (var i = 0; i < batches.length; i++) {
            var batch = batches[i], layer = batch.layer;
            if (AIArtboardStudio._shouldSkipLayer(layer, includeHidden)) { skipped += batch.items.length; continue; }
            var layerChain = AIArtboardStudio._openLayerChain(layer);
            var objectStates = AIArtboardStudio._unlockBatchObjects(batch);
            var group = null, moved = [];
            try {
                doc.activeLayer = layer;
                group = batch.parent.groupItems.add();
                group.name = 'Artboard Mask — ' + (scope == 'selected' ? 'Selected Elements' : 'Active Artboard');
                for (var j = 0; j < batch.items.length; j++) {
                    batch.items[j].move(group, ElementPlacement.PLACEATEND);
                    moved.push(batch.items[j]);
                }
                var clip = group.pathItems.rectangle(top, left, width, height);
                clip.name = 'Artboard Clipping Path';
                clip.stroked = false;
                clip.filled = false;
                clip.clipping = true;
                try { clip.zOrder(ZOrderMethod.BRINGTOFRONT); } catch (zerr) {}
                group.clipped = true;
                elementCount += batch.items.length;
                processed++;
                AIArtboardStudio._restoreBatchObjects(objectStates);
                AIArtboardStudio._restoreLayerChain(layerChain);
            } catch (batchError) {
                /* Best-effort rollback: move artwork back to its original container. */
                for (var m = moved.length - 1; m >= 0; m--) {
                    try { moved[m].move(batch.parent, ElementPlacement.PLACEATEND); } catch (moveBackError) {}
                }
                try { if (group) group.remove(); } catch (removeGroupError) {}
                AIArtboardStudio._restoreBatchObjects(objectStates);
                AIArtboardStudio._restoreLayerChain(layerChain);
                errors.push((scope == 'selected' ? 'مجموعة عناصر' : layer.name) + ': ' + (batchError.message || batchError));
            }
        }
        try { doc.activeLayer = originalLayer; } catch (activeError) {}
        if (processed < 1) throw new Error('لم يتم إنشاء أي ماسك. تأكد من وجود عناصر على الـArtboard النشط، أو ألغِ قفل الطبقات المستهدفة.');
        var msg = 'تم إنشاء ماسك داخل حدود الـArtboard النشط لـ ' + elementCount + ' عنصر في ' + processed + ' مجموعة.';
        if (scope == 'selected') msg += ' تمت معالجة العناصر المحددة فقط.';
        else msg += ' تمت معالجة العناصر المتقاطعة مع الـArtboard النشط فقط دون المساس ببقية الـArtboards.';
        if (skipped) msg += ' تم تجاوز ' + skipped + ' عنصرًا في طبقات مخفية أو مقفلة.';
        if (errors.length) msg += ' لم تكتمل بعض المجموعات: ' + errors.join(' | ');
        AIArtboardStudio._quietEnd(lvl);
        return AIArtboardStudio._result(true, msg);
    } catch (e) {
        try { if (doc && originalLayer) doc.activeLayer = originalLayer; } catch (restoreError) {}
        AIArtboardStudio._quietEnd(lvl);
        return AIArtboardStudio._result(false, e.message || e);
    }
};

AIArtboardStudio._collectImageItems = function (container, out) {
    var items = container.pageItems;
    for (var i = 0; i < items.length; i++) {
        var item = items[i];
        try {
            if (item.parent == container && (item.typename == 'PlacedItem' || item.typename == 'RasterItem')) out.push(item);
            else if (item.parent == container && item.typename == 'GroupItem') AIArtboardStudio._collectImageItems(item, out);
        } catch (e) {}
    }
};

AIArtboardStudio.maskImagesOnly = function (includeHidden) {
    var doc, originalLayer, layers, processed = 0, imageCount = 0, skipped = 0, errors = [], lvl = null;
    try {
        lvl = AIArtboardStudio._quietStart();
        doc = AIArtboardStudio._doc(); originalLayer = doc.activeLayer;
        var r = AIArtboardStudio._artboard(doc), left = r[0], top = r[1], width = r[2] - r[0], height = r[1] - r[3];
        layers = []; AIArtboardStudio._collectLayers(doc.layers, layers);
        for (var i = 0; i < layers.length; i++) {
            var layer = layers[i];
            if (AIArtboardStudio._shouldSkipLayer(layer, includeHidden)) { skipped++; continue; }
            var found = [], images = [];
            AIArtboardStudio._collectImageItems(layer, found);
            for (var fi = 0; fi < found.length; fi++) {
                var img = found[fi];
                if (!includeHidden) {
                    var hl = false;
                    try { if (img.hidden || img.locked) hl = true; } catch (he) {}
                    if (hl) continue;
                }
                var ib = AIArtboardStudio._itemBounds(img);
                if (!AIArtboardStudio._rectsIntersect(ib, r)) continue;
                images.push(img);
            }
            if (!images.length) continue;
            var chain = AIArtboardStudio._openLayerChain(layer);
            try {
                var group = layer.groupItems.add(); group.name = 'Artboard Image Mask — ' + layer.name;
                for (var j = 0; j < images.length; j++) {
                    try { images[j].locked = false; } catch (unlockImage) {}
                    try { images[j].hidden = false; } catch (unhideImage) {}
                    images[j].move(group, ElementPlacement.PLACEATEND);
                }
                var clip = group.pathItems.rectangle(top, left, width, height);
                clip.name = 'Artboard Image Clipping Path'; clip.stroked = false; clip.filled = false; clip.clipping = true;
                try { clip.zOrder(ZOrderMethod.BRINGTOFRONT); } catch (zerr) {}
                group.clipped = true;
                imageCount += images.length; processed++;
                AIArtboardStudio._restoreLayerChain(chain);
            } catch (layerError) { AIArtboardStudio._restoreLayerChain(chain); errors.push(layer.name + ': ' + (layerError.message || layerError)); }
        }
        try { doc.activeLayer = originalLayer; } catch (activeError) {}
        if (!processed) throw new Error('لم يتم العثور على صور مرتبطة أو مضمّنة على الـArtboard النشط.');
        var msg = 'تم إنشاء ماسك للصور فقط على الـArtboard النشط في ' + processed + ' طبقة، بإجمالي ' + imageCount + ' صورة.';
        if (skipped) msg += ' تم تجاوز ' + skipped + ' طبقة مخفية أو مقفلة.';
        if (errors.length) msg += ' أخطاء: ' + errors.join(' | ');
        AIArtboardStudio._quietEnd(lvl);
        return AIArtboardStudio._result(true, msg);
    } catch (e) { try { if (doc && originalLayer) doc.activeLayer = originalLayer; } catch (restoreError) {} AIArtboardStudio._quietEnd(lvl); return AIArtboardStudio._result(false, e.message || e); }
};

AIArtboardStudio._imageBounds = function (item) {
    try { return item.visibleBounds; } catch (e) { return item.geometricBounds; }
};

AIArtboardStudio._collectSelectedImages = function (doc, out) {
    var sel = doc.selection;
    if (!sel || !sel.length) throw new Error('حدد صورة أو أكثر أولًا، أو اختر نطاق «جميع الصور».');
    for (var i = 0; i < sel.length; i++) {
        var item = sel[i];
        try {
            if (item.typename == 'PlacedItem' || item.typename == 'RasterItem') out.push(item);
            else if (item.typename == 'GroupItem') AIArtboardStudio._collectImageItems(item, out);
        } catch (e) {}
    }
};

AIArtboardStudio._cropOneImage = function (doc, item, rect, ppi, includeHidden, sharedOpts) {
    // Returns 'cropped' | 'inside' | 'outside' | 'skipped'.
    var wasLocked = false, wasHidden = false;
    try { wasHidden = item.hidden; } catch (e0) {}
    if (wasHidden && !includeHidden) return 'skipped';
    var b = AIArtboardStudio._imageBounds(item); // [left, top, right, bottom]
    var l = Math.max(b[0], rect[0]), t = Math.min(b[1], rect[1]), r = Math.min(b[2], rect[2]), bt = Math.max(b[3], rect[3]);
    if (r - l <= 0.01 || t - bt <= 0.01) return 'outside';
    var tol = 0.05;
    if (b[0] >= rect[0] - tol && b[1] <= rect[1] + tol && b[2] <= rect[2] + tol && b[3] >= rect[3] + tol) return 'inside';

    try { wasLocked = item.locked; } catch (e1) {}
    try { item.locked = false; } catch (e3) {}
    try { item.hidden = false; } catch (e4) {}

    var name = '';
    try { name = item.name; } catch (e9) {}

    var opts = sharedOpts;
    if (!opts) {
        opts = new RasterizeOptions();
        try { opts.resolution = ppi; } catch (e11) {}
        try { opts.transparency = true; } catch (e12) {}
        try { opts.backgroundBlack = false; } catch (e13) {}
        try { opts.padding = 0; } catch (e14) {}
        try { opts.antiAliasingMethod = AntiAliasingMethod.ARTOPTIMIZED; } catch (e15) {}
    }

    var marker = null;
    try { marker = item.parent.groupItems.add(); marker.move(item, ElementPlacement.PLACEBEFORE); } catch (e10) { marker = null; }

    var result = null;
    var isPlacedRaster = false;
    if (item.typename == 'PlacedItem') {
        try {
            if (item.file && /\.(png|jpe?g|tiff?|psd|webp|bmp|gif)$/i.test(item.file.name)) isPlacedRaster = true;
        } catch (fErr) {}
        if (isPlacedRaster) {
            try { result = doc.rasterize(item, [l, t, r, bt], opts); } catch (rErr) { result = null; }
        }
        if (!result || result.typename != 'RasterItem') {
            doc.selection = null;
            item.selected = true;
            item.embed();
            var embedded = doc.selection;
            if (!embedded || !embedded.length) {
                if (marker) { try { marker.remove(); } catch (m1) {} }
                throw new Error('تعذّر تضمين الصورة المرتبطة.');
            }
            item = embedded[0];
            if (item.typename != 'RasterItem') {
                if (marker) { try { marker.remove(); } catch (m2) {} }
                throw new Error('الملف المرتبط ليس صورة نقطية (قد يكون PDF أو AI).');
            }
            result = doc.rasterize(item, [l, t, r, bt], opts);
        }
    } else {
        result = doc.rasterize(item, [l, t, r, bt], opts);
    }

    // Some versions keep the source art; remove it if it is still alive.
    var alive = false;
    try { alive = (item.typename !== undefined && item !== result); } catch (e16) { alive = false; }
    if (alive) { try { item.remove(); } catch (e17) {} }

    if (marker) {
        try { result.move(marker, ElementPlacement.PLACEBEFORE); } catch (e18) {}
        try { marker.remove(); } catch (e19) {}
    }
    try { if (name) result.name = name; } catch (e20) {}
    try { result.locked = wasLocked; } catch (e21) {}
    try { result.hidden = wasHidden; } catch (e22) {}
    return 'cropped';
};

AIArtboardStudio.cropImagesToArtboard = function (includeHidden, scope, ppi) {
    var doc, originalLayer, cropped = 0, inside = 0, outside = 0, skipped = 0, errors = [], lvl = null;
    try {
        lvl = AIArtboardStudio._quietStart();
        doc = AIArtboardStudio._doc(); originalLayer = doc.activeLayer;
        ppi = parseFloat(ppi); if (!isFinite(ppi) || ppi < 36) ppi = 300; if (ppi > 2400) ppi = 2400;
        var rect = AIArtboardStudio._artboard(doc); // [left, top, right, bottom]
        var opts = new RasterizeOptions();
        try { opts.resolution = ppi; } catch (o1) {}
        try { opts.transparency = true; } catch (o2) {}
        try { opts.backgroundBlack = false; } catch (o3) {}
        try { opts.padding = 0; } catch (o4) {}
        try { opts.antiAliasingMethod = AntiAliasingMethod.ARTOPTIMIZED; } catch (o5) {}

        var jobs = []; // {layer, chain, items}
        if (scope == 'selected') {
            var picked = []; AIArtboardStudio._collectSelectedImages(doc, picked);
            jobs.push({ layer: null, chain: null, items: picked });
        } else {
            var layers = []; AIArtboardStudio._collectLayers(doc.layers, layers);
            for (var i = 0; i < layers.length; i++) {
                var layer = layers[i];
                if (AIArtboardStudio._shouldSkipLayer(layer, includeHidden)) { skipped++; continue; }
                var found = [], needCrop = [];
                AIArtboardStudio._collectImageItems(layer, found);
                for (var fi = 0; fi < found.length; fi++) {
                    var cand = found[fi], wasH = false;
                    try { wasH = cand.hidden; } catch (hErr) {}
                    if (wasH && !includeHidden) { skipped++; continue; }
                    var ib = AIArtboardStudio._imageBounds(cand);
                    if (!AIArtboardStudio._rectsIntersect(ib, rect)) { outside++; continue; }
                    if (AIArtboardStudio._rectInside(ib, rect)) { inside++; continue; }
                    needCrop.push(cand);
                }
                if (!needCrop.length) continue;
                var chain = AIArtboardStudio._openLayerChain(layer);
                jobs.push({ layer: layer, chain: chain, items: needCrop });
            }
        }
        for (var j = 0; j < jobs.length; j++) {
            var job = jobs[j];
            for (var k = 0; k < job.items.length; k++) {
                try {
                    var res = AIArtboardStudio._cropOneImage(doc, job.items[k], rect, ppi, includeHidden || scope == 'selected', opts);
                    if (res == 'cropped') cropped++; else if (res == 'inside') inside++; else if (res == 'outside') outside++; else skipped++;
                } catch (imgError) { errors.push((imgError.message || imgError)); }
            }
            if (job.chain) AIArtboardStudio._restoreLayerChain(job.chain);
        }
        try { doc.selection = null; } catch (selError) {}
        try { doc.activeLayer = originalLayer; } catch (activeError) {}
        if (!cropped && !inside && !outside && !errors.length) throw new Error('لم يتم العثور على صور في النطاق المحدد.');
        var msg = 'تم قص ' + cropped + ' صورة بحدود الـArtboard النشط (دقة ' + ppi + ' ppi).';
        if (inside) msg += ' ' + inside + ' صورة داخل الحدود أصلًا فلم تتغيّر.';
        if (outside) msg += ' ' + outside + ' صورة خارج الـArtboard النشط بالكامل فتُركت دون حذف.';
        if (skipped) msg += ' تم تجاوز ' + skipped + ' عنصر مخفي/غير مستهدف.';
        if (errors.length) msg += ' أخطاء: ' + errors.join(' | ');
        AIArtboardStudio._quietEnd(lvl);
        return AIArtboardStudio._result(cropped > 0 || !errors.length, msg);
    } catch (e) { try { if (doc && originalLayer) doc.activeLayer = originalLayer; } catch (restoreError) {} AIArtboardStudio._quietEnd(lvl); return AIArtboardStudio._result(false, e.message || e); }
};

AIArtboardStudio._jsq = function (value) {
    // JSON-safe string literal (ASCII only, so it survives the evalScript text channel).
    var s = String(value), out = '"';
    for (var i = 0; i < s.length; i++) {
        var c = s.charCodeAt(i), ch = s.charAt(i);
        if (ch == '"') out += '\\"';
        else if (ch == '\\') out += '\\\\';
        else if (c < 32 || c > 126) { var hex = c.toString(16); while (hex.length < 4) hex = '0' + hex; out += '\\u' + hex; }
        else out += ch;
    }
    return out + '"';
};

AIArtboardStudio._crTarget = null;

AIArtboardStudio._isInternalItem = function (item) {
    try {
        if (item && item.name && String(item.name).indexOf('__ABS_') === 0) return true;
        if (item && item.layer && item.layer.name && String(item.layer.name).indexOf('__ABS_') === 0) return true;
    } catch (e) {}
    return false;
};

AIArtboardStudio._firstSelectedImage = function (doc) {
    var sel = doc.selection;
    if (!sel || !sel.length) return null;
    for (var i = 0; i < sel.length; i++) {
        try {
            if (!AIArtboardStudio._isInternalItem(sel[i]) && (sel[i].typename == 'RasterItem' || sel[i].typename == 'PlacedItem')) return sel[i];
        } catch (e) {}
    }
    for (var g = 0; g < sel.length; g++) {
        try {
            if (!AIArtboardStudio._isInternalItem(sel[g]) && sel[g].typename == 'GroupItem') {
                var imgs = [];
                AIArtboardStudio._collectImageItems(sel[g], imgs);
                for (var k = 0; k < imgs.length; k++) {
                    if (!AIArtboardStudio._isInternalItem(imgs[k])) return imgs[k];
                }
            }
        } catch (e2) {}
    }
    return null;
};

AIArtboardStudio._progressOpen = function () { return null; };
AIArtboardStudio._progressClose = function () {};

AIArtboardStudio.exportImageForEdit = function (ppi, maxSide) {
    return AIArtboardStudio._exportImageForEditCore(ppi, maxSide);
};
AIArtboardStudio.applyEditedImage = function (path, bounds, mode, placeBounds) {
    return AIArtboardStudio._applyEditedImageCore(path, bounds, mode, placeBounds);
};

AIArtboardStudio._isClipped = function (item) {
    var p = null, guard = 0;
    try { p = item.parent; } catch (e) { return false; }
    while (p && guard++ < 40) {
        try {
            if (p.typename == 'Layer' || p.typename == 'Document') return false;
            if (p.typename == 'GroupItem' && p.clipped) return true;
            p = p.parent;
        } catch (e2) { return false; }
    }
    return false;
};

AIArtboardStudio._canDirectRead = function (item) {
    try {
        if (!item || item.typename != 'PlacedItem') return false;
        var f = item.file;
        if (!f || !f.exists) return false;
        if (!(/\.(png|jpe?g|webp|gif|bmp)$/i.test(f.name))) return false;
        if (!(f.length > 0 && f.length <= 28 * 1024 * 1024)) return false;
        if (AIArtboardStudio._isClipped(item)) return false;
        var mx = item.matrix;
        if (!mx || Math.abs(mx.mValueB) > 0.001 || Math.abs(mx.mValueC) > 0.001 || mx.mValueA <= 0) return false;
        return true;
    } catch (e) { return false; }
};

AIArtboardStudio._exportInPlace = function (doc, item, pct, file, fast) {
    // Fast in-place export without opening a temporary document window.
    // Prefers doc.imageCapture (fast, safe on multi-artboard docs in AI 2024-2027), with fallback to exportSelectionAsPNG.
    var saved = [], i, ok = false, lvl = null, chain = null, wasHidden = false, wasLocked = false;
    try { for (i = 0; i < doc.selection.length; i++) saved.push(doc.selection[i]); } catch (e0) {}
    try {
        lvl = AIArtboardStudio._quietStart();
        chain = AIArtboardStudio._openLayerChain(AIArtboardStudio._layerFromItem(item));
        try { if (file.exists) file.remove(); } catch (e1) {}
        try { wasLocked = item.locked; item.locked = false; } catch (l0) {}
        try { wasHidden = item.hidden; item.hidden = false; } catch (h0) {}

        if (typeof doc.imageCapture === 'function') {
            var hiddenSibs = [], hiddenLayers = [];
            try {
                var rootLayer = AIArtboardStudio._layerFromItem(item);
                for (var li = 0; li < doc.layers.length; li++) {
                    var lyr = doc.layers[li];
                    if (lyr !== rootLayer) {
                        try {
                            if (lyr.visible) { hiddenLayers.push(lyr); lyr.visible = false; }
                        } catch (le) {}
                    }
                }
                var cur = item, guard = 0;
                while (cur && guard++ < 32) {
                    var par = null;
                    try { par = cur.parent; } catch (pe) { par = null; }
                    if (!par || par.typename == 'Document') break;
                    var isClipGrp = false;
                    try { isClipGrp = (par.typename == 'GroupItem' && par.clipped); } catch (ce) {}
                    if (!isClipGrp && par.pageItems) {
                        for (var si = 0; si < par.pageItems.length; si++) {
                            var sib = par.pageItems[si];
                            if (sib !== cur) {
                                try {
                                    if (!sib.hidden) { hiddenSibs.push(sib); sib.hidden = true; }
                                } catch (se) {}
                            }
                        }
                    }
                    if (par.typename == 'Layer') break;
                    cur = par;
                }
                var b = item.visibleBounds;
                var res = Math.max(36, Math.min(600, Math.round(72 * (pct / 100))));
                var capOpts = null;
                try {
                    capOpts = new ImageCaptureOptions();
                    capOpts.resolution = res;
                    capOpts.transparency = true;
                    capOpts.antiAliasing = !fast;
                    capOpts.matte = false;
                } catch (coErr) { capOpts = null; }
                if (capOpts) doc.imageCapture(file, b, capOpts);
                else doc.imageCapture(file, b);
                ok = !!file.exists && file.length > 0;
            } catch (capE) { ok = false; }
            for (i = 0; i < hiddenSibs.length; i++) { try { hiddenSibs[i].hidden = false; } catch (rs1) {} }
            for (i = 0; i < hiddenLayers.length; i++) { try { hiddenLayers[i].visible = true; } catch (rs2) {} }
        }

        if (!ok && typeof doc.exportSelectionAsPNG === 'function') {
            doc.selection = null;
            item.selected = true;
            var o = new ExportOptionsPNG24();
            o.antiAliasing = !fast;
            o.transparency = true;
            o.artBoardClipping = false;
            o.horizontalScale = pct;
            o.verticalScale = pct;
            try {
                doc.exportSelectionAsPNG(file, o);
            } catch (argErr) {
                doc.exportSelectionAsPNG(file);
            }
            ok = !!file.exists && file.length > 0;
        }
    } catch (e2) { ok = false; }
    try { item.hidden = wasHidden; } catch (h1) {}
    try { item.locked = wasLocked; } catch (l1) {}
    if (chain) AIArtboardStudio._restoreLayerChain(chain);
    AIArtboardStudio._quietEnd(lvl);
    try { doc.selection = null; for (i = 0; i < saved.length; i++) saved[i].selected = true; } catch (e3) {}
    return ok;
};

AIArtboardStudio._exportImageForEditCore = function (ppi, maxSide) {
    var doc = null, tmp = null, lvl = null, chain = null, item = null, wasHidden = false, wasLocked = false;
    try {
        lvl = AIArtboardStudio._quietStart();
        doc = AIArtboardStudio._doc();
        ppi = parseFloat(ppi); if (!isFinite(ppi) || ppi < 36) ppi = 300; if (ppi > 600) ppi = 600;
        maxSide = parseFloat(maxSide); if (!isFinite(maxSide) || maxSide < 256) maxSide = 4096;
        item = AIArtboardStudio._firstSelectedImage(doc);
        if (!item && AIArtboardStudio._xf && AIArtboardStudio._xf.target) {
            try { if (AIArtboardStudio._xf.target.typename) item = AIArtboardStudio._xf.target; } catch (xfT) {}
        }
        if (!item) throw new Error('حدد صورة واحدة (مضمّنة أو مرتبطة) داخل Illustrator أولًا.');
        AIArtboardStudio._crTarget = item;
        var b = item.visibleBounds; // [left, top, right, bottom]
        var w = b[2] - b[0], h = b[1] - b[3];
        if (w <= 0 || h <= 0) throw new Error('أبعاد الصورة غير صالحة.');
        var scale = ppi / 72;
        if (Math.max(w, h) * scale > maxSide) scale = maxSide / Math.max(w, h);
        var pct = scale * 100;
        var stamp = new Date().getTime();
        var outFile = new File(Folder.temp.fsName + '/abs_edit_' + stamp + '.png');
        var name = ''; try { name = item.name; } catch (e1) {}
        if (!name) name = (item.typename == 'PlacedItem') ? 'صورة مرتبطة' : 'صورة مضمّنة';

        var xfModified = (AIArtboardStudio._xf && AIArtboardStudio._xf.target == item &&
            (Math.abs(AIArtboardStudio._xf.cur.a - 1) > 1e-4 || Math.abs(AIArtboardStudio._xf.cur.d - 1) > 1e-4 ||
             Math.abs(AIArtboardStudio._xf.cur.b) > 1e-4 || Math.abs(AIArtboardStudio._xf.cur.c) > 1e-4));

        if (!xfModified && AIArtboardStudio._canDirectRead(item)) {
            var directJson = '{"path":' + AIArtboardStudio._jsq(item.file.fsName) +
                ',"outPath":' + AIArtboardStudio._jsq(outFile.fsName) +
                ',"bounds":[' + b[0] + ',' + b[1] + ',' + b[2] + ',' + b[3] + ']' +
                ',"name":' + AIArtboardStudio._jsq(name) +
                ',"kind":' + AIArtboardStudio._jsq(item.typename) + ',"isDirect":true,"method":"direct"}';
            AIArtboardStudio._quietEnd(lvl);
            return 'OK|' + directJson;
        }

        var srcFile = new File(Folder.temp.fsName + '/abs_src_' + stamp + '.png');
        var method = 'selection';
        var fast = (maxSide <= 800);
        if (!AIArtboardStudio._exportInPlace(doc, item, pct, srcFile, fast)) {
            method = 'tempdoc';
            chain = AIArtboardStudio._openLayerChain(AIArtboardStudio._layerFromItem(item));
            try { wasLocked = item.locked; item.locked = false; } catch (l0) {}
            try { wasHidden = item.hidden; item.hidden = false; } catch (h0) {}
            tmp = app.documents.add(DocumentColorSpace.RGB, Math.max(1, w), Math.max(1, h));
            var dup = item.duplicate(tmp.layers[0], ElementPlacement.PLACEATBEGINNING);
            tmp.artboards[0].artboardRect = dup.visibleBounds;
            var opts = new ExportOptionsPNG24();
            opts.antiAliasing = !fast; opts.transparency = true; opts.artBoardClipping = true;
            opts.horizontalScale = pct; opts.verticalScale = pct;
            tmp.exportFile(srcFile, ExportType.PNG24, opts);
            tmp.close(SaveOptions.DONOTSAVECHANGES); tmp = null;
            app.activeDocument = doc;
            try { item.hidden = wasHidden; } catch (h1) {}
            try { item.locked = wasLocked; } catch (l1) {}
            if (chain) { AIArtboardStudio._restoreLayerChain(chain); chain = null; }
        }
        if (!srcFile.exists || srcFile.length <= 0) throw new Error('تعذّر تصدير الصورة المحددة.');

        var json = '{"path":' + AIArtboardStudio._jsq(srcFile.fsName) +
            ',"outPath":' + AIArtboardStudio._jsq(outFile.fsName) +
            ',"bounds":[' + b[0] + ',' + b[1] + ',' + b[2] + ',' + b[3] + ']' +
            ',"name":' + AIArtboardStudio._jsq(name) +
            ',"kind":' + AIArtboardStudio._jsq(item.typename) + ',"isDirect":false,"method":' + AIArtboardStudio._jsq(method) + '}';
        AIArtboardStudio._quietEnd(lvl);
        return 'OK|' + json;
    } catch (e) {
        try { if (tmp) tmp.close(SaveOptions.DONOTSAVECHANGES); } catch (c1) {}
        try { if (doc) app.activeDocument = doc; } catch (c2) {}
        try { if (item) { item.hidden = wasHidden; item.locked = wasLocked; } } catch (c3) {}
        try { if (chain) AIArtboardStudio._restoreLayerChain(chain); } catch (c4) {}
        AIArtboardStudio._quietEnd(lvl);
        return AIArtboardStudio._result(false, e.message || e);
    }
};

AIArtboardStudio._sameBounds = function (item, bounds) {
    try {
        var b = item.visibleBounds;
        for (var i = 0; i < 4; i++) if (Math.abs(b[i] - bounds[i]) > 0.6) return false;
        return true;
    } catch (e) { return false; }
};

AIArtboardStudio._findImageByBounds = function (doc, bounds) {
    if (AIArtboardStudio._crTarget) {
        try {
            if (!AIArtboardStudio._isInternalItem(AIArtboardStudio._crTarget) && AIArtboardStudio._crTarget.typename && AIArtboardStudio._sameBounds(AIArtboardStudio._crTarget, bounds)) {
                return AIArtboardStudio._crTarget;
            }
        } catch (ctErr) {}
    }
    var i, sel = doc.selection;
    if (sel && sel.length) {
        for (i = 0; i < sel.length; i++) {
            try { if (!AIArtboardStudio._isInternalItem(sel[i]) && (sel[i].typename == 'RasterItem' || sel[i].typename == 'PlacedItem') && AIArtboardStudio._sameBounds(sel[i], bounds)) return sel[i]; } catch (e0) {}
        }
    }
    for (i = 0; i < doc.rasterItems.length; i++) { if (!AIArtboardStudio._isInternalItem(doc.rasterItems[i]) && AIArtboardStudio._sameBounds(doc.rasterItems[i], bounds)) return doc.rasterItems[i]; }
    for (i = 0; i < doc.placedItems.length; i++) { if (!AIArtboardStudio._isInternalItem(doc.placedItems[i]) && AIArtboardStudio._sameBounds(doc.placedItems[i], bounds)) return doc.placedItems[i]; }
    return null;
};

AIArtboardStudio._applyEditedImageCore = function (path, bounds, mode, placeBounds) {
    var doc = null, pb = (placeBounds && placeBounds.length === 4) ? placeBounds : bounds, lvl = null;
    try {
        lvl = AIArtboardStudio._quietStart();
        doc = AIArtboardStudio._doc();
        var f = new File(path);
        if (!f.exists) throw new Error('الملف المعدّل غير موجود.');
        var target = AIArtboardStudio._findImageByBounds(doc, bounds);
        if (!target) throw new Error('تعذّر العثور على الصورة الأصلية (قد تكون تحركت أو حُذفت). حدّدها وحمّلها من جديد.');
        try { target.locked = false; } catch (e1) {}
        var wasHidden = false; try { wasHidden = target.hidden; target.hidden = false; } catch (e2) {}
        var container = target.parent;
        var placed;
        try { placed = container.placedItems.add(); } catch (e3) { placed = target.layer.placedItems.add(); }
        placed.file = f;
        placed.width = pb[2] - pb[0];
        placed.height = pb[1] - pb[3];
        placed.left = pb[0];
        placed.top = pb[1];
        doc.selection = null;
        placed.selected = true;
        placed.embed();
        var result = (doc.selection && doc.selection.length) ? doc.selection[0] : null;
        if (!result) { try { result = container.pageItems[0]; } catch (e4) {} }
        if (!result) throw new Error('تعذّر تضمين الصورة المعدّلة في المستند.');
        try { result.move(target, ElementPlacement.PLACEBEFORE); } catch (e5) {}
        var name = ''; try { name = target.name; } catch (e6) {}
        if (mode == 'replace') {
            try { target.remove(); } catch (e7) { AIArtboardStudio._quietEnd(lvl); throw new Error('أُضيفت الصورة المعدّلة لكن تعذّر حذف الأصل (قد يكون مقفلًا).'); }
            try { if (name) result.name = name; } catch (e8) {}
            try { result.hidden = wasHidden; } catch (e9) {}
            AIArtboardStudio._crTarget = result;
        } else {
            try { target.hidden = wasHidden; } catch (e10) {}
            try { result.name = (name ? name + ' ' : '') + '(معدّلة)'; } catch (e11) {}
            AIArtboardStudio._crTarget = target;
        }
        try { doc.selection = null; result.selected = true; } catch (e12) {}
        AIArtboardStudio._quietEnd(lvl);
        return AIArtboardStudio._result(true, mode == 'replace' ? 'تم استبدال الصورة بالنسخة المعدّلة.' : 'تمت إضافة نسخة معدّلة فوق الصورة الأصلية.');
    } catch (e) {
        AIArtboardStudio._quietEnd(lvl);
        return AIArtboardStudio._result(false, e.message || e);
    }
};


/* ---------- live on-canvas preview ----------
   A linked placeholder image sits on top of the real image and is re-linked to a fresh low-resolution
   frame after every change, so the edit is visible on the artwork itself. The original is only hidden
   during the session and is restored on end/cancel.
   L.bounds = rectangle of the original image, L.frame = rectangle currently occupied by the placeholder
   (differs from L.bounds for warps, whose result may extend beyond the original). */
AIArtboardStudio._live = null;

AIArtboardStudio._liveFrameRect = function (b, nb) {
    // nb = [x0, y0, x1, y1] in units of the original image (x right, y down), or null for "same as original"
    if (!nb || nb.length !== 4) return [b[0], b[1], b[2], b[3]];
    var w = b[2] - b[0], h = b[1] - b[3];
    return [b[0] + nb[0] * w, b[1] - nb[1] * h, b[0] + nb[2] * w, b[1] - nb[3] * h];
};

AIArtboardStudio._liveFit = function (ph, r) {
    ph.width = r[2] - r[0];
    ph.height = r[1] - r[3];
    ph.left = r[0];
    ph.top = r[1];
};

AIArtboardStudio._liveSync = function (L) {
    // If the user moved/resized the preview image, the hidden original follows (no duplicates, no snapping back).
    var ph = L.ph, cur = [ph.left, ph.top, ph.left + ph.width, ph.top - ph.height], f = L.frame, b = L.bounds, moved = false, i;
    for (i = 0; i < 4; i++) if (Math.abs(cur[i] - f[i]) > 0.01) moved = true;
    if (!moved) return;
    var fw = f[2] - f[0], fh = f[1] - f[3], cw = cur[2] - cur[0], ch = cur[1] - cur[3];
    if (fw <= 0 || fh <= 0 || cw <= 0 || ch <= 0) return;
    var rw = cw / fw, rh = ch / fh;
    var nl = cur[0] + (b[0] - f[0]) * rw, nt = cur[1] + (b[1] - f[1]) * rh;
    var nw = (b[2] - b[0]) * rw, nh = (b[1] - b[3]) * rh;
    var t = L.target;
    try { t.locked = false; } catch (e0) {}
    try { t.width = nw; t.height = nh; } catch (e1) {}
    try { t.left = nl; t.top = nt; } catch (e2) {}
    L.bounds = [nl, nt, nl + nw, nt - nh];
    L.frame = cur;
};

AIArtboardStudio.liveBegin = function (framePath, bounds, nb) {
    var doc = null, ph = null, lvl = null;
    try {
        lvl = AIArtboardStudio._quietStart();
        if (AIArtboardStudio._live) AIArtboardStudio.liveEnd();
        doc = AIArtboardStudio._doc();
        var f = new File(framePath);
        if (!f.exists) throw new Error('ملف المعاينة غير موجود.');
        var target = AIArtboardStudio._findImageByBounds(doc, bounds);
        if (!target) throw new Error('تعذّر العثور على الصورة الأصلية في المستند.');
        var container = target.parent;
        try { ph = container.placedItems.add(); } catch (e1) { ph = target.layer.placedItems.add(); }
        ph.file = f;
        var fr = AIArtboardStudio._liveFrameRect(bounds, nb);
        AIArtboardStudio._liveFit(ph, fr);
        try { ph.name = '__ABS_LIVE__'; } catch (e2) {}
        try { ph.move(target, ElementPlacement.PLACEBEFORE); } catch (e3) {}
        var wasHidden = false;
        try { wasHidden = target.hidden; target.hidden = true; } catch (e4) {}
        AIArtboardStudio._live = { doc: doc, target: target, ph: ph, bounds: bounds, frame: fr, wasHidden: wasHidden };
        try { app.redraw(); } catch (e5) {}
        AIArtboardStudio._quietEnd(lvl);
        return AIArtboardStudio._result(true, 'live');
    } catch (e) {
        try { if (ph) ph.remove(); } catch (c1) {}
        AIArtboardStudio._quietEnd(lvl);
        return AIArtboardStudio._result(false, e.message || e);
    }
};

AIArtboardStudio.liveFrame = function (framePath, nb) {
    var L = AIArtboardStudio._live, lvl = null;
    try {
        if (!L) throw new Error('انتهت جلسة المعاينة المباشرة.');
        if (app.activeDocument !== L.doc) throw new Error('تغيّر المستند النشط أثناء المعاينة.');
        try { L.ph.typename; } catch (e0) { AIArtboardStudio._live = null; throw new Error('حُذفت صورة المعاينة من المستند.'); }
        var f = new File(framePath);
        if (!f.exists) throw new Error('ملف الإطار غير موجود.');
        lvl = AIArtboardStudio._quietStart();
        AIArtboardStudio._liveSync(L);
        L.ph.file = f;
        L.frame = AIArtboardStudio._liveFrameRect(L.bounds, nb);
        AIArtboardStudio._liveFit(L.ph, L.frame);
        try { app.redraw(); } catch (e2) {}
        AIArtboardStudio._quietEnd(lvl);
        return AIArtboardStudio._result(true, 'frame');
    } catch (e) {
        AIArtboardStudio._quietEnd(lvl);
        return AIArtboardStudio._result(false, e.message || e);
    }
};

AIArtboardStudio.liveEnd = function () {
    var L = AIArtboardStudio._live;
    AIArtboardStudio._live = null;
    if (!L) return AIArtboardStudio._result(true, 'none');
    var err = '', b = L.bounds, lvl = AIArtboardStudio._quietStart();
    try { AIArtboardStudio._liveSync(L); b = L.bounds; } catch (e0) {}
    try { L.ph.remove(); } catch (e1) {}
    try { L.target.hidden = L.wasHidden; } catch (e2) { err = 'تعذّر إظهار الصورة الأصلية.'; }
    try { L.doc.selection = null; L.target.selected = true; } catch (e3) {}
    try { app.redraw(); } catch (e4) {}
    AIArtboardStudio._quietEnd(lvl);
    if (err) return AIArtboardStudio._result(false, err);
    return 'OK|{"bounds":[' + b[0] + ',' + b[1] + ',' + b[2] + ',' + b[3] + ']}';
};

/* ---------- direct transforms (Scale / Rotate / Skew / Free Transform) ----------
   Applied to the real image through a matrix about its centre; every update first undoes the previous one,
   so the image is always "original x current settings" and can be reverted exactly. */
AIArtboardStudio._xf = null;

AIArtboardStudio._mmul = function (p, q) { // apply q first, then p
    return { a: p.a * q.a + p.c * q.b, b: p.b * q.a + p.d * q.b, c: p.a * q.c + p.c * q.d, d: p.b * q.c + p.d * q.d };
};
AIArtboardStudio._minv = function (m) {
    var det = m.a * m.d - m.b * m.c;
    if (Math.abs(det) < 1e-9) throw new Error('إعدادات التحويل غير صالحة (المساحة صفر).');
    return { a: m.d / det, b: -m.b / det, c: -m.c / det, d: m.a / det };
};
AIArtboardStudio._xfMatrix = function (sx, sy, rot, skx, sky, fh, fv) {
    var D = Math.PI / 180, mul = AIArtboardStudio._mmul;
    var S = { a: (sx / 100) * (fh ? -1 : 1), b: 0, c: 0, d: (sy / 100) * (fv ? -1 : 1) };
    var K = { a: 1, b: Math.tan(sky * D), c: Math.tan(skx * D), d: 1 };
    var c = Math.cos(rot * D), s = Math.sin(rot * D), R = { a: c, b: s, c: -s, d: c };
    return mul(R, mul(K, S));
};
AIArtboardStudio._toMatrix = function (m) {
    var mx = new Matrix();
    mx.mValueA = m.a; mx.mValueB = m.b; mx.mValueC = m.c; mx.mValueD = m.d; mx.mValueTX = 0; mx.mValueTY = 0;
    return mx;
};

AIArtboardStudio._xfToolMap = {
    free: 'Adobe Free Transform Tool',
    scale: 'Adobe Scale Tool',
    rotate: 'Adobe Rotate Tool',
    skew: 'Adobe Shear Tool',
    direct: 'Adobe Direct Select Tool',
    mesh: 'Adobe Mesh Editing Tool',
    select: 'Adobe Select Tool',
    distort: 'Adobe Select Tool',
    perspective: 'Adobe Select Tool',
    warp: 'Adobe Select Tool',
    splitH: 'Adobe Select Tool',
    splitV: 'Adobe Select Tool',
    splitX: 'Adobe Select Tool'
};

AIArtboardStudio._xfIsMatrixMode = function (m) {
    return m == 'free' || m == 'scale' || m == 'rotate' || m == 'skew';
};

AIArtboardStudio._xfSelectTool = function (key) {
    try {
        var t = AIArtboardStudio._xfToolMap[key];
        if (t) app.selectTool(t);
    } catch (e) {}
};

AIArtboardStudio._xfColor = function (doc, r, g, b) {
    try {
        if (doc && doc.documentColorSpace == DocumentColorSpace.CMYK) {
            var rr = r / 255, gg = g / 255, bb = b / 255;
            var k = 1 - Math.max(rr, Math.max(gg, bb));
            var c = new CMYKColor();
            if (k >= 0.999) { c.cyan = 0; c.magenta = 0; c.yellow = 0; c.black = 100; }
            else {
                c.cyan = Math.round(((1 - rr - k) / (1 - k)) * 100);
                c.magenta = Math.round(((1 - gg - k) / (1 - k)) * 100);
                c.yellow = Math.round(((1 - bb - k) / (1 - k)) * 100);
                c.black = Math.round(k * 100);
            }
            return c;
        }
    } catch (e) {}
    var rgb = new RGBColor();
    rgb.red = r; rgb.green = g; rgb.blue = b;
    return rgb;
};

AIArtboardStudio._xfParseNums = function (str) {
    var parts = String(str || '').split(','), out = [], i, v;
    for (i = 0; i < parts.length; i++) {
        if (parts[i] === '') continue;
        v = parseFloat(parts[i]);
        if (isFinite(v)) out.push(v);
    }
    return out;
};

AIArtboardStudio._xfNormToDoc = function (b, u, v) {
    return [b[0] + u * (b[2] - b[0]), b[1] - v * (b[1] - b[3])];
};

AIArtboardStudio._xfDocToNorm = function (b, x, y) {
    var w = Math.max(1e-6, b[2] - b[0]), h = Math.max(1e-6, b[1] - b[3]);
    return [(x - b[0]) / w, (b[1] - y) / h];
};

AIArtboardStudio._xfHandleSize = function (b, doc) {
    var w = Math.abs(b[2] - b[0]), h = Math.abs(b[1] - b[3]);
    var minSide = Math.max(24, Math.min(w, h));
    var maxSide = Math.max(24, Math.max(w, h));
    var z = 1;
    try {
        var d = doc || (AIArtboardStudio._xf && AIArtboardStudio._xf.doc) || app.activeDocument;
        if (d && d.activeView && d.activeView.zoom > 0.02) z = d.activeView.zoom;
    } catch (e) {}
    var ideal = 14 / z;
    var base = Math.max(minSide * 0.028, maxSide * 0.018);
    return Math.max(8, Math.min(minSide * 0.16, Math.max(ideal, base)));
};

AIArtboardStudio._xfClearOverlay = function (X) {
    if (!X) return;
    try {
        if (X.overlay) { X.overlay.locked = false; X.overlay.remove(); }
    } catch (e) {}
    X.overlay = null;
};

AIArtboardStudio._xfDrawMatrixOverlay = function (X) {
    if (!X || !X.target || !X.doc) return;
    AIArtboardStudio._xfClearOverlay(X);
    try {
        var doc = X.doc, b = X.target.visibleBounds;
        var ob = X.origBox || b;
        var hx = Math.max(1, (ob[2] - ob[0]) / 2), hy = Math.max(1, (ob[1] - ob[3]) / 2);
        var cx = (b[0] + b[2]) / 2, cy = (b[1] + b[3]) / 2;
        var m = X.cur || { a: 1, b: 0, c: 0, d: 1 };
        function pt(dx, dy) {
            return [cx + dx * m.a + dy * m.c, cy + dx * m.b + dy * m.d];
        }
        var c0 = pt(-hx, hy), c1 = pt(hx, hy), c2 = pt(hx, -hy), c3 = pt(-hx, -hy);
        var m0 = [(c0[0] + c1[0]) / 2, (c0[1] + c1[1]) / 2];
        var m1 = [(c1[0] + c2[0]) / 2, (c1[1] + c2[1]) / 2];
        var m2 = [(c2[0] + c3[0]) / 2, (c2[1] + c3[1]) / 2];
        var m3 = [(c3[0] + c0[0]) / 2, (c3[1] + c0[1]) / 2];

        var container = X.target.parent;
        var g = null;
        try { g = container.groupItems.add(); } catch (cgErr) { g = X.target.layer.groupItems.add(); }
        g.name = '__ABS_XF_OVERLAY__';
        try { g.move(X.target, ElementPlacement.PLACEBEFORE); } catch (mvErr) {}

        var blue = AIArtboardStudio._xfColor(doc, 38, 128, 235);
        var cyan = AIArtboardStudio._xfColor(doc, 0, 190, 255);
        var orange = AIArtboardStudio._xfColor(doc, 255, 145, 0);
        var white = AIArtboardStudio._xfColor(doc, 255, 255, 255);
        var sz = AIArtboardStudio._xfHandleSize(b, doc);
        var sw = Math.max(1.1, Math.min(3.2, sz * 0.15));

        var box = g.pathItems.add();
        box.setEntirePath([c0, c1, c2, c3]);
        box.closed = true; box.filled = false; box.stroked = true;
        box.strokeColor = blue; box.strokeWidth = sw;

        // Crosshair axes through center
        var axH = g.pathItems.add();
        axH.setEntirePath([m3, m1]);
        axH.closed = false; axH.filled = false; axH.stroked = true;
        axH.strokeColor = cyan; axH.strokeWidth = sw * 0.7;
        var axV = g.pathItems.add();
        axV.setEntirePath([m0, m2]);
        axV.closed = false; axV.filled = false; axV.stroked = true;
        axV.strokeColor = cyan; axV.strokeWidth = sw * 0.7;

        // Top rotation stem for Free Transform and Rotate modes
        var upVx = m0[0] - cx, upVy = m0[1] - cy;
        var upLen = Math.sqrt(upVx * upVx + upVy * upVy) || 1;
        var stemDist = sz * 2.4;
        var rotPt = [m0[0] + (upVx / upLen) * stemDist, m0[1] + (upVy / upLen) * stemDist];
        var mode = X.mode || 'free';
        if (mode == 'free' || mode == 'rotate') {
            var stem = g.pathItems.add();
            stem.setEntirePath([m0, rotPt]);
            stem.closed = false; stem.filled = false; stem.stroked = true;
            stem.strokeColor = orange; stem.strokeWidth = sw;
        }
        if (mode == 'rotate') {
            var orbitR = Math.min(hx, hy) * 0.55;
            var orb = g.pathItems.ellipse(cy + orbitR, cx - orbitR, orbitR * 2, orbitR * 2);
            orb.filled = false; orb.stroked = true; orb.strokeColor = orange; orb.strokeWidth = sw * 0.85;
        }

        var pivR = sz * 0.48;
        var piv = g.pathItems.ellipse(cy + pivR, cx - pivR, pivR * 2, pivR * 2);
        piv.filled = true; piv.fillColor = white;
        piv.stroked = true; piv.strokeColor = blue; piv.strokeWidth = sw;
        g.locked = true;
        X.overlay = g;

        // Build or update unlocked draggable handles in __ABS_XF_CAGE__ for Matrix modes
        var specs = [];
        if (mode == 'rotate') {
            specs = [
                { p: c0, shape: 'circle', color: orange },
                { p: c1, shape: 'circle', color: orange },
                { p: c2, shape: 'circle', color: orange },
                { p: c3, shape: 'circle', color: orange },
                { p: rotPt, shape: 'circle', color: orange }
            ];
        } else if (mode == 'skew') {
            specs = [
                { p: c0, shape: 'rect', color: blue },
                { p: c1, shape: 'rect', color: blue },
                { p: c2, shape: 'rect', color: blue },
                { p: c3, shape: 'rect', color: blue },
                { p: m0, shape: 'diamond', color: cyan },
                { p: m1, shape: 'diamond', color: cyan },
                { p: m2, shape: 'diamond', color: cyan },
                { p: m3, shape: 'diamond', color: cyan }
            ];
        } else if (mode == 'scale') {
            specs = [
                { p: c0, shape: 'rect', color: blue },
                { p: c1, shape: 'rect', color: blue },
                { p: c2, shape: 'rect', color: blue },
                { p: c3, shape: 'rect', color: blue },
                { p: m0, shape: 'rect', color: cyan },
                { p: m1, shape: 'rect', color: cyan },
                { p: m2, shape: 'rect', color: cyan },
                { p: m3, shape: 'rect', color: cyan }
            ];
        } else {
            // free transform: 4 corners + 4 midpoints + 1 top rotation handle
            specs = [
                { p: c0, shape: 'rect', color: blue },
                { p: c1, shape: 'rect', color: blue },
                { p: c2, shape: 'rect', color: blue },
                { p: c3, shape: 'rect', color: blue },
                { p: m0, shape: 'rect', color: cyan },
                { p: m1, shape: 'rect', color: cyan },
                { p: m2, shape: 'rect', color: cyan },
                { p: m3, shape: 'rect', color: cyan },
                { p: rotPt, shape: 'circle', color: orange }
            ];
        }

        X.cageBounds = [b[0], b[1], b[2], b[3]];
        X.matrixCenter = [cx, cy];
        X.matrixHalf = [hx, hy];

        if (X.cageLayer && X.handles && X.handles.length === specs.length && X.matrixHandleMode === mode) {
            for (var u = 0; u < specs.length; u++) {
                var uh = X.handles[u], uhb = uh.visibleBounds;
                var udx = specs[u].p[0] - (uhb[0] + uhb[2]) / 2;
                var udy = specs[u].p[1] - (uhb[1] + uhb[3]) / 2;
                if (Math.abs(udx) > 0.05 || Math.abs(udy) > 0.05) uh.translate(udx, udy);
                X.lastCenters[u] = [specs[u].p[0], specs[u].p[1]];
            }
        } else {
            try { if (X.cageLayer) { X.cageLayer.locked = false; X.cageLayer.remove(); } } catch (rmC) {}
            var cl = doc.layers.add();
            cl.name = '__ABS_XF_CAGE__';
            X.cageLayer = cl;
            X.matrixHandleMode = mode;
            X.handles = [];
            X.lastCenters = [];
            for (var i = 0; i < specs.length; i++) {
                var sp = specs[i], pos = sp.p, h = null;
                if (sp.shape == 'circle') {
                    h = cl.pathItems.ellipse(pos[1] + sz * 0.58, pos[0] - sz * 0.58, sz * 1.16, sz * 1.16);
                } else if (sp.shape == 'diamond') {
                    var r = sz * 0.65;
                    h = cl.pathItems.add();
                    h.setEntirePath([[pos[0], pos[1] + r], [pos[0] + r, pos[1]], [pos[0], pos[1] - r], [pos[0] - r, pos[1]]]);
                    h.closed = true;
                } else {
                    h = cl.pathItems.rectangle(pos[1] + sz / 2, pos[0] - sz / 2, sz, sz);
                }
                h.name = '__ABS_XF_H_' + i;
                h.filled = true; h.fillColor = white;
                h.stroked = true; h.strokeColor = sp.color; h.strokeWidth = sw;
                X.handles.push(h);
                X.lastCenters.push([pos[0], pos[1]]);
            }
            try { if (X.origActiveLayer) doc.activeLayer = X.origActiveLayer; } catch (alR) {}
        }
    } catch (e) {}
};

AIArtboardStudio._xfClearCage = function (X, unhideTarget) {
    if (!X) return;
    try {
        if (X.cageLayer) { X.cageLayer.locked = false; X.cageLayer.remove(); }
    } catch (e1) {}
    try {
        if (X.livePh) { X.livePh.locked = false; X.livePh.remove(); }
    } catch (e2) {}
    if (unhideTarget && X.target) {
        try { X.target.hidden = false; } catch (e3) {}
    }
    if (X.origActiveLayer) {
        try { X.doc.activeLayer = X.origActiveLayer; } catch (e4) {}
    }
    X.cageLayer = null;
    X.matrixHandleMode = null;
    X.grid = null;
    X.handles = null;
    X.livePh = null;
    X.lastCenters = null;
};

AIArtboardStudio._xfDrawCageGrid = function (X, mode, gx, gy, ptsFlat, guidesStr) {
    if (!X || !X.cageLayer || !X.cageBounds) return;
    try { if (X.grid) { X.grid.locked = false; X.grid.remove(); } } catch (e0) {}
    X.grid = null;
    var doc = X.doc, b = X.cageBounds;
    var g = X.cageLayer.groupItems.add();
    g.name = '__ABS_XF_GRID__';
    try { g.zOrder(ZOrderMethod.SENDTOBACK); } catch (z0) {}

    var outerBlue = AIArtboardStudio._xfColor(doc, 38, 128, 235);
    var innerCyan = AIArtboardStudio._xfColor(doc, 0, 185, 255);
    var splitGold = AIArtboardStudio._xfColor(doc, 255, 155, 0);
    var sz = AIArtboardStudio._xfHandleSize(b, doc);
    var swOuter = Math.max(1.2, Math.min(3.4, sz * 0.15));
    var swInner = Math.max(1.0, Math.min(2.8, sz * 0.12));
    var isSplitMode = (mode == 'splitH' || mode == 'splitV' || mode == 'splitX');

    var lines = String(guidesStr || '').split('|');
    for (var li = 0; li < lines.length; li++) {
        var nums = AIArtboardStudio._xfParseNums(lines[li]);
        if (nums.length < 4) continue;
        var pathPts = [];
        for (var pi = 0; pi + 1 < nums.length; pi += 2) {
            pathPts.push(AIArtboardStudio._xfNormToDoc(b, nums[pi], nums[pi + 1]));
        }
        var isRowOuter = (li === 0 || li === gy - 1);
        var isColOuter = (li === gy || li === gy + gx - 1);
        var isOuter = (isRowOuter || isColOuter);
        var isSplitLine = isSplitMode && !isOuter && (li < gy + gx);
        var p = g.pathItems.add();
        p.setEntirePath(pathPts);
        p.closed = false; p.filled = false; p.stroked = true;
        p.strokeColor = isOuter ? outerBlue : (isSplitLine ? splitGold : innerCyan);
        p.strokeWidth = isOuter ? swOuter : (isSplitLine ? swOuter * 1.05 : swInner);
    }

    if (mode == 'perspective' && ptsFlat && ptsFlat.length >= 8) {
        var d0 = AIArtboardStudio._xfNormToDoc(b, ptsFlat[0], ptsFlat[1]);
        var d1 = AIArtboardStudio._xfNormToDoc(b, ptsFlat[2], ptsFlat[3]);
        var d2 = AIArtboardStudio._xfNormToDoc(b, ptsFlat[4], ptsFlat[5]);
        var d3 = AIArtboardStudio._xfNormToDoc(b, ptsFlat[6], ptsFlat[7]);
        var diag1 = g.pathItems.add();
        diag1.setEntirePath([d0, d3]);
        diag1.closed = false; diag1.filled = false; diag1.stroked = true;
        diag1.strokeColor = innerCyan; diag1.strokeWidth = swInner * 0.9;
        var diag2 = g.pathItems.add();
        diag2.setEntirePath([d1, d2]);
        diag2.closed = false; diag2.filled = false; diag2.stroked = true;
        diag2.strokeColor = innerCyan; diag2.strokeWidth = swInner * 0.9;
    }
    g.locked = true;
    X.grid = g;
};

AIArtboardStudio._xfReadLinMatrix = function (item) {
    try {
        var m = item.matrix;
        return { a: m.mValueA, b: m.mValueB, c: m.mValueC, d: m.mValueD };
    } catch (e) { return null; }
};

AIArtboardStudio._xfRestoreFresh = function () {
    var X = AIArtboardStudio._xf;
    if (!X || !X.bak) return;
    AIArtboardStudio._xfClearOverlay(X);
    AIArtboardStudio._xfClearCage(X, false);
    try { X.target.locked = false; X.target.remove(); } catch (e1) {}
    X.bak.locked = false;
    X.bak.hidden = false;
    var fresh = X.bak.duplicate(X.bak, ElementPlacement.PLACEBEFORE);
    fresh.hidden = false;
    fresh.locked = false;
    try { if (X.origName) fresh.name = X.origName; } catch (e2) {}
    X.bak.hidden = true;
    X.bak.locked = true;
    X.target = fresh;
    var b = fresh.visibleBounds;
    X.origBox = [b[0], b[1], b[2], b[3]];
    X.lastItemLin = AIArtboardStudio._xfReadLinMatrix(fresh);
    X.isEnv = false;
    X.cur = { a: 1, b: 0, c: 0, d: 1 };
};

AIArtboardStudio._xfApplyMode = function (mode) {
    var X = AIArtboardStudio._xf;
    if (!X) return;
    var doc = X.doc, lvl = AIArtboardStudio._quietStart();
    try {
        X.mode = mode || 'free';
        if (AIArtboardStudio._xfIsMatrixMode(X.mode)) {
            if (X.isEnv) AIArtboardStudio._xfClearCage(X, true);
            X.isEnv = false;
            try { X.target.hidden = false; X.target.locked = false; } catch (u1) {}
            doc.selection = null;
            X.target.selected = true;
            AIArtboardStudio._xfDrawMatrixOverlay(X);
            AIArtboardStudio._xfSelectTool(X.mode);
            AIArtboardStudio._xfSelectTool('select');
            try { doc.selection = null; X.target.locked = true; } catch (lk1) {}
        } else {
            AIArtboardStudio._xfClearOverlay(X);
            doc.selection = null;
        }
        try { app.redraw(); } catch (rd) {}
        AIArtboardStudio._quietEnd(lvl);
    } catch (e) {
        AIArtboardStudio._quietEnd(lvl);
        throw e;
    }
};

AIArtboardStudio.xfBegin = function (mode) {
    var doc = null, chain = null;
    try {
        if (AIArtboardStudio._xf) AIArtboardStudio.xfEnd(true);
        doc = AIArtboardStudio._doc();
        var item = AIArtboardStudio._firstSelectedImage(doc);
        if (!item) throw new Error('حدد صورة واحدة (مضمّنة أو مرتبطة) داخل Illustrator أولًا.');
        chain = AIArtboardStudio._openLayerChain(AIArtboardStudio._layerFromItem(item));
        try { item.locked = false; item.hidden = false; } catch (u1) {}
        var origActiveLayer = null; try { origActiveLayer = doc.activeLayer; } catch (alErr) {}
        var origName = ''; try { origName = item.name; } catch (e1) {}
        var bak = item.duplicate(item, ElementPlacement.PLACEAFTER);
        bak.name = '__ABS_XF_BAK__';
        bak.hidden = true;
        bak.locked = true;
        var b = item.visibleBounds;
        AIArtboardStudio._xf = {
            doc: doc, target: item, bak: bak, origName: origName,
            mode: mode || 'free', isEnv: false, cur: { a: 1, b: 0, c: 0, d: 1 },
            origBox: [b[0], b[1], b[2], b[3]],
            lastItemLin: AIArtboardStudio._xfReadLinMatrix(item),
            layerChain: chain, origActiveLayer: origActiveLayer,
            overlay: null, cageLayer: null, matrixHandleMode: null, grid: null, handles: null, livePh: null, lastCenters: null
        };
        if (AIArtboardStudio._xfIsMatrixMode(AIArtboardStudio._xf.mode)) {
            AIArtboardStudio._xfApplyMode(AIArtboardStudio._xf.mode);
        } else {
            AIArtboardStudio._xfSelectTool('select');
        }
        b = AIArtboardStudio._xf.target.visibleBounds;
        return 'OK|{"bounds":[' + b[0] + ',' + b[1] + ',' + b[2] + ',' + b[3] + '],"name":' + AIArtboardStudio._jsq(origName || item.typename) + '}';
    } catch (e) {
        try { if (chain) AIArtboardStudio._restoreLayerChain(chain); } catch (rc) {}
        try { AIArtboardStudio.xfEnd(false); } catch (cleanErr) {}
        return AIArtboardStudio._result(false, e.message || e);
    }
};

AIArtboardStudio.xfSwitchMode = function (mode) {
    try {
        var X = AIArtboardStudio._xf;
        if (!X) throw new Error('لم تبدأ جلسة التحويل.');
        if (app.activeDocument !== X.doc) throw new Error('تغيّر المستند النشط أثناء التحويل.');
        AIArtboardStudio._xfApplyMode(mode);
        return AIArtboardStudio._result(true, 'switched');
    } catch (e) { return AIArtboardStudio._result(false, e.message || e); }
};

AIArtboardStudio.xfReset = function (mode) {
    try {
        var X = AIArtboardStudio._xf;
        if (!X) throw new Error('لم تبدأ جلسة التحويل.');
        if (app.activeDocument !== X.doc) throw new Error('تغيّر المستند النشط أثناء التحويل.');
        AIArtboardStudio._xfRestoreFresh();
        AIArtboardStudio._xfApplyMode(mode || X.mode);
        return AIArtboardStudio._result(true, 'reset');
    } catch (e) { return AIArtboardStudio._result(false, e.message || e); }
};

AIArtboardStudio.xfSet = function (sx, sy, rot, skx, sky, fh, fv) {
    try {
        var X = AIArtboardStudio._xf;
        if (!X) throw new Error('لم تبدأ جلسة التحويل.');
        if (app.activeDocument !== X.doc) throw new Error('تغيّر المستند النشط أثناء التحويل.');
        try { X.target.typename; } catch (e0) { AIArtboardStudio._xf = null; throw new Error('الصورة لم تعد موجودة في المستند.'); }
        if (!(sx > 0.5 && sy > 0.5)) throw new Error('نسبة التحجيم صغيرة جدًا.');
        var lvl = AIArtboardStudio._quietStart();
        try { X.target.locked = false; } catch (e1) {}
        var next = AIArtboardStudio._xfMatrix(sx, sy, rot, skx, sky, !!fh, !!fv);
        var delta = AIArtboardStudio._mmul(next, AIArtboardStudio._minv(X.cur));
        X.target.transform(AIArtboardStudio._toMatrix(delta), true, true, true, true, 1, Transformation.CENTER);
        X.cur = next;
        X.lastItemLin = AIArtboardStudio._xfReadLinMatrix(X.target);
        AIArtboardStudio._xfDrawMatrixOverlay(X);
        try { X.doc.selection = null; X.target.locked = true; } catch (lk2) {}
        try { app.redraw(); } catch (e2) {}
        AIArtboardStudio._quietEnd(lvl);
        return AIArtboardStudio._result(true, 'xf');
    } catch (e) {
        try { AIArtboardStudio._quietEnd(null); } catch (qe) {}
        return AIArtboardStudio._result(false, e.message || e);
    }
};

AIArtboardStudio.xfMatrixSync = function () {
    try {
        var X = AIArtboardStudio._xf;
        if (!X || !AIArtboardStudio._xfIsMatrixMode(X.mode) || !X.target) return AIArtboardStudio._result(true, 'skip');
        var curLin = AIArtboardStudio._xfReadLinMatrix(X.target);
        if (!curLin || !X.lastItemLin) return AIArtboardStudio._result(true, 'same');
        var diff = Math.abs(curLin.a - X.lastItemLin.a) + Math.abs(curLin.b - X.lastItemLin.b) +
                   Math.abs(curLin.c - X.lastItemLin.c) + Math.abs(curLin.d - X.lastItemLin.d);
        if (diff > 1e-4) {
            try {
                var delta = AIArtboardStudio._mmul(curLin, AIArtboardStudio._minv(X.lastItemLin));
                X.cur = AIArtboardStudio._mmul(delta, X.cur);
                X.lastItemLin = curLin;
                AIArtboardStudio._xfDrawMatrixOverlay(X);
                try { app.redraw(); } catch (rd) {}
                return AIArtboardStudio._result(true, 'synced');
            } catch (invErr) {}
        }
        return AIArtboardStudio._result(true, 'same');
    } catch (e) { return AIArtboardStudio._result(true, 'skip'); }
};

AIArtboardStudio.xfCageBegin = function (mode, framePath, gx, gy, ptsStr, guidesStr) {
    var X = AIArtboardStudio._xf, lvl = null;
    try {
        if (!X) throw new Error('لم تبدأ جلسة التحويل.');
        if (app.activeDocument !== X.doc) throw new Error('تغيّر المستند النشط أثناء التحويل.');
        lvl = AIArtboardStudio._quietStart();
        var doc = X.doc;
        AIArtboardStudio._xfClearOverlay(X);
        AIArtboardStudio._xfClearCage(X, true);

        try { X.target.locked = false; X.target.hidden = false; } catch (t0) {}
        var b = X.target.visibleBounds;
        X.cageBounds = [b[0], b[1], b[2], b[3]];
        X.cageMode = String(mode);
        X.mode = String(mode);
        X.cageGx = parseInt(gx, 10) || 2;
        X.cageGy = parseInt(gy, 10) || 2;
        X.isEnv = true;

        var hasFrame = false, f = null;
        if (framePath && String(framePath).length > 0) {
            f = new File(framePath);
            hasFrame = !!f.exists;
            if (!hasFrame) throw new Error('تعذّر العثور على صورة المعاينة.');
        }

        if (hasFrame) {
            var container = X.target.parent;
            var ph;
            try { ph = container.placedItems.add(); } catch (e1) { ph = X.target.layer.placedItems.add(); }
            ph.file = f;
            AIArtboardStudio._liveFit(ph, X.cageBounds);
            ph.name = '__ABS_XF_LIVE__';
            try { ph.move(X.target, ElementPlacement.PLACEBEFORE); } catch (e2) {}
            ph.locked = true;
            X.livePh = ph;
            try { X.target.hidden = true; X.target.locked = true; } catch (e3) {}
        } else {
            // Instant handle placement while mesh is at identity: keep target visible & locked until first drag
            X.livePh = null;
            try { X.target.hidden = false; X.target.locked = true; } catch (e3b) {}
        }

        var cl = doc.layers.add();
        cl.name = '__ABS_XF_CAGE__';
        X.cageLayer = cl;

        var ptsFlat = AIArtboardStudio._xfParseNums(ptsStr);
        AIArtboardStudio._xfDrawCageGrid(X, X.cageMode, X.cageGx, X.cageGy, ptsFlat, guidesStr);

        var sz = AIArtboardStudio._xfHandleSize(X.cageBounds, doc);
        var sw = Math.max(1.2, Math.min(3.2, sz * 0.16));
        var cornerBlue = AIArtboardStudio._xfColor(doc, 38, 128, 235);
        var splitCyan = AIArtboardStudio._xfColor(doc, 0, 185, 255);
        var splitGold = AIArtboardStudio._xfColor(doc, 255, 155, 0);
        var white = AIArtboardStudio._xfColor(doc, 255, 255, 255);
        var isSplitMode = (X.cageMode == 'splitH' || X.cageMode == 'splitV' || X.cageMode == 'splitX');

        X.handles = [];
        X.lastCenters = [];
        var count = Math.floor(ptsFlat.length / 2);
        for (var k = 0; k < count; k++) {
            var pos = AIArtboardStudio._xfNormToDoc(X.cageBounds, ptsFlat[k * 2], ptsFlat[k * 2 + 1]);
            var row = Math.floor(k / X.cageGx), col = k % X.cageGx;
            var isCorner = (row === 0 || row === X.cageGy - 1) && (col === 0 || col === X.cageGx - 1);
            var isSplitPt = isSplitMode && !isCorner;
            var h = null;
            if (isSplitPt) {
                var r = sz * 0.62;
                h = cl.pathItems.add();
                h.setEntirePath([[pos[0], pos[1] + r], [pos[0] + r, pos[1]], [pos[0], pos[1] - r], [pos[0] - r, pos[1]]]);
                h.closed = true;
            } else {
                h = cl.pathItems.rectangle(pos[1] + sz / 2, pos[0] - sz / 2, sz, sz);
            }
            h.name = '__ABS_XF_H_' + k;
            h.filled = true; h.fillColor = white;
            h.stroked = true;
            h.strokeColor = isCorner ? cornerBlue : (isSplitPt ? splitGold : splitCyan);
            h.strokeWidth = sw;
            X.handles.push(h);
            X.lastCenters.push([pos[0], pos[1]]);
        }
        try { if (X.origActiveLayer) doc.activeLayer = X.origActiveLayer; } catch (alR) {}
        try { doc.selection = null; } catch (selR) {}
        AIArtboardStudio._xfSelectTool('select');
        try { app.redraw(); } catch (rd) {}
        AIArtboardStudio._quietEnd(lvl);
        return AIArtboardStudio._result(true, 'cage');
    } catch (e) {
        AIArtboardStudio._xfClearCage(X, true);
        AIArtboardStudio._quietEnd(lvl);
        return AIArtboardStudio._result(false, e.message || e);
    }
};

AIArtboardStudio.xfCagePoll = function (commit) {
    var X = AIArtboardStudio._xf;
    try {
        if (!X || !X.handles || !X.handles.length || !X.cageBounds) return 'OK|same';
        if (app.activeDocument !== X.doc) return 'OK|same';
        var doCommit = (commit !== false);
        var dirty = false, movedIdx = -1, maxD = 0, centers = [], i;
        for (i = 0; i < X.handles.length; i++) {
            var h = X.handles[i], hb = h.visibleBounds;
            var cx = (hb[0] + hb[2]) / 2, cy = (hb[1] + hb[3]) / 2;
            centers.push([cx, cy]);
            var d = Math.abs(cx - X.lastCenters[i][0]) + Math.abs(cy - X.lastCenters[i][1]);
            if (d > 0.25) {
                dirty = true;
                if (d > maxD) { maxD = d; movedIdx = i; }
            }
        }
        if (!dirty) return 'OK|same';
        if (!X.isEnv && AIArtboardStudio._xfIsMatrixMode(X.mode)) {
            var ox = X.lastCenters[movedIdx][0], oy = X.lastCenters[movedIdx][1];
            var nx = centers[movedIdx][0], ny = centers[movedIdx][1];
            if (doCommit) {
                for (i = 0; i < centers.length; i++) X.lastCenters[i] = centers[i];
            }
            var mcx = X.matrixCenter ? X.matrixCenter[0] : (X.cageBounds[0] + X.cageBounds[2]) / 2;
            var mcy = X.matrixCenter ? X.matrixCenter[1] : (X.cageBounds[1] + X.cageBounds[3]) / 2;
            var mhx = X.matrixHalf ? X.matrixHalf[0] : Math.max(1, (X.cageBounds[2] - X.cageBounds[0]) / 2);
            var mhy = X.matrixHalf ? X.matrixHalf[1] : Math.max(1, (X.cageBounds[1] - X.cageBounds[3]) / 2);
            return 'OK|mhandle|' + movedIdx + '|' + [ox, oy, nx, ny, mcx, mcy, mhx, mhy].join(',');
        }
        var coords = [];
        for (i = 0; i < centers.length; i++) {
            if (doCommit) X.lastCenters[i] = centers[i];
            var uv = AIArtboardStudio._xfDocToNorm(X.cageBounds, centers[i][0], centers[i][1]);
            coords.push(Math.round(uv[0] * 10000) / 10000);
            coords.push(Math.round(uv[1] * 10000) / 10000);
        }
        return 'OK|moved|' + movedIdx + '|' + coords.join(',');
    } catch (e) { return 'OK|same'; }
};

AIArtboardStudio.xfCageFrame = function (framePath, nbStr, mode, guidesStr, ptsStr, syncHandles) {
    var X = AIArtboardStudio._xf, lvl = null;
    try {
        if (!X || !X.cageLayer) throw new Error('انتهت جلسة التحويل.');
        if (app.activeDocument !== X.doc) throw new Error('تغيّر المستند النشط.');
        var f = new File(framePath);
        if (!f.exists) throw new Error('ملف الإطار غير موجود.');
        lvl = AIArtboardStudio._quietStart();

        var nb = AIArtboardStudio._xfParseNums(nbStr);
        var fr = AIArtboardStudio._liveFrameRect(X.cageBounds, nb);
        if (!X.livePh) {
            var container = X.target.parent;
            var ph;
            try { ph = container.placedItems.add(); } catch (e1) { ph = X.target.layer.placedItems.add(); }
            ph.file = f;
            AIArtboardStudio._liveFit(ph, fr);
            ph.name = '__ABS_XF_LIVE__';
            try { ph.move(X.target, ElementPlacement.PLACEBEFORE); } catch (e2) {}
            ph.locked = true;
            X.livePh = ph;
            try { X.target.hidden = true; X.target.locked = true; } catch (e3) {}
        } else {
            X.livePh.locked = false;
            X.livePh.file = f;
            AIArtboardStudio._liveFit(X.livePh, fr);
            X.livePh.locked = true;
        }

        var ptsFlat = AIArtboardStudio._xfParseNums(ptsStr);
        AIArtboardStudio._xfDrawCageGrid(X, String(mode), X.cageGx, X.cageGy, ptsFlat, guidesStr);

        if (X.handles && ptsFlat.length >= X.handles.length * 2) {
            for (var k = 0; k < X.handles.length; k++) {
                var pos = AIArtboardStudio._xfNormToDoc(X.cageBounds, ptsFlat[k * 2], ptsFlat[k * 2 + 1]);
                if (syncHandles) {
                    var h = X.handles[k], hb = h.visibleBounds;
                    var dx = pos[0] - (hb[0] + hb[2]) / 2, dy = pos[1] - (hb[1] + hb[3]) / 2;
                    if (Math.abs(dx) > 0.05 || Math.abs(dy) > 0.05) h.translate(dx, dy);
                }
                X.lastCenters[k] = [pos[0], pos[1]];
            }
        }
        try { app.redraw(); } catch (rd) {}
        AIArtboardStudio._quietEnd(lvl);
        return AIArtboardStudio._result(true, 'frame');
    } catch (e) {
        AIArtboardStudio._quietEnd(lvl);
        return AIArtboardStudio._result(false, e.message || e);
    }
};

AIArtboardStudio.xfCageBake = function (bakedPath, nbStr, keepSession, nextMode) {
    var X = AIArtboardStudio._xf, lvl = null;
    try {
        if (!X || !X.doc) throw new Error('لم تبدأ جلسة التحويل.');
        lvl = AIArtboardStudio._quietStart();
        var doc = X.doc;
        var f = new File(bakedPath);
        if (!f.exists) throw new Error('ملف التحويل النهائي غير موجود.');
        var nb = AIArtboardStudio._xfParseNums(nbStr);
        var pb = AIArtboardStudio._liveFrameRect(X.cageBounds, nb);

        AIArtboardStudio._xfClearCage(X, true);
        var container = X.target.parent;
        var placed;
        try { placed = container.placedItems.add(); } catch (e1) { placed = X.target.layer.placedItems.add(); }
        placed.file = f;
        AIArtboardStudio._liveFit(placed, pb);
        doc.selection = null;
        placed.selected = true;
        placed.embed();
        var result = (doc.selection && doc.selection.length) ? doc.selection[0] : null;
        if (!result) { try { result = container.pageItems[0]; } catch (e2) {} }
        if (!result) throw new Error('تعذّر تضمين الصورة المحوّلة.');
        try { result.move(X.target, ElementPlacement.PLACEBEFORE); } catch (e3) {}
        try { if (X.origName) result.name = X.origName; } catch (e4) {}
        try { X.target.locked = false; X.target.remove(); } catch (e5) {}
        X.target = result;
        X.isEnv = false;
        X.cur = { a: 1, b: 0, c: 0, d: 1 };
        X.origBox = [pb[0], pb[1], pb[2], pb[3]];
        X.lastItemLin = AIArtboardStudio._xfReadLinMatrix(result);
        AIArtboardStudio._crTarget = result;

        if (keepSession) {
            if (nextMode) AIArtboardStudio._xfApplyMode(nextMode);
            AIArtboardStudio._quietEnd(lvl);
            return AIArtboardStudio._result(true, 'baked');
        }
        if (X.bak) { try { X.bak.locked = false; X.bak.hidden = false; X.bak.remove(); } catch (b1) {} }
        if (X.layerChain) AIArtboardStudio._restoreLayerChain(X.layerChain);
        AIArtboardStudio._xf = null;
        try { result.locked = false; result.hidden = false; doc.selection = null; result.selected = true; } catch (s1) {}
        AIArtboardStudio._xfSelectTool('select');
        try { app.redraw(); } catch (rd) {}
        AIArtboardStudio._quietEnd(lvl);
        return AIArtboardStudio._result(true, 'kept');
    } catch (e) {
        AIArtboardStudio._quietEnd(lvl);
        return AIArtboardStudio._result(false, e.message || e);
    }
};

AIArtboardStudio.xfEnd = function (keep) {
    var X = AIArtboardStudio._xf;
    AIArtboardStudio._xf = null;
    if (!X) return AIArtboardStudio._result(true, 'none');
    var lvl = AIArtboardStudio._quietStart();
    try {
        AIArtboardStudio._xfClearOverlay(X);
        AIArtboardStudio._xfClearCage(X, true);
        if (keep) {
            try { X.target.locked = false; X.target.hidden = false; } catch (ul1) {}
            try { if (X.origName) X.target.name = X.origName; } catch (n1) {}
            if (X.bak) {
                try { X.bak.locked = false; X.bak.hidden = false; X.bak.remove(); } catch (b1) {}
            }
            try { X.doc.selection = null; X.target.selected = true; } catch (s1) {}
        } else {
            try { X.target.locked = false; X.target.remove(); } catch (t1) {}
            if (X.bak) {
                try {
                    X.bak.locked = false; X.bak.hidden = false;
                    if (X.origName) X.bak.name = X.origName;
                    X.doc.selection = null; X.bak.selected = true;
                } catch (b2) {}
            }
        }
        if (X.layerChain) AIArtboardStudio._restoreLayerChain(X.layerChain);
        AIArtboardStudio._xfSelectTool('select');
        try { app.redraw(); } catch (e2) {}
        AIArtboardStudio._quietEnd(lvl);
        return AIArtboardStudio._result(true, keep ? 'kept' : 'reverted');
    } catch (e) {
        try { if (X.layerChain) AIArtboardStudio._restoreLayerChain(X.layerChain); } catch (rc) {}
        AIArtboardStudio._quietEnd(lvl);
        return AIArtboardStudio._result(false, e.message || e);
    }
};

AIArtboardStudio.xfNativeTool = function (name) {
    try {
        var X = AIArtboardStudio._xf;
        var t = AIArtboardStudio._xfToolMap[name];
        if (!t) throw new Error('أداة غير معروفة.');
        if (X && X.target && AIArtboardStudio._xfIsMatrixMode(name || X.mode)) {
            try { X.doc.selection = null; X.target.selected = true; } catch (sErr) {}
        }
        app.selectTool(t);
        try { app.redraw(); } catch (rd) {}
        return AIArtboardStudio._result(true, 'tool');
    } catch (e) { return AIArtboardStudio._result(false, 'تعذّر تفعيل الأداة الأصلية في هذا الإصدار (' + (e.message || e) + ').'); }
};

AIArtboardStudio.xfRunMenu = function (cmd) {
    try {
        var X = AIArtboardStudio._xf;
        if (!X) throw new Error('لم تبدأ جلسة التحويل.');
        if (app.activeDocument !== X.doc) throw new Error('تغيّر المستند النشط أثناء التحويل.');
        X.doc.selection = null;
        if (X.target && !X.target.hidden) X.target.selected = true;
        app.executeMenuCommand(cmd);
        try { app.redraw(); } catch (rd) {}
        return AIArtboardStudio._result(true, 'menu');
    } catch (e) {
        return AIArtboardStudio._result(false, e.message || e);
    }
};

AIArtboardStudio.cropAllLayers = function (includeHidden, scope) {
    var doc, originalLayer, batches, processed = 0, elementCount = 0, inside = 0, outside = 0, skipped = 0, errors = [], lvl = null;
    try {
        lvl = AIArtboardStudio._quietStart();
        doc = AIArtboardStudio._doc();
        originalLayer = doc.activeLayer;
        var r = AIArtboardStudio._artboard(doc);
        var left = r[0], top = r[1], width = r[2] - r[0], height = r[1] - r[3];
        var whiteColor;
        if (doc.documentColorSpace == DocumentColorSpace.CMYK) {
            whiteColor = new CMYKColor(); whiteColor.cyan = 0; whiteColor.magenta = 0; whiteColor.yellow = 0; whiteColor.black = 0;
        } else {
            whiteColor = new RGBColor(); whiteColor.red = 255; whiteColor.green = 255; whiteColor.blue = 255;
        }
        batches = AIArtboardStudio._elementBatches(doc, scope, includeHidden);

        for (var i = 0; i < batches.length; i++) {
            var batch = batches[i], layer = batch.layer;
            if (AIArtboardStudio._shouldSkipLayer(layer, includeHidden)) { skipped += batch.items.length; continue; }
            var crossing = [];
            for (var ci = 0; ci < batch.items.length; ci++) {
                var cand = batch.items[ci];
                var ib = AIArtboardStudio._itemBounds(cand);
                if (!ib || !AIArtboardStudio._rectsIntersect(ib, r)) { outside++; continue; }
                if (AIArtboardStudio._rectInside(ib, r)) { inside++; continue; }
                crossing.push(cand);
            }
            if (!crossing.length) continue;

            var layerChain = AIArtboardStudio._openLayerChain(layer);
            try {
                doc.activeLayer = layer;
                for (var j = 0; j < crossing.length; j++) {
                    var item = crossing[j];
                    var oneItemBatch = { parent: batch.parent, layer: layer, items: [item] };
                    var objectStates = AIArtboardStudio._unlockBatchObjects(oneItemBatch);
                    var workGrp = null, cropRect = null, movedIn = false;
                    try {
                        doc.selection = null;
                        workGrp = batch.parent.groupItems.add();
                        workGrp.move(item, ElementPlacement.PLACEBEFORE);
                        cropRect = workGrp.pathItems.rectangle(top, left, width, height);
                        cropRect.name = 'TEMP — Artboard Crop Boundary';
                        cropRect.filled = true;
                        cropRect.stroked = false;
                        cropRect.fillColor = whiteColor;
                        item.move(workGrp, ElementPlacement.PLACEATEND);
                        movedIn = true;
                        workGrp.selected = true;
                        app.executeMenuCommand('Live Pathfinder Crop');
                        app.executeMenuCommand('expandStyle');
                        try { app.executeMenuCommand('ungroup'); } catch (ungroupError) {}
                        doc.selection = null;
                        elementCount++;
                        processed++;
                    } catch (itemError) {
                        try { if (cropRect) cropRect.remove(); } catch (removeCropError) {}
                        if (movedIn && workGrp) {
                            try { item.move(workGrp, ElementPlacement.PLACEBEFORE); } catch (moveOutErr) {}
                        }
                        try { if (workGrp) workGrp.remove(); } catch (removeGrpErr) {}
                        try { doc.selection = null; } catch (selectionResetError) {}
                        var itemName = 'عنصر ' + (j + 1);
                        try { if (item.name) itemName = item.name; } catch (nameError) {}
                        errors.push(itemName + ': ' + (itemError.message || itemError));
                    }
                    AIArtboardStudio._restoreBatchObjects(objectStates);
                }
            } catch (batchError) {
                errors.push((scope == 'selected' ? 'مجموعة عناصر' : layer.name) + ': ' + (batchError.message || batchError));
            }
            AIArtboardStudio._restoreLayerChain(layerChain);
        }
        try { doc.activeLayer = originalLayer; } catch (activeError) {}
        if (processed < 1 && inside < 1 && errors.length) throw new Error('لم تنجح عملية القصّ: ' + errors.join(' | '));
        if (processed < 1 && inside < 1) throw new Error('لم يتم العثور على عناصر متقاطعة مع الـArtboard النشط لقصّها. للصور استخدم أداة «ماسك للصور».');
        var msg = processed > 0
            ? ('اكتمل القصّ الفعلي لـ ' + elementCount + ' عنصر على الـArtboard النشط.')
            : ('جميع العناصر (' + inside + ') تقع بالفعل داخل حدود الـArtboard النشط فلم تحتج إلى قصّ.');
        if (processed > 0 && inside) msg += ' تم الإبقاء على ' + inside + ' عنصرًا داخل الحدود دون تغيير لتسريع المعالجة.';
        if (outside) msg += ' تُرك ' + outside + ' عنصر خارج الـArtboard النشط دون مساس.';
        if (skipped) msg += ' تم تجاوز ' + skipped + ' عنصرًا في طبقات مخفية أو مقفلة.';
        if (errors.length) msg += ' عناصر لم تكتمل: ' + errors.join(' | ');
        AIArtboardStudio._quietEnd(lvl);
        return AIArtboardStudio._result(true, msg);
    } catch (e) {
        try { if (doc && originalLayer) doc.activeLayer = originalLayer; } catch (restoreError) {}
        AIArtboardStudio._quietEnd(lvl);
        return AIArtboardStudio._result(false, e.message || e);
    }
};

AIArtboardStudio._qrIcons = {
    whatsapp: { hex: "#25D366", subs: [[[17.472,14.382,17.472,14.382,17.175,14.233],[15.442,13.415,15.714,13.515,15.169,13.316],[14.772,13.565,14.971,13.267,14.575,13.862],[13.832,14.729,14.005,14.531,13.659,14.928],[13.188,14.804,13.485,14.952,12.891,14.654],[10.798,13.329,11.933,14.341,9.915,12.541],[9.145,11.27,9.318,11.568,8.972,10.973],[9.275,10.664,9.127,10.812,9.409,10.531],[9.721,10.144,9.573,10.317,9.87,9.97],[10.019,9.647,9.919,9.846,10.118,9.449],[9.994,9.127,10.069,9.276,9.919,8.978],[9.078,6.92,9.325,7.515,8.836,6.341],[8.409,6.41,8.591,6.42,8.236,6.402],[7.839,6.4,8.038,6.4,7.641,6.4],[7.047,6.772,7.319,6.474,6.775,7.069],[6.007,9.251,6.007,7.788,6.007,10.713],[7.22,12.325,7.072,12.126,7.369,12.523],[12.297,16.812,9.316,15.525,13.006,17.118],[13.991,17.437,13.559,17.301,14.703,17.664],[15.862,17.555,15.351,17.632,16.433,17.47],[17.868,16.142,17.62,16.836,18.116,15.448],[18.041,14.729,18.116,14.853,17.967,14.605],[17.471,14.382,17.769,14.531,17.471,14.382]],[[12.05,21.785,17.498,21.785,12.05,21.785],[12.046,21.785,12.046,21.785,10.276,21.785],[7.015,20.407,8.538,21.309,7.015,20.407],[6.654,20.193,6.654,20.193,6.654,20.193],[2.913,21.175,2.913,21.175,2.913,21.175],[3.911,17.527,3.911,17.527,3.911,17.527],[3.676,17.153,3.676,17.153,2.686,15.577],[2.166,11.893,2.163,13.754,2.167,6.443],[12.054,2.009,6.602,2.009,14.694,2.009],[19.042,4.907,17.176,3.039,20.902,6.758],[21.935,11.901,21.943,9.277,21.932,17.351]],[[20.463,3.488,22.7,5.715,18.237,1.248],[12.05,0,15.208,-0.008,5.495,0],[0.157,11.892,0.16,5.335,0.157,13.988],[1.745,17.837,0.704,16.034,1.745,17.837],[0.057,24,0.057,24,0.057,24],[6.362,22.346,6.362,22.346,8.106,23.296],[12.045,23.794,10.059,23.794,12.045,23.794],[12.05,23.794,12.05,23.794,18.604,23.794],[23.943,11.901,23.94,18.459,23.953,8.745]]] },
    instagram: { hex: "#FF0069", subs: [[[7.03,0.084,7.03,0.084,5.753,0.144],[4.119,0.647,4.881,0.348,3.33,0.955],[1.996,2.035,2.662,1.367,1.331,2.703],[0.616,4.162,0.921,3.372,0.321,4.926],[0.064,7.076,0.12,5.799,0.008,8.354],[0.001,12.023,-0.005,8.764,0.008,15.282],[0.084,16.97,0.022,15.69,0.145,18.247],[0.647,19.881,0.348,19.119,0.955,20.67],[2.035,22.004,1.367,21.338,2.703,22.669],[4.164,23.384,3.372,23.078,4.927,23.679],[7.077,23.936,5.8,23.88,8.355,23.992],[12.024,23.999,8.766,24.005,15.281,23.992],[16.971,23.917,15.692,23.978,18.251,23.856],[19.881,23.354,19.118,23.652,20.67,23.045],[22.004,21.966,21.339,22.634,22.669,21.298],[23.383,19.837,23.079,20.628,23.679,19.074],[23.935,16.925,23.88,18.201,23.992,15.644],[23.998,11.977,24.005,15.235,23.992,8.719],[23.917,7.03,23.977,8.31,23.856,5.751],[23.353,4.119,23.653,4.882,23.045,3.33],[21.966,1.996,22.633,2.662,21.298,1.33],[19.838,0.617,20.628,0.921,19.074,0.321],[16.924,0.065,18.202,0.12,15.647,0.009],[11.977,0.001,15.236,-0.005,8.718,0.008],[7.03,0.084,8.31,0.022,7.03,0.084]],[[7.17,21.777,7.17,21.777,6,21.726],[4.942,21.369,5.365,21.532,4.381,21.153],[3.56,20.474,3.982,20.892,3.138,20.056],[2.66,19.096,2.879,19.656,2.495,18.673],[2.243,16.868,2.297,18.038,2.183,15.604],[2.164,12.02,2.171,15.224,2.157,8.816],[2.224,7.172,2.169,8.437,2.274,6.003],[2.632,4.944,2.47,5.367,2.848,4.383],[3.527,3.562,3.109,3.984,3.946,3.141],[4.906,2.662,4.346,2.881,5.329,2.497],[7.133,2.245,5.963,2.301,8.398,2.185],[11.981,2.166,8.777,2.173,15.184,2.159],[16.83,2.227,15.564,2.171,17.999,2.277],[19.058,2.635,18.635,2.471,19.619,2.851],[20.44,3.53,20.018,3.11,20.861,3.949],[21.34,4.908,21.121,4.347,21.505,5.33],[21.757,7.135,21.702,5.964,21.817,8.4],[21.837,11.983,21.831,8.78,21.842,15.186],[21.776,16.831,21.831,15.566,21.725,18.001],[21.368,19.06,21.531,18.636,21.152,19.621],[20.472,20.441,20.891,20.02,20.053,20.863],[19.094,21.341,19.654,21.123,18.672,21.506],[16.868,21.759,18.036,21.703,15.602,21.818],[12.019,21.838,15.223,21.831,8.814,21.845],[7.171,21.777,8.436,21.832,7.171,21.777]],[[16.953,5.586,16.952,4.791,16.954,6.169],[17.844,6.915,17.306,6.693,18.383,7.137],[19.413,6.6,19.002,7.013,19.824,6.188],[19.722,5.03,19.946,5.568,19.498,4.493],[18.39,4.144,18.972,4.143,17.595,4.146]],[[5.839,12.012,5.832,8.609,5.845,15.415],[12.012,18.161,8.609,18.168,15.414,18.155],[18.162,11.988,18.169,15.391,18.156,8.585],[11.988,5.838,15.391,5.831,8.585,5.845]],[[8,12.008,8.002,13.069,7.996,9.799],[11.992,8,9.783,8.004,14.201,7.995],[16,11.992,15.996,9.783,16.004,14.201],[12.008,16,14.217,15.995,10.947,16.002],[9.177,14.834,9.929,15.583,8.425,14.085]]] },
    x: { hex: "#000000", subs: [[[18.901,1.153,18.901,1.153,18.901,1.153],[22.581,1.153,22.581,1.153,22.581,1.153],[14.541,10.343,14.541,10.343,14.541,10.343],[24,22.846,24,22.846,24,22.846],[16.594,22.846,16.594,22.846,16.594,22.846],[10.794,15.262,10.794,15.262,10.794,15.262],[4.156,22.846,4.156,22.846,4.156,22.846],[0.474,22.846,0.474,22.846,0.474,22.846],[9.074,13.016,9.074,13.016,9.074,13.016],[0,1.154,0,1.154,0,1.154],[7.594,1.154,7.594,1.154,7.594,1.154],[12.837,8.086,12.837,8.086,12.837,8.086]],[[17.61,20.644,17.61,20.644,17.61,20.644],[19.649,20.644,19.649,20.644,19.649,20.644],[6.486,3.24,6.486,3.24,6.486,3.24],[4.298,3.24,4.298,3.24,4.298,3.24]]] },
    telegram: { hex: "#26A5E4", subs: [[[11.944,0,11.963,0,5.338,0.031],[0,12,0,5.394,0,18.627],[12,24,5.373,24,18.627,24],[24,12,24,18.627,24,5.373],[12,0,18.627,0,11.981,0]],[[16.906,7.224,16.455,7.232,17.006,7.222],[17.371,7.364,17.227,7.247,17.467,7.447],[17.542,7.689,17.528,7.563,17.558,7.782],[17.562,8.161,17.578,7.995,17.382,10.059],[16.202,16.788,16.6,14.663,16.034,17.688],[15.382,18.018,15.703,17.989,14.686,18.083],[13.482,17.116,14.157,17.558,12.426,16.423],[10.804,15.316,11.829,15.992,9.619,14.536],[11.062,13.406,10.387,14.106,11.239,13.222],[14.369,10.176,14.309,10.429,14.376,10.144],[14.313,9.964,14.383,10.026,14.243,9.902],[14.064,9.94,14.139,9.923,13.958,9.964],[9.003,13.285,12.271,11.08,8.523,13.615],[7.701,13.765,8.09,13.775,7.273,13.757],[5.836,13.325,6.449,13.524,5.084,13.08],[4.539,12.536,4.487,12.951,4.566,12.32],[5.432,11.873,4.864,12.099,8.93,10.349],[12.43,8.859,11.262,9.344,15.762,7.473]]] },
    facebook: { hex: "#0866FF", subs: [[[9.101,23.691,3.874,22.394,9.101,23.691],[9.101,15.711,9.101,15.711,9.101,15.711],[6.627,15.711,6.627,15.711,6.627,15.711],[6.627,12.044,6.627,12.044,6.627,12.044],[9.101,12.044,9.101,12.044,9.101,12.044],[9.101,10.464,9.101,10.464,9.101,6.379],[14.959,4.486,10.949,4.486,15.36,4.486],[16.427,4.589,15.914,4.528,16.811,4.629],[17.568,4.784,17.192,4.694,17.568,4.784],[17.568,8.109,17.568,8.109,17.351,8.089],[16.915,8.073,17.133,8.077,16.671,8.067],[16.182,8.064,16.426,8.064,15.475,8.064],[14.507,8.373,14.923,8.16,14.227,8.513],[13.828,8.995,13.992,8.729,13.57,9.415],[13.454,10.747,13.454,9.99,13.454,10.747],[13.454,12.044,13.454,12.044,13.454,12.044],[17.373,12.044,17.373,12.044,17.373,12.044],[16.987,14.147,16.987,14.147,16.987,14.147],[16.7,15.711,16.7,15.711,16.7,15.711],[13.454,15.711,13.454,15.711,13.454,15.711],[13.454,23.956,13.454,23.956,19.396,23.238],[24,12.044,24,18.179,24,5.417],[12,0.044,18.627,0.044,5.373,0.044],[0,12.044,0,5.417,0,17.672]]] },
    tiktok: { hex: "#000000", subs: [[[12.525,0.02,12.495,4.04,13.835,0],[16.435,0,15.135,0.01,16.515,1.53],[18.185,4.17,17.065,3.09,19.305,5.28],[22.425,5.96,20.885,5.79,22.425,5.96],[22.425,9.99,22.425,9.99,20.985,9.94],[18.225,9.02,19.535,9.64,17.655,8.76],[16.605,8.09,17.125,8.43,16.595,11.01],[16.585,16.84,16.615,13.93,16.505,18.24],[15.235,20.78,16.045,19.63,13.925,22.7],[9.325,23.99,11.655,23.95,7.895,24.07],[5.245,22.96,6.465,23.68,3.225,21.77],[1.595,17.25,1.805,19.59,1.575,16.75],[1.585,15.76,1.565,16.25,1.765,13.86],[4.165,10.8,2.705,12.04,5.825,9.36],[10.315,9.08,8.145,8.67,10.335,10.56],[10.275,13.52,10.275,12.04,9.285,13.2],[7.255,13.89,8.125,13.29,6.625,14.3],[5.895,15.64,6.145,14.93,5.685,16.15],[5.755,17.25,5.745,16.71,5.995,18.89],[9.255,20.12,7.575,20.27,10.375,20.11],[12.025,18.51,11.445,19.46,12.215,18.18],[12.435,17.45,12.425,17.84,12.535,15.66],[12.505,12.09,12.495,13.88,12.515,8.06]]] },
    youtube: { hex: "#FF0000", subs: [[[23.498,6.186,24,8.07,23.222,5.147],[21.376,4.05,22.414,4.333,19.505,3.545],[12,3.545,12,3.545,12,3.545],[2.623,4.05,4.495,3.545,1.586,4.333],[0.502,6.186,0.778,5.147,0,8.07],[0,12,0,12,0,12],[0.502,17.814,0,15.93,0.778,18.853],[2.624,19.95,1.586,19.667,4.495,20.455],[12,20.455,12,20.455,12,20.455],[21.377,19.95,19.505,20.455,22.415,19.667],[23.499,17.814,23.223,18.854,24,15.93],[24,12,24,12,24,12]],[[9.545,15.568,9.545,15.568,9.545,15.568],[9.545,8.432,9.545,8.432,9.545,8.432],[15.818,12,15.818,12,15.818,12]]] }
};

AIArtboardStudio._drawQRIcon = function (doc, group, centerX, centerY, holeSize, moduleSize, whiteColor, blackColor, iconKey) {
    var def = AIArtboardStudio._qrIcons && AIArtboardStudio._qrIcons[iconKey];
    if (!def || !def.subs || !def.subs.length) return false;
    var badgeSize = Math.max(moduleSize * 3, holeSize - moduleSize * 0.2);
    var badgeLeft = centerX - badgeSize / 2;
    var badgeTop = centerY + badgeSize / 2;
    var badgeRad = badgeSize * 0.22;
    var badge;
    try { badge = group.pathItems.roundedRectangle(badgeTop, badgeLeft, badgeSize, badgeSize, badgeRad, badgeRad); }
    catch (rr) { badge = group.pathItems.rectangle(badgeTop, badgeLeft, badgeSize, badgeSize); }
    badge.name = 'QR — Icon Badge';
    badge.stroked = false;
    badge.filled = true;
    badge.fillColor = whiteColor;

    var brandColor = (def.hex == '#000000') ? blackColor : AIArtboardStudio._hexColor(def.hex, doc);
    var iconSize = badgeSize * 0.68;
    var iconLeft = centerX - iconSize / 2;
    var iconTop = centerY + iconSize / 2;
    var scale = iconSize / 24;
    var container = (def.subs.length > 1) ? group.compoundPathItems.add() : null;
    if (container) container.name = 'QR — Brand Icon (' + iconKey + ')';

    for (var s = 0; s < def.subs.length; s++) {
        var pts = def.subs[s];
        if (!pts || pts.length < 3) continue;
        var path = container ? container.pathItems.add() : group.pathItems.add();
        if (!container) path.name = 'QR — Brand Icon (' + iconKey + ')';
        path.closed = true;
        path.stroked = false;
        path.filled = true;
        path.fillColor = brandColor;
        for (var p = 0; p < pts.length; p++) {
            var q = pts[p];
            var pt = path.pathPoints.add();
            pt.pointType = PointType.CORNER;
            pt.anchor = [iconLeft + q[0] * scale, iconTop - q[1] * scale];
            pt.leftDirection = [iconLeft + q[2] * scale, iconTop - q[3] * scale];
            pt.rightDirection = [iconLeft + q[4] * scale, iconTop - q[5] * scale];
        }
    }
    return true;
};

AIArtboardStudio.placeQRMatrix = function (matrix, sizeMM, iconKey, cutout) {
    var doc = null, layer = null, group = null, originalLayer = null, lvl = null;
    try {
        lvl = AIArtboardStudio._quietStart();
        doc = AIArtboardStudio._doc();
        if (!matrix || typeof matrix.length != 'number' || matrix.length < 21 || matrix.length > 69) {
            throw new Error('بيانات QR غير صالحة. أعد إنشاء الرمز.');
        }
        var n = matrix.length;
        for (var rowCheck = 0; rowCheck < n; rowCheck++) {
            if (!matrix[rowCheck] || matrix[rowCheck].length != n) throw new Error('مصفوفة QR غير مكتملة.');
        }

        var artboard = AIArtboardStudio._artboard(doc);
        var size = Number(sizeMM) * 2.834645669;
        if (!(size > 5 && size < 2000)) throw new Error('مقاس QR غير صالح.');
        var quiet = 4;
        var total = n + quiet * 2;
        var moduleSize = size / total;
        var centerX = (artboard[0] + artboard[2]) / 2;
        var centerY = (artboard[1] + artboard[3]) / 2;
        var left = centerX - size / 2;
        var top = centerY + size / 2;
        if (size > (artboard[2] - artboard[0]) || size > (artboard[1] - artboard[3])) {
            throw new Error('حجم QR أكبر من لوحة الرسم النشطة. قلّل الحجم أو اختر لوحة أكبر.');
        }

        originalLayer = doc.activeLayer;
        layer = doc.layers.add();
        layer.name = iconKey ? ('QR Code — ' + iconKey) : 'QR Code';
        doc.activeLayer = layer;
        group = layer.groupItems.add();
        group.name = iconKey ? ('QR Code (' + iconKey + ') — Editable Vector') : 'QR Code — Editable Vector';

        var isRGB = false;
        try { isRGB = doc.documentColorSpace == DocumentColorSpace.RGB; } catch (spaceError) {}
        var white, black;
        if (isRGB) {
            white = new RGBColor(); white.red = 255; white.green = 255; white.blue = 255;
            black = new RGBColor(); black.red = 0; black.green = 0; black.blue = 0;
        } else {
            white = new CMYKColor(); white.cyan = 0; white.magenta = 0; white.yellow = 0; white.black = 0;
            black = new CMYKColor(); black.cyan = 0; black.magenta = 0; black.yellow = 0; black.black = 100;
        }

        // White quiet-zone background, then one black rectangle per horizontal run directly in group.
        var background = group.pathItems.rectangle(top, left, size, size);
        background.name = 'QR — White Quiet Zone';
        background.stroked = false;
        background.filled = true;
        background.fillColor = white;

        var created = 0;
        for (var r = 0; r < n; r++) {
            var c = 0;
            while (c < n) {
                if (matrix[r][c] !== true && matrix[r][c] !== 1) { c++; continue; }
                var runStart = c;
                while (c < n && (matrix[r][c] === true || matrix[r][c] === 1)) c++;
                var runWidth = (c - runStart) * moduleSize;
                var x = left + (quiet + runStart) * moduleSize;
                var y = top - (quiet + r) * moduleSize;
                var bar = group.pathItems.rectangle(y, x, runWidth, moduleSize);
                bar.name = 'QR Module Row ' + (r + 1) + ' Run ' + (created + 1);
                bar.stroked = false;
                bar.filled = true;
                bar.fillColor = black;
                created++;
            }
        }
        try { background.zOrder(ZOrderMethod.SENDTOBACK); } catch (zOrderError) {}

        var hasIcon = false;
        if (iconKey && AIArtboardStudio._qrIcons && AIArtboardStudio._qrIcons[iconKey]) {
            var cutMods = Number(cutout) || 0;
            if (cutMods < 3) cutMods = Math.max(5, Math.round(n * 0.22));
            hasIcon = AIArtboardStudio._drawQRIcon(doc, group, centerX, centerY, cutMods * moduleSize, moduleSize, white, black, String(iconKey));
        }

        try { group.selected = true; } catch (selectError) {}
        try { doc.activeLayer = originalLayer; } catch (restoreLayerError) {}
        AIArtboardStudio._quietEnd(lvl);
        return AIArtboardStudio._result(true, hasIcon
            ? 'تم إنشاء QR مع أيقونة التطبيق المدمجة كعناصر متجهية قابلة للتحرير وبتصحيح أخطاء ECC-H.'
            : 'تم إنشاء QR وإدراجه كعناصر متجهية أصلية قابلة للتحرير داخل مجموعة في طبقة مستقلة.');
    } catch (e) {
        try { if (group) group.remove(); } catch (groupError) {}
        try { if (layer && layer.pageItems.length === 0) layer.remove(); } catch (layerError) {}
        try { if (doc && originalLayer) doc.activeLayer = originalLayer; } catch (restoreError) {}
        AIArtboardStudio._quietEnd(lvl);
        return AIArtboardStudio._result(false, e.message || e);
    }
};
if (typeof $ !== 'undefined' && $.global) {
    $.global.AIArtboardStudio = AIArtboardStudio;
}
