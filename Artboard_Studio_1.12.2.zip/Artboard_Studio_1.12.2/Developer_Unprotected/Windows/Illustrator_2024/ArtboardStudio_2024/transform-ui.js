/* Direct On-Canvas Image Transform controller for Artboard Studio.
   Provides all 11 Adobe Photoshop Transform tools with pre-session locking,
   visible Photoshop-style control handles directly on the artwork in Illustrator,
   zero Make-Envelope freezes/crashes, throttled Matrix updates, and ABSMesh high-res baking. */
(function () {
  'use strict';
  var SH = window.ABSCRShared;
  var MESH = window.ABSMesh;
  function $(id) { return document.getElementById(id); }
  function tr(raw) { return (window.ABSi18n && raw) ? window.ABSi18n.tr(raw) : (raw || ''); }

  var MATRIX = { free: 1, scale: 1, rotate: 1, skew: 1 };
  var SPLIT_MODES = { splitH: 1, splitV: 1, splitX: 1 };
  var PROXY_MAX = 420, LIVE_CAGE_MAX = 360, BAKE_MAX = 3200;

  // Matches Photoshop Edit > Transform submenu order (3 visual sections, 11 tools)
  var MODES = [
    ['free',        'تحويل حر',     'Free Transform · تحجيم/تدوير/إمالة', true],
    { sep: true },
    ['scale',       'تحجيم',        'Scale · تكبير وتصغير العرض والارتفاع'],
    ['rotate',      'دوران',        'Rotate · تدوير حول المركز'],
    ['skew',        'إمالة',        'Skew · انحراف أفقي ورأسي'],
    ['distort',     'تشويه الحواف', 'Distort · سحب الزوايا الـ4 بحرية'],
    ['perspective', 'منظور',        'Perspective · تناظر المنظور'],
    { sep: true },
    ['warp',        'تقوس / انحناء', 'Warp · شبكة انحناء مرنة'],
    ['splitH',      'تقسيم أفقي',   'Split Warp Horizontally'],
    ['splitV',      'تقسيم رأسي',   'Split Warp Vertically'],
    ['splitX',      'تقسيم تقاطعي', 'Split Warp Crosswise'],
    ['removeSplit', 'إزالة التقسيم', 'Remove Warp Split']
  ];

  var ICONS = {
    free:        '<rect x="5" y="5" width="14" height="14"/><rect x="3" y="3" width="4" height="4" fill="currentColor"/><rect x="17" y="3" width="4" height="4" fill="currentColor"/><rect x="3" y="17" width="4" height="4" fill="currentColor"/><rect x="17" y="17" width="4" height="4" fill="currentColor"/>',
    scale:       '<rect x="4" y="9" width="10" height="10" rx="1"/><path d="M10 4h10v10M15 9l5-5"/>',
    rotate:      '<path d="M20 12a8 8 0 1 1-2.4-5.7"/><polyline points="20 4 20 8.5 15.5 8.5"/>',
    skew:        '<polygon points="7,5 20,5 17,19 4,19"/>',
    distort:     '<polygon points="4,6 19,3.5 20,17 5,20"/>',
    perspective: '<polygon points="6,4 18,4 21,20 3,20"/>',
    warp:        '<path d="M4 6c5-2.5 11-2.5 16 0v12c-5-2.5-11-2.5-16 0z"/><path d="M4 12c5-2.5 11-2.5 16 0"/><line x1="12" y1="4" x2="12" y2="16"/>',
    splitH:      '<rect x="4" y="5" width="16" height="14" rx="1"/><line x1="4" y1="12" x2="20" y2="12"/><circle cx="12" cy="12" r="2" fill="currentColor"/>',
    splitV:      '<rect x="4" y="5" width="16" height="14" rx="1"/><line x1="12" y1="5" x2="12" y2="19"/><circle cx="12" cy="12" r="2" fill="currentColor"/>',
    splitX:      '<rect x="4" y="5" width="16" height="14" rx="1"/><line x1="4" y1="12" x2="20" y2="12"/><line x1="12" y1="5" x2="12" y2="19"/><circle cx="12" cy="12" r="2" fill="currentColor"/>',
    removeSplit: '<rect x="4" y="5" width="16" height="14" rx="1"/><path d="M8 9l8 6M16 9l-8 6"/>'
  };

  var ROWS = [
    { k: 'sx',  label: 'العرض %',        min: 10,   max: 400, step: 1,   def: 100, modes: ['free', 'scale'] },
    { k: 'sy',  label: 'الارتفاع %',     min: 10,   max: 400, step: 1,   def: 100, modes: ['free', 'scale'] },
    { k: 'rot', label: 'الدوران °',      min: -180, max: 180, step: 0.5, def: 0,   modes: ['free', 'rotate'] },
    { k: 'skx', label: 'إمالة أفقية °',  min: -75,  max: 75,  step: 0.5, def: 0,   modes: ['free', 'skew'] },
    { k: 'sky', label: 'إمالة رأسية °',  min: -75,  max: 75,  step: 0.5, def: 0,   modes: ['free', 'skew'] }
  ];

  var HINTS = {
    distort:     'ظهرت النقاط الـ4 على زوايا الصورة في Illustrator — اسحب أي زاوية بأداة التحديد (V) مثل Distort في فوتوشوب.',
    perspective: 'اسحب أي زاوية على الصورة في Illustrator: يتحرك الركن المقابل تلقائيًا بتناظر مثل Perspective في فوتوشوب.',
    warp:        'اسحب أي نقطة من نقاط الشبكة الـ16 أو اختر قالب انحناء جاهز (قوس/انتفاخ/موجة) أعلاه.',
    splitH:      'ظهر خط تقسيم أفقي في منتصف الصورة — اسحب نقاط الخط أو الحواف لتشكيل كل نصف بحرية.',
    splitV:      'ظهر خط تقسيم رأسي في منتصف الصورة — اسحب نقاط الخط أو الحواف لتشكيل كل جانب بحرية.',
    splitX:      'ظهر تقاطع أفقي ورأسي (9 نقاط) على الصورة — اسحب نقطة التقاطع أو أي نقطة للتحكم بالانحناء.'
  };

  var st = {
    mode: 'free',
    vals: null,
    session: null,
    busy: false,
    pumping: false,
    needPump: false,
    pumpTimer: 0,
    matrixDirty: false,
    proxyCanvas: null,
    proxyInfo: null,
    hasAlpha: false,
    pts: null,
    perspSym: true,
    pollTimer: 0,
    polling: false,
    frameSeq: 0,
    lastFramePath: null,
    rendering: false,
    pendingRender: false,
    pendingSyncHandles: false
  };

  function hostEval(code, cb, timeoutMs) {
    if (!SH || !SH.hostEval) { cb(false, 'لوحة Illustrator غير جاهزة بعد.'); return; }
    return SH.hostEval(code, cb, timeoutMs || 18000);
  }
  function jsq(s) { return SH ? SH.jsq(s) : JSON.stringify(String(s || '')); }
  function dropFile(p) {
    if (!p) return;
    if (SH && SH.dropFile) SH.dropFile(p);
    else if (window.cep && window.cep.fs) try { window.cep.fs.deleteFile(p); } catch (e) {}
  }
  function status(msg, kind) {
    var el = $('xfStatus'); if (!el) return;
    var raw = msg || '';
    el.setAttribute('data-i18n-ar', raw);
    el.textContent = tr(raw);
    el.className = 'cr-status' + (kind === 'error' ? ' is-error' : kind === 'success' ? ' is-success' : '');
  }
  function defVals() { return { sx: 100, sy: 100, rot: 0, skx: 0, sky: 0, fh: false, fv: false, link: true }; }
  function isMatrix(m) { return !!MATRIX[m || st.mode]; }
  function icon(k) { return '<svg class="xf-ico" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (ICONS[k] || '') + '</svg>'; }

  function setSessionOwner(on) {
    if (window.ABSSession) {
      window.ABSSession.owner = on ? 'xf' : (window.ABSSession.owner === 'xf' ? null : window.ABSSession.owner);
    }
  }

  function showWorkspace(on) {
    var ws = $('xfWorkspace'), cancelBtn = $('xfCancel'), applyCard = $('xfApplyCard'), loadBtn = $('xfLoad');
    var ctrls = $('xfControls'), lockNote = $('xfLockNote');
    if (ctrls) ctrls.classList.toggle('xf-locked', !on);
    if (lockNote) lockNote.classList.toggle('hidden', !!on);
    if (ws) ws.classList.toggle('hidden', !on);
    if (cancelBtn) cancelBtn.classList.toggle('hidden', !on);
    if (applyCard) applyCard.classList.toggle('hidden', !on);
    if (loadBtn) loadBtn.classList.toggle('hidden', !!on);
  }

  function build() {
    var box = $('xfModes');
    if (box) {
      box.innerHTML = '';
      MODES.forEach(function (m) {
        if (m.sep) {
          var s = document.createElement('div');
          s.className = 'xf-sep';
          s.setAttribute('aria-hidden', 'true');
          box.appendChild(s);
          return;
        }
        var b = document.createElement('button');
        b.type = 'button';
        b.className = 'xf-mode' + (m[3] ? ' xf-mode-wide' : '');
        b.setAttribute('data-mode', m[0]);
        b.innerHTML = icon(m[0]) +
          '<span class="xf-txt"><b data-i18n-ar="' + m[1] + '">' + tr(m[1]) + '</b>' +
          '<small data-i18n-ar="' + m[2] + '">' + tr(m[2]) + '</small></span>';
        b.addEventListener('click', function () { setMode(m[0]); });
        box.appendChild(b);
      });
    }
    var rows = $('xfRows');
    if (rows) {
      rows.innerHTML = '';
      ROWS.forEach(function (r) {
        var d = document.createElement('div');
        d.className = 'xf-row';
        d.setAttribute('data-modes', r.modes.join(' '));
        d.innerHTML = '<label><span data-i18n-ar="' + r.label + '">' + tr(r.label) + '</span>' +
          '<span id="xfv_' + r.k + '" class="cr-val">' + r.def + (r.k === 'sx' || r.k === 'sy' ? '%' : '°') + '</span></label>' +
          '<input id="xfr_' + r.k + '" type="range" min="' + r.min + '" max="' + r.max + '" step="' + r.step + '" value="' + r.def + '">';
        rows.appendChild(d);
        var inp = d.querySelector('input');
        inp.addEventListener('input', function () { onSlider(r.k, parseFloat(this.value)); });
        inp.addEventListener('dblclick', function () { this.value = r.def; onSlider(r.k, r.def); });
      });
    }
    if ($('xfLink')) $('xfLink').addEventListener('change', function () { st.vals && (st.vals.link = this.checked); });
    if ($('xfFlipH')) $('xfFlipH').addEventListener('change', function () { if (st.vals) { st.vals.fh = this.checked; scheduleMatrixPump(); } });
    if ($('xfFlipV')) $('xfFlipV').addEventListener('change', function () { if (st.vals) { st.vals.fv = this.checked; scheduleMatrixPump(); } });
    if ($('xfPerspSym')) $('xfPerspSym').addEventListener('change', function () { st.perspSym = !!this.checked; });
    Array.prototype.forEach.call(document.querySelectorAll('#xfWarpPresets .xf-preset'), function (btn) {
      btn.addEventListener('click', function () { applyWarpPreset(btn.getAttribute('data-preset')); });
    });
  }

  function syncUI() {
    var m = st.mode, mat = isMatrix(m), v = st.vals || defVals();
    ROWS.forEach(function (r) {
      var val = v[r.k], sl = $('xfr_' + r.k), lbl = $('xfv_' + r.k);
      if (sl) sl.value = val;
      if (lbl) lbl.textContent = (Math.round(val * 10) / 10) + (r.k === 'sx' || r.k === 'sy' ? '%' : '°');
    });
    if ($('xfLink')) $('xfLink').checked = !!v.link;
    if ($('xfFlipH')) $('xfFlipH').checked = !!v.fh;
    if ($('xfFlipV')) $('xfFlipV').checked = !!v.fv;
    if ($('xfPerspSym')) $('xfPerspSym').checked = !!st.perspSym;
    Array.prototype.forEach.call(document.querySelectorAll('#xfRows .xf-row'), function (row) {
      row.classList.toggle('hidden', row.getAttribute('data-modes').split(' ').indexOf(m) < 0);
    });
    if ($('xfLinkRow')) $('xfLinkRow').classList.toggle('hidden', !(m === 'free' || m === 'scale'));
    if ($('xfFlipRow')) $('xfFlipRow').classList.toggle('hidden', m !== 'free');
    if ($('xfMatrixBox')) $('xfMatrixBox').classList.toggle('hidden', !mat);
    if ($('xfMeshBox')) $('xfMeshBox').classList.toggle('hidden', mat);
    if ($('xfPerspSymRow')) $('xfPerspSymRow').classList.toggle('hidden', m !== 'perspective');
    if ($('xfWarpPresets')) $('xfWarpPresets').classList.toggle('hidden', !(m === 'warp' || SPLIT_MODES[m]));
    if ($('xfHint')) {
      var h = HINTS[m] || '';
      $('xfHint').setAttribute('data-i18n-ar', h);
      $('xfHint').textContent = tr(h);
    }
    if ($('xfLiveState')) {
      var lr = mat ? 'مقابض التحويل نشطة مباشرةً على الصورة في Illustrator'
                   : 'نقاط ومقابض الشبكة نشطة مباشرةً على الصورة في Illustrator';
      $('xfLiveState').setAttribute('data-i18n-ar', lr);
      $('xfLiveState').textContent = tr(lr);
    }
    Array.prototype.forEach.call(document.querySelectorAll('.xf-mode'), function (b) {
      var dm = b.getAttribute('data-mode');
      b.classList.toggle('active', dm === m);
      if (dm === 'removeSplit') {
        var canRemove = !st.session || !mat;
        b.classList.toggle('is-dim', !!st.session && mat);
      } else {
        b.classList.remove('is-dim');
      }
    });
  }

  /* ---------- throttled matrix controls ---------- */
  function onSlider(k, v) {
    if (!st.session || !isMatrix() || !st.vals) return;
    if (st.vals.link && (k === 'sx' || k === 'sy')) { st.vals.sx = st.vals.sy = v; }
    else st.vals[k] = v;
    syncUI();
    scheduleMatrixPump();
  }

  function scheduleMatrixPump() {
    window.clearTimeout(st.pumpTimer);
    st.pumpTimer = window.setTimeout(pumpMatrix, 55);
  }

  function pumpMatrix() {
    if (!st.session || !isMatrix() || !st.vals) return;
    if (st.pumping) { st.needPump = true; return; }
    st.pumping = true; st.needPump = false;
    st.matrixDirty = true;
    var v = st.vals;
    hostEval('AIArtboardStudio.xfSet(' + [v.sx, v.sy, v.rot, v.skx, v.sky, v.fh ? 1 : 0, v.fv ? 1 : 0].join(',') + ')', function (ok, msg) {
      st.pumping = false;
      if (!ok) status(msg, 'error');
      else if (st.needPump) scheduleMatrixPump();
    });
  }

  /* ---------- interactive Photoshop vector control cage (fast & crash-free) ---------- */
  function ptsToCsv(pts) {
    var out = [];
    for (var i = 0; i < pts.length; i++) {
      out.push((Math.round(pts[i].x * 10000) / 10000) + ',' + (Math.round(pts[i].y * 10000) / 10000));
    }
    return out.join(',');
  }

  function guidesToStr(mode, pts) {
    if (!MESH || !MESH.guides) return '';
    var lines = MESH.guides(mode, pts), parts = [];
    for (var i = 0; i < lines.length; i++) {
      var seg = [];
      for (var j = 0; j < lines[i].length; j++) {
        seg.push((Math.round(lines[i][j].x * 10000) / 10000) + ',' + (Math.round(lines[i][j].y * 10000) / 10000));
      }
      parts.push(seg.join(','));
    }
    return parts.join('|');
  }

  function canvasFromImageData(id) {
    var cv = document.createElement('canvas');
    cv.width = id.width; cv.height = id.height;
    cv.getContext('2d').putImageData(id, 0, 0);
    return cv;
  }

  function tempFilePath(ext) {
    var base = (st.proxyInfo && st.proxyInfo.outPath) ? st.proxyInfo.outPath : '';
    var idx = Math.max(base.lastIndexOf('\\'), base.lastIndexOf('/'));
    if (idx < 0) return null;
    return base.substring(0, idx) + base.charAt(idx) + 'abs_xf_frame_' + Date.now() + '_' + (++st.frameSeq) + '.' + ext;
  }

  function writeCanvasFrame(cv, forcePng) {
    var usePng = forcePng || st.hasAlpha;
    var ext = usePng ? 'png' : 'jpg';
    var p = tempFilePath(ext);
    if (!p || !window.cep || !window.cep.fs) return null;
    var url = usePng ? cv.toDataURL('image/png') : cv.toDataURL('image/jpeg', 0.88);
    var wr = window.cep.fs.writeFile(p, url.split(',')[1], window.cep.encoding.Base64);
    if (!wr || wr.err !== 0) return null;
    return p;
  }

  function ensureProxy(cb) {
    if (st.proxyCanvas && !st.matrixDirty && st.proxyInfo) return cb(null);
    if (!SH || !SH.fsOk || !SH.fsOk()) return cb('هذه الميزة تعمل داخل Illustrator فقط.');
    SH.exportAndDecode(150, PROXY_MAX, function (err, info, id) {
      if (err) return cb(err);
      st.proxyInfo = info;
      st.proxyCanvas = canvasFromImageData(id);
      st.hasAlpha = SH.detectAlpha ? SH.detectAlpha(id) : false;
      st.matrixDirty = false;
      cb(null);
    });
  }

  function enterCageMode(mode, customPts, cb) {
    if (!MESH || !MESH.MODES[mode]) return cb && cb('وضع غير مدعوم.');
    stopPoll();
    var pts = customPts || MESH.identityPoints(mode);
    var spec = MESH.MODES[mode];
    var isIdent = MESH.isIdentity(mode, pts);

    // Fast path: when entering a cage mode at identity, draw vector handles on the image immediately (< 3ms)
    // and pre-warm the raster proxy in the background for the first drag.
    if (isIdent) {
      var oldPath = st.lastFramePath;
      st.lastFramePath = null;
      st.pts = pts;
      var gs = guidesToStr(mode, pts);
      var expr = 'AIArtboardStudio.xfCageBegin(' +
        jsq(mode) + ',"",' + spec.gx + ',' + spec.gy + ',' +
        jsq(ptsToCsv(pts)) + ',' + jsq(gs) + ')';
      hostEval(expr, function (ok, msg) {
        dropFile(oldPath);
        if (!ok) return cb && cb(msg || 'تعذّر إنشاء نقاط التحويل على الصورة.');
        startPoll();
        cb && cb(null);
        if (!st.proxyCanvas || st.matrixDirty) {
          window.setTimeout(function () {
            if (st.session && !isMatrix()) ensureProxy(function () {});
          }, 25);
        }
      });
      return;
    }

    ensureProxy(function (err) {
      if (err) return cb && cb(err);
      var rendered = MESH.render(st.proxyCanvas, { mode: mode, pts: pts }, { maxSide: LIVE_CAGE_MAX, quality: 'fast' });
      var framePath = writeCanvasFrame(rendered.canvas, false);
      var nb = rendered.nb;
      if (!framePath) return cb && cb('تعذّرت كتابة ملف المعاينة المؤقت.');
      var oldPath2 = st.lastFramePath;
      st.lastFramePath = framePath;
      st.pts = pts;
      var gs2 = guidesToStr(mode, pts);
      var expr2 = 'AIArtboardStudio.xfCageBegin(' +
        jsq(mode) + ',' + jsq(framePath) + ',' + spec.gx + ',' + spec.gy + ',' +
        jsq(ptsToCsv(pts)) + ',' + jsq(gs2) + ')';
      hostEval(expr2, function (ok, msg) {
        dropFile(oldPath2);
        if (!ok) {
          dropFile(framePath);
          if (st.lastFramePath === framePath) st.lastFramePath = null;
          return cb && cb(msg || 'تعذّر إنشاء نقاط التحويل على الصورة.');
        }
        if (nb[0] !== 0 || nb[1] !== 0 || nb[2] !== 1 || nb[3] !== 1) {
          renderCageFrame(false);
        }
        startPoll();
        cb && cb(null);
      });
    });
  }

  function renderCageFrame(syncHandles) {
    if (!st.session || isMatrix() || !st.pts) return;
    if (st.rendering) {
      st.pendingRender = true;
      st.pendingSyncHandles = st.pendingSyncHandles || !!syncHandles;
      return;
    }
    if (!st.proxyCanvas || st.matrixDirty) {
      st.rendering = true;
      ensureProxy(function (err) {
        st.rendering = false;
        if (!err && st.session && !isMatrix()) renderCageFrame(syncHandles);
      });
      return;
    }
    st.rendering = true;
    st.pendingRender = false;
    var needSync = !!syncHandles;
    st.pendingSyncHandles = false;
    try {
      var rendered = MESH.render(st.proxyCanvas, { mode: st.mode, pts: st.pts }, { maxSide: LIVE_CAGE_MAX, quality: 'fast' });
      var framePath = writeCanvasFrame(rendered.canvas, false);
      if (!framePath) { st.rendering = false; return; }
      var oldPath = st.lastFramePath;
      st.lastFramePath = framePath;
      var gs = guidesToStr(st.mode, st.pts);
      var expr = 'AIArtboardStudio.xfCageFrame(' +
        jsq(framePath) + ',' + jsq(rendered.nb.join(',')) + ',' + jsq(st.mode) + ',' +
        jsq(gs) + ',' + jsq(ptsToCsv(st.pts)) + ',' + (needSync ? 'true' : 'false') + ')';
      hostEval(expr, function () {
        st.rendering = false;
        dropFile(oldPath);
        if (st.pendingRender) {
          var s = st.pendingSyncHandles;
          st.pendingRender = false; st.pendingSyncHandles = false;
          renderCageFrame(s);
        }
      }, 10000);
    } catch (e) {
      st.rendering = false;
    }
  }

  function clampNum(v, lo, hi) { return v < lo ? lo : v > hi ? hi : v; }

  function applyPerspectiveSymmetry(prevPts, nextPts, movedIdx) {
    if (!st.perspSym || !prevPts || movedIdx < 0 || movedIdx > 3) return false;
    var dx = nextPts[movedIdx].x - prevPts[movedIdx].x;
    var dy = nextPts[movedIdx].y - prevPts[movedIdx].y;
    if (Math.abs(dx) < 1e-4 && Math.abs(dy) < 1e-4) return false;
    if (Math.abs(dx) >= Math.abs(dy)) {
      var hp = movedIdx ^ 1; // top-left <-> top-right (0<->1), bottom-left <-> bottom-right (2<->3)
      var leftIdx = movedIdx & ~1, rightIdx = leftIdx | 1;
      var midX = (prevPts[leftIdx].x + prevPts[rightIdx].x) / 2;
      nextPts[movedIdx].y = prevPts[movedIdx].y;
      nextPts[hp].y = prevPts[hp].y;
      nextPts[hp].x = Math.round((prevPts[hp].x - dx) * 10000) / 10000;
      nextPts[movedIdx].x = clampNum(nextPts[movedIdx].x, -1.2, 2.2);
      nextPts[hp].x = clampNum(nextPts[hp].x, -1.2, 2.2);
      // Prevent perspective corners from crossing or pinching past the vanishing pole
      if (nextPts[rightIdx].x - nextPts[leftIdx].x < 0.12) {
        nextPts[leftIdx].x = Math.round((midX - 0.06) * 10000) / 10000;
        nextPts[rightIdx].x = Math.round((midX + 0.06) * 10000) / 10000;
      }
    } else {
      var vp = movedIdx ^ 2; // top-left <-> bottom-left (0<->2), top-right <-> bottom-right (1<->3)
      var topIdx = movedIdx & 1, botIdx = topIdx | 2;
      var midY = (prevPts[topIdx].y + prevPts[botIdx].y) / 2;
      nextPts[movedIdx].x = prevPts[movedIdx].x;
      nextPts[vp].x = prevPts[vp].x;
      nextPts[vp].y = Math.round((prevPts[vp].y - dy) * 10000) / 10000;
      nextPts[movedIdx].y = clampNum(nextPts[movedIdx].y, -1.2, 2.2);
      nextPts[vp].y = clampNum(nextPts[vp].y, -1.2, 2.2);
      if (nextPts[botIdx].y - nextPts[topIdx].y < 0.12) {
        nextPts[topIdx].y = Math.round((midY - 0.06) * 10000) / 10000;
        nextPts[botIdx].y = Math.round((midY + 0.06) * 10000) / 10000;
      }
    }
    return true;
  }

  function applyMatrixHandleDrag(movedIdx, nums) {
    if (!st.vals || nums.length < 8) return;
    var ox = nums[0], oy = nums[1], nx = nums[2], ny = nums[3];
    var cx = nums[4], cy = nums[5], hx = Math.max(4, nums[6]), hy = Math.max(4, nums[7]);
    var m = st.mode, v = st.vals;
    var rad = (v.rot || 0) * Math.PI / 180;
    var cos = Math.cos(rad), sin = Math.sin(rad);
    // Project old & new handle vectors into the image's local axes
    var odx = ox - cx, ody = oy - cy;
    var ndx = nx - cx, ndy = ny - cy;
    var olx = odx * cos + ody * sin, oly = -odx * sin + ody * cos;
    var nlx = ndx * cos + ndy * sin, nly = -ndx * sin + ndy * cos;

    if (m === 'rotate' || (m === 'free' && movedIdx === 8)) {
      var a0 = Math.atan2(ody, odx), a1 = Math.atan2(ndy, ndx);
      var dDeg = (a1 - a0) * 180 / Math.PI;
      while (dDeg > 180) dDeg -= 360;
      while (dDeg < -180) dDeg += 360;
      var nextRot = (v.rot || 0) + dDeg;
      while (nextRot > 180) nextRot -= 360;
      while (nextRot < -180) nextRot += 360;
      v.rot = Math.round(nextRot * 2) / 2;
    } else if (m === 'skew') {
      var dLocalX = nlx - olx, dLocalY = nly - oly;
      if (movedIdx === 4 || movedIdx === 6 || (movedIdx < 4 && Math.abs(dLocalX) >= Math.abs(dLocalY))) {
        var sgnY = (oly >= 0) ? 1 : -1;
        var addSkx = Math.atan2(dLocalX * sgnY, Math.max(12, hy)) * 180 / Math.PI;
        v.skx = Math.round(clampNum((v.skx || 0) + addSkx, -75, 75) * 2) / 2;
      } else {
        var sgnX = (olx >= 0) ? 1 : -1;
        var addSky = Math.atan2(dLocalY * sgnX, Math.max(12, hx)) * 180 / Math.PI;
        v.sky = Math.round(clampNum((v.sky || 0) + addSky, -75, 75) * 2) / 2;
      }
    } else {
      // free (handles 0..7) or scale (handles 0..7)
      if (movedIdx >= 0 && movedIdx <= 3) {
        if (v.link) {
          var r0 = Math.max(4, Math.sqrt(odx * odx + ody * ody));
          var r1 = Math.max(2, Math.sqrt(ndx * ndx + ndy * ndy));
          var ratio = r1 / r0;
          v.sx = Math.round(clampNum(v.sx * ratio, 10, 400));
          v.sy = Math.round(clampNum(v.sy * ratio, 10, 400));
        } else {
          var rx = Math.abs(nlx) / Math.max(4, Math.abs(olx));
          var ry = Math.abs(nly) / Math.max(4, Math.abs(oly));
          v.sx = Math.round(clampNum(v.sx * rx, 10, 400));
          v.sy = Math.round(clampNum(v.sy * ry, 10, 400));
        }
      } else if (movedIdx === 4 || movedIdx === 6) {
        var ryEdge = Math.abs(nly) / Math.max(4, Math.abs(oly));
        v.sy = Math.round(clampNum(v.sy * ryEdge, 10, 400));
        if (v.link && m === 'scale') v.sx = v.sy;
      } else if (movedIdx === 5 || movedIdx === 7) {
        var rxEdge = Math.abs(nlx) / Math.max(4, Math.abs(olx));
        v.sx = Math.round(clampNum(v.sx * rxEdge, 10, 400));
        if (v.link && m === 'scale') v.sy = v.sx;
      }
    }
    syncUI();
    pumpMatrix();
  }

  function stopPoll() {
    window.clearTimeout(st.pollTimer);
    st.pollTimer = 0;
  }

  function schedulePoll(ms) {
    stopPoll();
    if (!st.session) return;
    st.pollTimer = window.setTimeout(pollTick, ms);
  }

  function startPoll() {
    if (!st.session) return;
    schedulePoll(260);
  }

  function pollTick() {
    if (!st.session || st.busy) { schedulePoll(320); return; }
    if (st.pumping || st.polling || st.rendering) { schedulePoll(260); return; }
    st.polling = true;
    hostEval('AIArtboardStudio.xfCagePoll(true)', function (ok, body) {
      st.polling = false;
      if (!st.session) return;
      if (ok && body) {
        if (body.indexOf('mhandle|') === 0 && isMatrix()) {
          var mparts = body.split('|');
          var mIdx = parseInt(mparts[1], 10);
          var mnums = (mparts[2] || '').split(',').map(parseFloat);
          applyMatrixHandleDrag(mIdx, mnums);
        } else if (body.indexOf('moved|') === 0 && !isMatrix()) {
          var parts = body.split('|');
          var movedIdx = parseInt(parts[1], 10);
          var nums = (parts[2] || '').split(','), parsed = [];
          for (var i = 0; i + 1 < nums.length; i += 2) {
            parsed.push({ x: parseFloat(nums[i]), y: parseFloat(nums[i + 1]) });
          }
          var expected = MESH.MODES[st.mode].gx * MESH.MODES[st.mode].gy;
          if (parsed.length === expected) {
            var synced = false;
            if (st.mode === 'perspective') synced = applyPerspectiveSymmetry(st.pts, parsed, movedIdx);
            st.pts = parsed;
            renderCageFrame(synced);
          }
        }
      }
      schedulePoll(260);
    }, 5000);
  }

  function applyWarpPreset(preset) {
    if (!st.session || !(st.mode === 'warp' || SPLIT_MODES[st.mode]) || !MESH) return;
    var spec = MESH.MODES[st.mode], pts = MESH.identityPoints(st.mode), i, j, k = 0;
    for (j = 0; j < spec.gy; j++) {
      for (i = 0; i < spec.gx; i++) {
        var u = i / (spec.gx - 1), v = j / (spec.gy - 1), dx = 0, dy = 0;
        if (preset === 'arc') dy = -0.18 * Math.sin(Math.PI * u);
        else if (preset === 'bulge') {
          dx = (u - 0.5) * 0.24 * Math.sin(Math.PI * v);
          dy = (v - 0.5) * 0.24 * Math.sin(Math.PI * u);
        } else if (preset === 'wave') dy = 0.14 * Math.sin(u * Math.PI * 2);
        else if (preset === 'flag') dy = 0.15 * Math.sin(u * Math.PI * 2);
        pts[k++] = { x: u + dx, y: v + dy };
      }
    }
    st.pts = pts;
    renderCageFrame(true);
    status('تم تطبيق شكل «' + preset + '» مباشرةً على الصورة ونقاط الشبكة في Illustrator.', 'success');
  }

  /* ---------- Remove Warp Split (matches Photoshop's Edit > Transform > Remove Warp Split) ---------- */
  function bilinearPts4x4(tl, tr, bl, br) {
    var pts = [], i, j;
    for (j = 0; j < 4; j++) {
      var v = j / 3;
      for (i = 0; i < 4; i++) {
        var u = i / 3;
        pts.push({
          x: (1 - v) * ((1 - u) * tl.x + u * tr.x) + v * ((1 - u) * bl.x + u * br.x),
          y: (1 - v) * ((1 - u) * tl.y + u * tr.y) + v * ((1 - u) * bl.y + u * br.y)
        });
      }
    }
    return pts;
  }

  function sampleSurfaceToWarp4x4(mode, pts) {
    if (!MESH || !MESH.surface || MESH.isIdentity(mode, pts)) return MESH.identityPoints('warp');
    var fn = MESH.surface(mode, pts), out = [], i, j;
    for (j = 0; j < 4; j++) {
      var v = j / 3;
      for (i = 0; i < 4; i++) {
        var u = i / 3, p = fn(u, v);
        out.push({ x: Math.round(p.x * 10000) / 10000, y: Math.round(p.y * 10000) / 10000 });
      }
    }
    return out;
  }

  function handleRemoveSplit() {
    if (!st.session) return;
    if (SPLIT_MODES[st.mode] && st.pts && MESH) {
      var warpPts = sampleSurfaceToWarp4x4(st.mode, st.pts);
      st.mode = 'warp';
      st.busy = true;
      enterCageMode('warp', warpPts, function (err) {
        st.busy = false;
        syncUI();
        status(err || 'تمت إزالة خطوط التقسيم والعودة إلى شبكة الانحناء الأساسية (Warp).', err ? 'error' : 'success');
      });
      return;
    }
    if (st.mode === 'warp' && st.pts && MESH) {
      var tl2 = st.pts[0], tr2 = st.pts[3], bl2 = st.pts[12], br2 = st.pts[15];
      st.pts = bilinearPts4x4(tl2, tr2, bl2, br2);
      renderCageFrame(true);
      status('تمت إزالة الانحناء الداخلي مع الإبقاء على حدود الزوايا.', 'success');
      return;
    }
    status('أمر «إزالة التقسيم» يُستخدم أثناء العمل بأوضاع التقسيم (أفقي / رأسي / متقاطع) أو الانحناء.', 'error');
  }

  /* ---------- modes & direct Illustrator session ---------- */
  function setMode(m) {
    if (st.busy || !st.session) return;
    if (m === 'removeSplit') { handleRemoveSplit(); return; }
    var prev = st.mode;
    if (prev === m) return;
    st.mode = m;

    if (isMatrix(prev) && isMatrix(m)) {
      syncUI();
      hostEval('AIArtboardStudio.xfSwitchMode(' + jsq(m) + ')', function (ok, msg) {
        status(ok ? modeReadyMsg(m) : msg, ok ? 'success' : 'error');
      });
      return;
    }

    if (!isMatrix(prev) && !isMatrix(m)) {
      // Switching between Distort / Perspective / Warp / Split modes:
      // If the current cage is already deformed, sample its surface onto the new mode's control points
      var nextPts = null;
      if (st.pts && MESH && !MESH.isIdentity(prev, st.pts) && MESH.surface && MESH.MODES[m]) {
        var surf = MESH.surface(prev, st.pts), sp = MESH.MODES[m], sampled = [];
        for (var r = 0; r < sp.gy; r++) {
          var v = r / (sp.gy - 1);
          for (var c = 0; c < sp.gx; c++) {
            var u = c / (sp.gx - 1), pt = surf(u, v);
            sampled.push({ x: Math.round(pt.x * 10000) / 10000, y: Math.round(pt.y * 10000) / 10000 });
          }
        }
        nextPts = sampled;
      }
      st.busy = true;
      status('جارٍ إظهار نقاط ومقابض «' + modeTitle(m) + '» على الصورة…');
      enterCageMode(m, nextPts, function (err) {
        st.busy = false;
        if (err) { st.mode = prev; syncUI(); status(err, 'error'); return; }
        st.session.kind = 'mesh';
        syncUI();
        status(modeReadyMsg(m), 'success');
      });
      return;
    }

    if (!isMatrix(prev) && isMatrix(m)) {
      // Switching from Cage back to Matrix: bake warped image into session target if modified
      stopPoll();
      st.busy = true;
      status('جارٍ الانتقال إلى «' + modeTitle(m) + '»…');
      if (st.pts && MESH && !MESH.isIdentity(prev, st.pts)) {
        bakeCurrentCage(true, m, function (ok, msg) {
          st.busy = false;
          if (!ok) { st.mode = prev; syncUI(); startPoll(); status(msg || 'تعذّر تبديل وضع التحويل.', 'error'); return; }
          st.vals = defVals();
          st.proxyCanvas = null; st.matrixDirty = true;
          st.session.kind = 'matrix';
          syncUI();
          startPoll();
          status(modeReadyMsg(m), 'success');
        });
      } else {
        hostEval('AIArtboardStudio.xfSwitchMode(' + jsq(m) + ')', function (ok, msg) {
          st.busy = false;
          if (!ok) { st.mode = prev; syncUI(); startPoll(); status(msg || 'تعذّر تبديل وضع التحويل.', 'error'); return; }
          st.vals = defVals();
          st.session.kind = 'matrix';
          syncUI();
          startPoll();
          status(modeReadyMsg(m), 'success');
        });
      }
      return;
    }

    // Switching from Matrix -> Cage
    st.busy = true;
    status('جارٍ إظهار نقاط ومقابض «' + modeTitle(m) + '» على الصورة…');
    enterCageMode(m, null, function (err) {
      st.busy = false;
      if (err) { st.mode = prev; syncUI(); status(err, 'error'); return; }
      st.session.kind = 'mesh';
      syncUI();
      status(modeReadyMsg(m), 'success');
    });
  }

  function modeTitle(m) {
    for (var i = 0; i < MODES.length; i++) if (MODES[i][0] === m) return MODES[i][1];
    return m;
  }

  function modeReadyMsg(m) {
    if (isMatrix(m)) return 'ظهرت مقابض التحويل الثمانية بوضوح على الصورة في Illustrator — اسحب من الصورة أو عدّل القيم هنا ثم اضغط «تثبيت التحويل».';
    if (m === 'distort') return 'نقاط الزوايا الأربعة جاهزة على الصورة في Illustrator — اسحب أي زاوية بحرية مثل Distort في فوتوشوب.';
    if (m === 'perspective') return 'نقاط المنظور الـ4 جاهزة على الصورة في Illustrator — اسحب أي زاوية لتناظر المنظور تلقائيًا.';
    return 'ظهرت نقاط ومقابض «' + modeTitle(m) + '» مباشرةً على الصورة في Illustrator — اسحب أي نقطة على الصورة ثم اضغط «تثبيت التحويل».';
  }

  function load() {
    if (st.busy) return;
    if (window.ABSSession && window.ABSSession.owner && window.ABSSession.owner !== 'xf') {
      status('أنهِ أو ألغِ جلسة «تعديل الصور» أولًا ثم ابدأ هنا.', 'error');
      return;
    }
    if (st.session) {
      closeSession(false, function () { load(); });
      return;
    }
    st.mode = 'free';
    st.busy = true;
    var loadBtn = $('xfLoad');
    if (loadBtn) loadBtn.disabled = true;
    status('جارٍ تفعيل مقابض التحويل مباشرةً على الصورة…');
    hostEval('AIArtboardStudio.xfBegin(' + jsq(st.mode) + ')', function (ok, body) {
      st.busy = false;
      if (loadBtn) loadBtn.disabled = false;
      if (!ok) { status(body || 'حدّد صورة واحدة في Illustrator أولًا.', 'error'); return; }
      st.vals = defVals();
      st.proxyCanvas = null; st.proxyInfo = null; st.pts = null; st.matrixDirty = false;
      st.session = { kind: 'matrix' };
      setSessionOwner(true);
      showWorkspace(true);
      syncUI();
      startPoll();
      status(modeReadyMsg(st.mode), 'success');
    });
  }

  function closeSession(keep, cb) {
    stopPoll();
    window.clearTimeout(st.pumpTimer);
    if (!st.session) {
      dropFile(st.lastFramePath); st.lastFramePath = null;
      if (cb) cb(true);
      return;
    }
    st.busy = true;
    hostEval('AIArtboardStudio.xfEnd(' + (keep ? 'true' : 'false') + ')', function (ok, msg) {
      st.busy = false;
      st.session = null; st.vals = null; st.pts = null;
      st.proxyCanvas = null; st.proxyInfo = null; st.matrixDirty = false;
      dropFile(st.lastFramePath); st.lastFramePath = null;
      setSessionOwner(false);
      showWorkspace(false);
      syncUI();
      if (cb) cb(ok, msg);
    }, 15000);
  }

  function bakeCurrentCage(keepSession, nextMode, cb) {
    if (!SH || !SH.exportAndDecode || !MESH) return cb(false, 'الوحدة غير جاهزة.');
    SH.exportAndDecode(300, BAKE_MAX, function (err, info, full) {
      if (err) return cb(false, err);
      var outPath = info.outPath;
      try {
        var fullCv = canvasFromImageData(full);
        var rendered = MESH.render(fullCv, { mode: st.mode, pts: st.pts }, { maxSide: BAKE_MAX, quality: 'high' });
        var b64 = rendered.canvas.toDataURL('image/png').split(',')[1];
        var wr = window.cep.fs.writeFile(outPath, b64, window.cep.encoding.Base64);
        if (!wr || wr.err !== 0) return cb(false, 'تعذّرت كتابة الملف المؤقت (رمز ' + (wr && wr.err) + ').');
        var expr = 'AIArtboardStudio.xfCageBake(' + jsq(outPath) + ',' + jsq(rendered.nb.join(',')) + ',' +
          (keepSession ? 'true' : 'false') + ',' + jsq(nextMode || '') + ')';
        hostEval(expr, function (ok, msg) {
          dropFile(outPath);
          cb(ok, msg);
        }, 45000);
      } catch (e) {
        dropFile(outPath);
        cb(false, 'فشل تثبيت التحويل: ' + (e.message || e));
      }
    });
  }

  function apply() {
    if (st.busy || !st.session) return;
    if (isMatrix(st.mode) || !st.pts || !MESH || MESH.isIdentity(st.mode, st.pts)) {
      closeSession(true, function (ok, msg) {
        status(ok ? 'تم تثبيت التحويل على الصورة في Illustrator.' : (msg || 'تعذّر تثبيت التحويل.'), ok ? 'success' : 'error');
      });
      return;
    }
    stopPoll();
    st.busy = true;
    if (window.ABSBusy) window.ABSBusy.show('جارٍ تثبيت التحويل بالدقة الكاملة…');
    status('جارٍ تثبيت التحويل بالدقة الكاملة على الصورة…');
    bakeCurrentCage(false, '', function (ok, msg) {
      if (window.ABSBusy) window.ABSBusy.hide();
      st.busy = false;
      if (ok) {
        st.session = null; st.vals = null; st.pts = null;
        st.proxyCanvas = null; st.proxyInfo = null; st.matrixDirty = false;
        dropFile(st.lastFramePath); st.lastFramePath = null;
        setSessionOwner(false);
        showWorkspace(false);
        syncUI();
        status('تم تثبيت التحويل على الصورة في Illustrator.', 'success');
      } else {
        startPoll();
        status(msg || 'تعذّر تثبيت التحويل.', 'error');
      }
    });
  }

  function cancel() {
    if (st.busy || !st.session) return;
    closeSession(false, function () {
      status('أُلغي التحويل وأُعيدت الصورة الأصلية كما كانت.', 'success');
    });
  }

  function reset() {
    if (st.busy || !st.session) return;
    if (!isMatrix(st.mode) && MESH) {
      st.pts = MESH.identityPoints(st.mode);
      renderCageFrame(true);
      status('أُعيدت نقاط الشبكة إلى الوضع الافتراضي.', 'success');
      return;
    }
    st.busy = true;
    hostEval('AIArtboardStudio.xfReset(' + jsq(st.mode) + ')', function (ok, msg) {
      st.busy = false;
      if (!ok) { status(msg || 'تعذّر إعادة الضبط.', 'error'); return; }
      st.vals = defVals();
      st.matrixDirty = false; st.proxyCanvas = null;
      syncUI();
      status('أُعيدت الصورة إلى وضعها قبل التحويل مع إبقاء المقابض نشطة.', 'success');
    });
  }

  function activateTool(toolKey, okMsg) {
    if (!st.session) { status('اضغط «بدء التحويل على الصورة المحددة» أولًا.', 'error'); return; }
    hostEval('AIArtboardStudio.xfNativeTool(' + jsq(toolKey) + ')', function (ok, msg) {
      status(ok ? okMsg : (msg || 'تعذّر تفعيل الأداة في Illustrator.'), ok ? 'success' : 'error');
    });
  }

  function init() {
    var p = $('panel-xf');
    if (!p || p.getAttribute('data-ready')) return;
    p.setAttribute('data-ready', '1');
    build();
    showWorkspace(false);
    syncUI();

    if ($('xfLoad')) $('xfLoad').addEventListener('click', load);
    if ($('xfApply')) $('xfApply').addEventListener('click', apply);
    if ($('xfCancel')) $('xfCancel').addEventListener('click', cancel);
    if ($('xfReset')) $('xfReset').addEventListener('click', reset);
    if ($('xfNative')) {
      $('xfNative').addEventListener('click', function () {
        activateTool('select', 'فُعّلت مقابض التحويل على الصورة داخل Illustrator — اسحب أي مقبض مباشرةً على الصورة.');
      });
    }
    if ($('xfSyncNow')) {
      $('xfSyncNow').addEventListener('click', function () {
        if (!st.session) return;
        st.polling = false;
        pollTick();
        status('تم تحديث معاينة الصورة حسب مواضع النقاط الحالية.', 'success');
      });
    }
    if ($('xfToolSelect')) {
      $('xfToolSelect').addEventListener('click', function () {
        activateTool('select', 'فُعّلت أداة التحديد (V) — اسحب أي مربع أبيض/أزرق على الصورة مباشرةً.');
      });
    }
    p.addEventListener('mouseenter', function () {
      if (st.session && !st.busy && !st.polling && !st.rendering) pollTick();
    });
    window.addEventListener('beforeunload', function () {
      stopPoll();
      dropFile(st.lastFramePath);
      if (st.session) {
        try { window.__adobe_cep__.evalScript('AIArtboardStudio.xfEnd(true)'); } catch (e) {}
      }
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
  window.ABSTransformUI = { _state: st, load: load, apply: apply, cancel: cancel, reset: reset, setMode: setMode };
}());
