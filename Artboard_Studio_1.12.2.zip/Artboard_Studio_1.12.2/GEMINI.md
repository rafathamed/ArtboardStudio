# Artboard Studio Project Rules

## 1. Version Bumping Policy (Mandatory for Every Future Release)
- **Never reuse an already-published version number.** Whenever building and publishing a new fix, feature, or release to GitHub (`rafathamed/ArtboardStudio`), always bump the version to a strictly newer SemVer (e.g., `1.12.1` -> `1.12.2`, `1.13.0`) unless the user explicitly specifies another newer version.
- Because the in-app updater compares the installed local version against `version.json`, keeping the same version prevents users from receiving automatic update prompts.
- Update the version consistently across all 8 source trees (`Windows` & `macOS` × `Illustrator_2024..2027`) and installer files before running `Installer/build.ps1`:
  - `version.js` (`window.ARTBOARD_STUDIO_VERSION`)
  - `CSXS/manifest.xml` (`ExtensionBundleVersion` and `<Extension ... Version="..." />`)
  - `license-config.js` (`window.ARTBOARD_STUDIO_BUILD`)
  - `index.html` (`BUILD <version>`)
  - `README*.md` files
  - `Installer/build_all.js` (update regex/targets so `processExtensionFolder` & `updateReadmes` stamp the new version instead of an older one)
  - `Installer/build_github_update.js` (`VERSION` and `notes`)
  - `Installer/build.ps1` (`Artboard_Studio_<VERSION>_...` filenames)
  - `Installer/src/Setup.cs` (`AssemblyVersion`, `AssemblyFileVersion`, `AssemblyInformationalVersion`, and any displayed version labels)

## 2. Publishing to GitHub (Replace Old Versions cleanly)
- **Replace obsolete version packages on GitHub (`rafathamed/ArtboardStudio`, `main`):**
  - After uploading a new version (`<NEW_VER>`), check all references in `index.html`, `admin-panel.js`, and `README.md` on `main`, and update installer/download URLs (`Setup.exe`, `Windows_PROTECTED.zip`, `macOS_PROTECTED.zip`, `Update.zip`) to `<NEW_VER>`.
  - **Delete obsolete previous-version release artifacts** (`Artboard_Studio_<OLD_VER>_Setup.exe`, `Artboard_Studio_<OLD_VER>_Update.zip`, `Artboard_Studio_<OLD_VER>_Windows_PROTECTED.zip`, `Artboard_Studio_<OLD_VER>_macOS_PROTECTED.zip`, etc.) from the repository so only the latest version remains (unless an asset is still explicitly referenced on the site, such as `Artboard_Studio_1.12.0_English_Guide.mp4`).
- Do **not** attempt to bypass Antigravity's browser file-upload permission prompt (`UPLOAD_NEEDS_PERMISSION`).
- Keep `Windows` and `macOS` (`2024..2027`) source files synced before building, and note that `.bat` files belong only in Windows packages and `.command` files belong only in macOS packages.
- Only if the user installs `git` or GitHub CLI (`gh`) locally and connects credentials should CLI push workflows (`git add` / `git rm` / `git push`) be used.

## 3. Arabic-Only Command & Permission Descriptions
- Whenever executing any command (`run_command`) or requesting user permission for an action, **always write `toolSummary` and any accompanying explanation in clear Arabic only** so the user immediately understands what the command does before approving.

## 4. Automatic Upload to Google Drive (Mandatory After Every Completed Project/Release)
- Whenever any project or new release version is completed and built, automatically upload the final deliverables (e.g., `Setup.exe`, `Windows_PROTECTED.zip`, `macOS_PROTECTED.zip`, `Windows_DEVELOPER_unprotected.zip`, `macOS_DEVELOPER_unprotected.zip`, `GitHub_Update` files, and a full project `.zip` archive) to Google Drive using the `gdrive` CLI (`gdrive mutate mkdir` / `gdrive mutate upload`) inside an organized version folder (e.g., `Artboard Studio/v<VERSION>/`), and return the verified Google Drive links (`gdrive readonly url <FILE_ID>`).
