/* Panel version and Illustrator year, used by the updater. Release tool stamps the version. */
window.ARTBOARD_STUDIO_VERSION = '1.12.0';
window.ARTBOARD_STUDIO_YEAR = '2027';
