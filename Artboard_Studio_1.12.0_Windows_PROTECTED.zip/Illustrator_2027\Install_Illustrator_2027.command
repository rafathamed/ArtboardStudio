#!/bin/bash
# Artboard Studio - Illustrator 2027 (macOS installer)
cd "$(dirname "$0")" || exit 1
SRC="$(pwd)/ArtboardStudio_2027"
EXTROOT="$HOME/Library/Application Support/Adobe/CEP/extensions"
DEST="$EXTROOT/com.rafat.artboardstudio.ai2027"
echo "================================================"
echo " Artboard Studio - Illustrator 2027 (macOS)"
echo "================================================"
if [ ! -d "$SRC" ]; then echo "ERROR: ArtboardStudio_2027 folder not found next to this script."; read -n 1 -s -r -p "Press any key to close..."; exit 1; fi
mkdir -p "$EXTROOT"
rm -rf "$DEST"
cp -R "$SRC" "$DEST" || { echo "ERROR: could not copy files."; read -n 1 -s -r -p "Press any key to close..."; exit 1; }
xattr -cr "$DEST" 2>/dev/null
chmod -R u+rwX "$DEST"
# Allow unsigned CEP extensions

defaults write com.adobe.CSXS.12 PlayerDebugMode 1
killall cfprefsd 2>/dev/null
echo
echo "Installed to: $DEST"
echo "1) Quit Illustrator completely (Cmd+Q) and open it again."
echo "2) Open: Window > Extensions (Legacy) > Artboard Studio 2027"
echo
read -n 1 -s -r -p "Press any key to close..."
