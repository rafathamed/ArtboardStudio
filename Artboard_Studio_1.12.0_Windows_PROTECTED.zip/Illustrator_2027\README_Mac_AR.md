# Artboard Studio — Illustrator 2027 على macOS

## التثبيت
1. فك الضغط عن الملف **على الماك** (يفضّل بالنقر المزدوج على الـ zip من Finder).
2. افتح مجلد `Illustrator_2027`.
3. انقر **كليك يمين** على `Install_Illustrator_2027.command` ثم **Open** ثم **Open** مرة أخرى (أول مرة فقط بسبب حماية macOS).
4. أغلق Illustrator تمامًا (Cmd+Q) ثم افتحه من جديد.
5. من القائمة: **Window ‹ Extensions (Legacy) ‹ Artboard Studio 2027**.

## إذا لم يعمل الملف .command
افتح Terminal ونفّذ:
```
cd ~/Downloads/<مسار المجلد>/Illustrator_2027
chmod +x *.command
./Install_Illustrator_2027.command
```

## يدويًا (بدون سكربت)
- انسخ المجلد `ArtboardStudio_2027` إلى:
  `~/Library/Application Support/Adobe/CEP/extensions/com.rafat.artboardstudio.ai2027`
  (للوصول: Finder ‹ Go ‹ Go to Folder، والصق مسار `~/Library/Application Support/Adobe/CEP`)
- في Terminal:  ; defaults write com.adobe.CSXS.12 PlayerDebugMode 1

## الإزالة
شغّل `Uninstall_Illustrator_2027.command`.

## ملاحظات
- الإضافة تحتاج اتصال إنترنت لتفعيل السريال أول مرة.
- لم تُختبر داخل Illustrator على ماك في بيئة البناء.
