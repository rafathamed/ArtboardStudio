#!/bin/bash
DEST="$HOME/Library/Application Support/Adobe/CEP/extensions/com.rafat.artboardstudio.ai2024"
rm -rf "$DEST"
echo "Artboard Studio 2024 removed."
echo "PlayerDebugMode was left unchanged because other CEP extensions may use it."
read -n 1 -s -r -p "Press any key to close..."
