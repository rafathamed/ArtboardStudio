# Artboard Studio — Illustrator 2024 على macOS

## التثبيت
1. فك الضغط عن الملف **على الماك** (يفضّل بالنقر المزدوج على الـ zip من Finder).
2. افتح مجلد `Illustrator_2024`.
3. انقر **كليك يمين** على `Install_Illustrator_2024.command` ثم **Open** ثم **Open** مرة أخرى (أول مرة فقط بسبب حماية macOS).
4. أغلق Illustrator تمامًا (Cmd+Q) ثم افتحه من جديد.
5. من القائمة: **Window ‹ Extensions (Legacy) ‹ Artboard Studio 2024**.

## إذا لم يعمل الملف .command
افتح Terminal ونفّذ:
```
cd ~/Downloads/<مسار المجلد>/Illustrator_2024
chmod +x *.command
./Install_Illustrator_2024.command
```

## يدويًا (بدون سكربت)
- انسخ المجلد `ArtboardStudio_2024` إلى:
  `~/Library/Application Support/Adobe/CEP/extensions/com.rafat.artboardstudio.ai2024`
  (للوصول: Finder ‹ Go ‹ Go to Folder، والصق مسار `~/Library/Application Support/Adobe/CEP`)
- في Terminal:  ; defaults write com.adobe.CSXS.11 PlayerDebugMode 1

## الإزالة
شغّل `Uninstall_Illustrator_2024.command`.

## ملاحظات
- الإضافة تحتاج اتصال إنترنت لتفعيل السريال أول مرة.
- لم تُختبر داخل Illustrator على ماك في بيئة البناء.
