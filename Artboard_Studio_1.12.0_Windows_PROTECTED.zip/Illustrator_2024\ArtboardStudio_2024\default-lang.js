/* Artboard Studio — Default Language Configuration (written by Setup.exe or default package) */
window.ARTBOARD_STUDIO_DEFAULT_LANG = 'ar';
window.ARTBOARD_STUDIO_INSTALL_STAMP = '0';
