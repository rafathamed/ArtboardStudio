@echo off
setlocal
set "EXTROOT=%APPDATA%\Adobe\CEP\extensions"
set "DEST=%EXTROOT%\com.rafat.artboardstudio.ai2027"
echo ================================================
echo  Artboard Studio - Illustrator 2027
echo ================================================
if not exist "%EXTROOT%" mkdir "%EXTROOT%"
if exist "%DEST%" rmdir /s /q "%DEST%"
xcopy "%~dp0ArtboardStudio_2027" "%DEST%\" /E /I /Y >nul
if errorlevel 1 (
  echo ERROR: Extension files could not be copied.
  pause
  exit /b 1
)
reg add "HKCU\Software\Adobe\CSXS.12" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul
if errorlevel 1 echo WARNING: Could not enable CEP 12 debugging automatically.
echo.
echo Installation files copied successfully.
echo Restart Illustrator.
echo Open Window ^> Extensions (Legacy) ^> Artboard Studio 2027.
echo.
pause
