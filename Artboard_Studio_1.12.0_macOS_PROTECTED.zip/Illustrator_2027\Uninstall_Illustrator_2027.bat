@echo off
set "DEST=%APPDATA%\Adobe\CEP\extensions\com.rafat.artboardstudio.ai2027"
if exist "%DEST%" rmdir /s /q "%DEST%"
echo Artboard Studio 2027 files removed.
pause
