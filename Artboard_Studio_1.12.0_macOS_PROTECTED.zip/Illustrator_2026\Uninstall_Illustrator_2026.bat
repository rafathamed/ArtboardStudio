@echo off
set "DEST=%APPDATA%\Adobe\CEP\extensions\com.rafat.artboardstudio.ai2026"
if exist "%DEST%" rmdir /s /q "%DEST%"
echo Artboard Studio 2026 files removed.
echo PlayerDebugMode was left unchanged because other CEP extensions may use it.
pause
