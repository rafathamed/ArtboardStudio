@echo off
set "DEST=%APPDATA%\Adobe\CEP\extensions\com.rafat.artboardstudio.ai2025"
if exist "%DEST%" rmdir /s /q "%DEST%"
echo Artboard Studio 2025 files removed.
pause
