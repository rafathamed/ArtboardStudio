#!/bin/bash
cd "$(dirname "$0")"; exec bash "./Artboard_Studio_1.13.6_macOS_Setup.command" uninstall
