#!/bin/bash
cd "$(dirname "$0")"; exec bash "./Artboard_Studio_1.12.9_macOS_Setup.command" uninstall
