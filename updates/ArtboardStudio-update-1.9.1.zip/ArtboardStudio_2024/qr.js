/* Local QR encoder: byte mode, ECC-M, QR versions 1-6. No network calls. */
(function (root) {
  'use strict';

  var VERSIONS = [
    null,
    { data: 16, blocks: 1, blockData: 16, ecc: 10, align: [] },
    { data: 28, blocks: 1, blockData: 28, ecc: 16, align: [6, 18] },
    { data: 44, blocks: 1, blockData: 44, ecc: 26, align: [6, 22] },
    { data: 64, blocks: 2, blockData: 32, ecc: 18, align: [6, 26] },
    { data: 86, blocks: 2, blockData: 43, ecc: 24, align: [6, 30] },
    { data: 108, blocks: 4, blockData: 27, ecc: 16, align: [6, 34] }
  ];

  function utf8Bytes(str) {
    if (typeof TextEncoder !== 'undefined') return Array.prototype.slice.call(new TextEncoder().encode(str));
    var encoded = unescape(encodeURIComponent(str));
    var out = [];
    for (var i = 0; i < encoded.length; i++) out.push(encoded.charCodeAt(i));
    return out;
  }

  function gfMul(x, y) {
    var z = 0;
    for (var i = 7; i >= 0; i--) {
      z = (z << 1) ^ ((z >>> 7) * 0x11D);
      if ((y >>> i) & 1) z ^= x;
    }
    return z;
  }

  function rsGenerator(degree) {
    var p = [1];
    for (var i = 0; i < degree; i++) {
      var next = new Array(p.length + 1).fill(0);
      for (var j = 0; j < p.length; j++) {
        next[j] ^= p[j];
        next[j + 1] ^= gfMul(p[j], gfPow(i));
      }
      p = next;
    }
    return p;
  }

  function gfPow(power) {
    var x = 1;
    for (var i = 0; i < power; i++) x = gfMul(x, 2);
    return x;
  }

  function rsRemainder(data, degree) {
    var gen = rsGenerator(degree);
    var rem = data.slice();
    for (var i = 0; i < degree; i++) rem.push(0);
    for (var k = 0; k < data.length; k++) {
      var factor = rem[k];
      if (factor) for (var j = 0; j < gen.length; j++) rem[k + j] ^= gfMul(gen[j], factor);
    }
    return rem.slice(data.length);
  }

  function pushBits(out, value, count) {
    for (var i = count - 1; i >= 0; i--) out.push((value >>> i) & 1);
  }

  function makeCodewords(bytes, version) {
    var cfg = VERSIONS[version];
    var bits = [];
    pushBits(bits, 4, 4); // Byte mode
    pushBits(bits, bytes.length, version < 10 ? 8 : 16);
    for (var i = 0; i < bytes.length; i++) pushBits(bits, bytes[i], 8);
    var maxBits = cfg.data * 8;
    if (bits.length > maxBits) throw new Error('النص أطول من سعة QR المتاحة.');
    for (i = 0; i < Math.min(4, maxBits - bits.length); i++) bits.push(0);
    while (bits.length % 8) bits.push(0);
    var data = [];
    for (i = 0; i < bits.length; i += 8) {
      var val = 0;
      for (var b = 0; b < 8; b++) val = (val << 1) | bits[i + b];
      data.push(val);
    }
    var pad = [0xEC, 0x11], p = 0;
    while (data.length < cfg.data) data.push(pad[p++ & 1]);

    var blocks = [];
    for (i = 0; i < cfg.blocks; i++) {
      var part = data.slice(i * cfg.blockData, (i + 1) * cfg.blockData);
      blocks.push({ data: part, ecc: rsRemainder(part, cfg.ecc) });
    }
    var out = [], maxData = cfg.blockData;
    for (i = 0; i < maxData; i++) for (var k = 0; k < blocks.length; k++) out.push(blocks[k].data[i]);
    for (i = 0; i < cfg.ecc; i++) for (k = 0; k < blocks.length; k++) out.push(blocks[k].ecc[i]);
    return out;
  }

  function maskBit(mask, r, c) {
    switch (mask) {
      case 0: return (r + c) % 2 === 0;
      case 1: return r % 2 === 0;
      case 2: return c % 3 === 0;
      case 3: return (r + c) % 3 === 0;
      case 4: return (Math.floor(r / 2) + Math.floor(c / 3)) % 2 === 0;
      case 5: return (r * c) % 2 + (r * c) % 3 === 0;
      case 6: return ((r * c) % 2 + (r * c) % 3) % 2 === 0;
      default: return ((r + c) % 2 + (r * c) % 3) % 2 === 0;
    }
  }

  function addFinder(m, r0, c0) {
    var n = m.length;
    for (var dr = -1; dr <= 7; dr++) {
      for (var dc = -1; dc <= 7; dc++) {
        var r = r0 + dr, c = c0 + dc;
        if (r < 0 || r >= n || c < 0 || c >= n) continue;
        var inside = dr >= 0 && dr <= 6 && dc >= 0 && dc <= 6;
        var black = inside && (dr === 0 || dr === 6 || dc === 0 || dc === 6 || (dr >= 2 && dr <= 4 && dc >= 2 && dc <= 4));
        m[r][c] = black;
      }
    }
  }

  function addAlignment(m, r0, c0) {
    for (var dr = -2; dr <= 2; dr++) for (var dc = -2; dc <= 2; dc++) {
      var d = Math.max(Math.abs(dr), Math.abs(dc));
      m[r0 + dr][c0 + dc] = d === 2 || d === 0;
    }
  }

  function writeFormat(m, mask) {
    var n = m.length;
    var data = mask; // ECC-M format bits are 00.
    var rem = data;
    for (var i = 0; i < 10; i++) rem = (rem << 1) ^ (((rem >>> 9) & 1) ? 0x537 : 0);
    var bits = ((data << 10) | rem) ^ 0x5412;
    function bit(i) { return ((bits >>> i) & 1) !== 0; }
    for (i = 0; i <= 5; i++) m[i][8] = bit(i);
    m[7][8] = bit(6); m[8][8] = bit(7); m[8][7] = bit(8);
    for (i = 9; i < 15; i++) m[8][14 - i] = bit(i);
    for (i = 0; i < 8; i++) m[8][n - 1 - i] = bit(i);
    for (i = 8; i < 15; i++) m[n - 15 + i][8] = bit(i);
    m[n - 8][8] = true;
  }

  function buildMatrix(codewords, version, mask) {
    var n = version * 4 + 17;
    var m = new Array(n);
    for (var r = 0; r < n; r++) m[r] = new Array(n).fill(null);
    addFinder(m, 0, 0); addFinder(m, 0, n - 7); addFinder(m, n - 7, 0);

    for (var i = 8; i < n - 8; i++) {
      if (m[6][i] === null) m[6][i] = i % 2 === 0;
      if (m[i][6] === null) m[i][6] = i % 2 === 0;
    }
    var positions = VERSIONS[version].align;
    for (var ai = 0; ai < positions.length; ai++) for (var aj = 0; aj < positions.length; aj++) {
      var ar = positions[ai], ac = positions[aj];
      if (m[ar][ac] === null) addAlignment(m, ar, ac);
    }
    // Reserve format-information cells before placing payload.
    for (i = 0; i <= 5; i++) { m[i][8] = false; m[8][i] = false; }
    m[7][8] = false; m[8][8] = false; m[8][7] = false;
    for (i = 0; i < 8; i++) m[8][n - 1 - i] = false;
    for (i = 0; i < 7; i++) m[n - 1 - i][8] = false;

    var bitIndex = 0, totalBits = codewords.length * 8;
    for (var right = n - 1; right >= 1; right -= 2) {
      if (right === 6) right = 5;
      for (var vert = 0; vert < n; vert++) {
        var row = ((right + 1) & 2) === 0 ? n - 1 - vert : vert;
        for (var j = 0; j < 2; j++) {
          var col = right - j;
          if (m[row][col] !== null) continue;
          var val = bitIndex < totalBits ? ((codewords[bitIndex >>> 3] >>> (7 - (bitIndex & 7))) & 1) !== 0 : false;
          if (maskBit(mask, row, col)) val = !val;
          m[row][col] = val;
          bitIndex++;
        }
      }
    }
    writeFormat(m, mask);
    return m;
  }

  function chooseVersion(byteLength) {
    for (var v = 1; v <= 6; v++) {
      var required = 4 + 8 + byteLength * 8;
      if (required <= VERSIONS[v].data * 8) return v;
    }
    throw new Error('الحد الأقصى المدعوم حاليًا 106 بايت تقريبًا. اختصر الرابط أو استخدم رابطًا مختصرًا موثوقًا.');
  }

  function encode(text) {
    var bytes = utf8Bytes(String(text));
    var version = chooseVersion(bytes.length);
    var codewords = makeCodewords(bytes, version);
    return { version: version, matrix: buildMatrix(codewords, version, 0), bytes: bytes.length };
  }

  function toSvg(text, pixels) {
    var result = encode(text), matrix = result.matrix;
    var n = matrix.length, quiet = 4, full = n + quiet * 2;
    var path = [];
    for (var r = 0; r < n; r++) {
      var start = -1;
      for (var c = 0; c <= n; c++) {
        var isBlack = c < n && matrix[r][c];
        if (isBlack && start < 0) start = c;
        if ((!isBlack || c === n) && start >= 0) {
          path.push('M' + (start + quiet) + ' ' + (r + quiet) + 'h' + (c - start) + 'v1h-' + (c - start) + 'z');
          start = -1;
        }
      }
    }
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" width="' + pixels + '" height="' + pixels + '" viewBox="0 0 ' + full + ' ' + full + '"><rect width="100%" height="100%" fill="#fff"/><path d="' + path.join('') + '" fill="#000"/></svg>';
    return { svg: svg, version: result.version, bytes: result.bytes };
  }

  root.ArtboardStudioQR = { encode: encode, toSvg: toSvg };
}(this));
