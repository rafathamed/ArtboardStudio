/* Artboard Studio - "تحويل الصورة" tab.
   Matrix modes (Free Transform / Scale / Rotate / Skew): applied directly to the real image in Illustrator
   (every slider move transforms the actual item about its centre; cancel reverts exactly).
   Mesh modes (Distort / Perspective / Warp / Split Warp x3): the image is warped on a canvas with draggable
   handles; each change is pushed as a frame to a linked placeholder on the artwork (same live mechanism as the
   image-editing tab) and the full-resolution warp is placed when applying. */
(function () {
  'use strict';
  var SH = window.ABSCRShared, M = window.ABSMesh;
  function $(id) { return document.getElementById(id); }
  if (!SH || !M || !$('panel-xf')) return;
  var hostEval = SH.hostEval, jsq = SH.jsq;

  var MODES = [
    ['free', 'Free Transform', 'تحويل حر'], ['scale', 'Scale', 'تحجيم'], ['rotate', 'Rotate', 'تدوير'], ['skew', 'Skew', 'إمالة'],
    ['distort', 'Distort', 'تشويه حر'], ['perspective', 'Perspective', 'منظور'], ['warp', 'Warp', 'التفاف'],
    ['splitH', 'Split Warp Horizontally', 'تقسيم أفقي'], ['splitV', 'Split Warp Vertically', 'تقسيم رأسي'], ['splitX', 'Split Warp Crosswise', 'تقسيم متقاطع']
  ];
  var ICONS = {
    free: '<rect x="6" y="6" width="12" height="12"/><rect x="3" y="3" width="4" height="4" fill="currentColor"/><rect x="17" y="3" width="4" height="4" fill="currentColor"/><rect x="3" y="17" width="4" height="4" fill="currentColor"/><rect x="17" y="17" width="4" height="4" fill="currentColor"/>',
    scale: '<rect x="3" y="11" width="10" height="10"/><path d="M11 13L21 3M15 3h6v6"/>',
    rotate: '<path d="M20 12a8 8 0 1 1-2.4-5.7"/><path d="M20 4v5h-5"/>',
    skew: '<path d="M8 6h13l-5 12H3z"/>',
    distort: '<path d="M5 7l14-3 2 12-15 4z"/><circle cx="5" cy="7" r="1.6" fill="currentColor"/><circle cx="19" cy="4" r="1.6" fill="currentColor"/><circle cx="21" cy="16" r="1.6" fill="currentColor"/><circle cx="6" cy="20" r="1.6" fill="currentColor"/>',
    perspective: '<path d="M8 5h8l5 14H3z"/><path d="M12 5v14" stroke-dasharray="2 2"/>',
    warp: '<path d="M3 7c4-4 6 4 9 0s5 4 9 0M3 17c4-4 6 4 9 0s5 4 9 0"/><path d="M3 7v10M21 7v10"/><path d="M3 12c4-4 6 4 9 0s5 4 9 0" opacity=".5"/>',
    splitH: '<rect x="4" y="4" width="16" height="16" rx="1"/><path d="M4 12h16"/><circle cx="12" cy="12" r="2" fill="currentColor"/><path d="M12 6v2.5M12 15.5V18" opacity=".6"/>',
    splitV: '<rect x="4" y="4" width="16" height="16" rx="1"/><path d="M12 4v16"/><circle cx="12" cy="12" r="2" fill="currentColor"/><path d="M6 12h2.5M15.5 12H18" opacity=".6"/>',
    splitX: '<rect x="4" y="4" width="16" height="16" rx="1"/><path d="M12 4v16M4 12h16"/><circle cx="12" cy="12" r="2" fill="currentColor"/>'
  };
  function icon(k) { return '<svg class="xf-ico" viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + ICONS[k] + '</svg>'; }
  var MATRIX = { free: 1, scale: 1, rotate: 1, skew: 1 };
  var ROWS = [
    { k: 'sx', label: 'العرض %', min: 10, max: 400, step: 1, def: 100, modes: ['free', 'scale'] },
    { k: 'sy', label: 'الارتفاع %', min: 10, max: 400, step: 1, def: 100, modes: ['free', 'scale'] },
    { k: 'rot', label: 'الدوران °', min: -180, max: 180, step: 0.5, def: 0, modes: ['free', 'rotate'] },
    { k: 'skx', label: 'إمالة أفقية °', min: -75, max: 75, step: 0.5, def: 0, modes: ['free', 'skew'] },
    { k: 'sky', label: 'إمالة رأسية °', min: -75, max: 75, step: 0.5, def: 0, modes: ['free', 'skew'] }
  ];
  var HINTS = {
    distort: 'اسحب أي ركن بحرية لتشويه الصورة.',
    perspective: 'اسحب ركنًا: يتحرك الركن المقابل له على نفس الضلع بشكل متناظر لإعطاء منظور.',
    warp: 'اسحب أي نقطة من الشبكة (16 نقطة) لثني الصورة بسلاسة.',
    splitH: 'خط تقسيم أفقي في المنتصف: اسحب النقاط (6 نقاط) لثني الصورة من كل جانب على حدة.',
    splitV: 'خط تقسيم رأسي في المنتصف: اسحب النقاط (6 نقاط).',
    splitX: 'خطّا تقسيم متقاطعان (9 نقاط): اسحب أي نقطة، بما فيها المركز.'
  };
  var PREVIEW_MAX = 640, HI_MAX = 1400, SETTLE_MS = 260, PROXY_MAX = 1400;

  var st = { mode: 'free', session: null, info: null, vals: null, flight: false, dirty: false,
             full: null, srcLo: null, srcHi: null, pts: null, nb: [0, 0, 1, 1], live: null, busy: false, drag: -1, last: null, settleTimer: 0, raf: false };

  function status(msg, kind) { var el = $('xfStatus'); el.textContent = msg || ''; el.className = 'cr-status' + (kind ? ' ' + kind : ''); }
  function defVals() { return { sx: 100, sy: 100, rot: 0, skx: 0, sky: 0, fh: false, fv: false, link: true }; }
  function isMatrix() { return !!MATRIX[st.mode]; }
  function refreshLock() { var c = $('xfControls'); if (c) { c.classList.toggle('xf-locked', !st.session); c.setAttribute('aria-disabled', st.session ? 'false' : 'true'); } }
  function owner(on) { refreshLock(); if (window.ABSSession) window.ABSSession.owner = on ? 'xf' : (window.ABSSession.owner === 'xf' ? null : window.ABSSession.owner); }

  /* ---------- build UI ---------- */
  function build() {
    var box = $('xfModes'); box.innerHTML = '';
    MODES.forEach(function (m) {
      var b = document.createElement('button'); b.type = 'button'; b.className = 'xf-mode' + (m[0] === st.mode ? ' active' : ''); b.setAttribute('data-mode', m[0]);
      b.innerHTML = icon(m[0]) + '<span class="xf-txt"><b>' + m[1] + '</b><small>' + m[2] + '</small></span>'; b.addEventListener('click', function () { setMode(m[0]); }); box.appendChild(b);
    });
    var rows = $('xfRows'); rows.innerHTML = '';
    ROWS.forEach(function (r) {
      var d = document.createElement('div'); d.className = 'xf-row'; d.setAttribute('data-modes', r.modes.join(' '));
      d.innerHTML = '<span class="xf-val" id="xfv_' + r.k + '"></span><input type="range" id="xfr_' + r.k + '" min="' + r.min + '" max="' + r.max + '" step="' + r.step + '" value="' + r.def + '"><label for="xfr_' + r.k + '">' + r.label + '</label>';
      rows.appendChild(d);
      d.querySelector('input').addEventListener('input', function () { onSlider(r.k, parseFloat(this.value)); });
      d.querySelector('input').addEventListener('dblclick', function () { this.value = r.def; onSlider(r.k, r.def); });
    });
    $('xfLink').addEventListener('change', function () { st.vals.link = this.checked; });
    $('xfFlipH').addEventListener('change', function () { st.vals.fh = this.checked; pumpMatrix(); });
    $('xfFlipV').addEventListener('change', function () { st.vals.fv = this.checked; pumpMatrix(); });
    syncUI();
  }

  function syncUI() {
    ROWS.forEach(function (r) { var v = st.vals ? st.vals[r.k] : r.def; $('xfr_' + r.k).value = v; $('xfv_' + r.k).textContent = (Math.round(v * 10) / 10) + (r.k === 'sx' || r.k === 'sy' ? '%' : '°'); });
    $('xfLink').checked = st.vals ? st.vals.link : true; $('xfFlipH').checked = st.vals ? st.vals.fh : false; $('xfFlipV').checked = st.vals ? st.vals.fv : false;
    var m = st.mode, mat = isMatrix();
    Array.prototype.forEach.call(document.querySelectorAll('#xfRows .xf-row'), function (row) { row.classList.toggle('hidden', row.getAttribute('data-modes').split(' ').indexOf(m) < 0); });
    $('xfLinkRow').classList.toggle('hidden', !(m === 'free' || m === 'scale'));
    $('xfFlipRow').classList.toggle('hidden', m !== 'free');
    $('xfNative').classList.toggle('hidden', !mat);
    $('xfMatrixBox').classList.toggle('hidden', !mat);
    $('xfMeshBox').classList.toggle('hidden', mat);
    $('xfModeRow').classList.toggle('hidden', mat);
    $('xfApply').firstElementChild.textContent = mat ? 'تثبيت التحويل على الصورة' : 'تطبيق على الصورة في Illustrator';
    $('xfHint').textContent = HINTS[m] || '';
    Array.prototype.forEach.call(document.querySelectorAll('.xf-mode'), function (b) { b.classList.toggle('active', b.getAttribute('data-mode') === m); });
  }

  /* ---------- matrix modes: direct on the image ---------- */
  function onSlider(k, v) {
    st.vals[k] = v;
    if (st.vals.link && (k === 'sx' || k === 'sy') && st.mode !== 'rotate') { var o = k === 'sx' ? 'sy' : 'sx'; st.vals[o] = v; }
    syncUI(); pumpMatrix();
  }
  function pumpMatrix() {
    if (!st.session || st.session.kind !== 'matrix') return;
    if (st.flight) { st.dirty = true; return; }
    var v = st.vals; st.flight = true; st.dirty = false;
    hostEval('AIArtboardStudio.xfSet(' + [v.sx, v.sy, v.rot, v.skx, v.sky, v.fh ? 1 : 0, v.fv ? 1 : 0].join(',') + ')', function (ok, msg) {
      st.flight = false;
      if (!ok) { status('توقف التحويل: ' + msg, 'error'); closeSession(false); return; }
      if (st.dirty) pumpMatrix();
    });
  }

  /* ---------- mesh modes ---------- */
  function canvasOf(id) { var c = document.createElement('canvas'); c.width = id.width; c.height = id.height; c.getContext('2d').putImageData(id, 0, 0); return c; }
  function scaled(c, max) {
    var f = Math.min(1, max / Math.max(c.width, c.height)), w = Math.max(1, Math.round(c.width * f)), h = Math.max(1, Math.round(c.height * f));
    var o = document.createElement('canvas'); o.width = w; o.height = h; var g = o.getContext('2d'); g.imageSmoothingQuality = 'high'; g.drawImage(c, 0, 0, w, h); return o;
  }
  function spec() { return { mode: st.mode, pts: st.pts }; }

  function geom() { // where the original image sits inside the stage
    var s = $('xfStage'), W = s.width, H = s.height, ar = st.info ? st.info.ar : 1, iw, ih;
    var maxw = W * 0.56, maxh = H * 0.56; if (maxw / ar <= maxh) { iw = maxw; ih = maxw / ar; } else { ih = maxh; iw = maxh * ar; }
    return { ox: (W - iw) / 2, oy: (H - ih) / 2, iw: iw, ih: ih, W: W, H: H };
  }

  function drawStage(res) {
    var s = $('xfStage'), g = s.getContext('2d'), G = geom();
    g.clearRect(0, 0, G.W, G.H);
    g.fillStyle = '#1d1d1d'; g.fillRect(0, 0, G.W, G.H);
    g.strokeStyle = '#3a3a3a'; g.setLineDash([4, 4]); g.strokeRect(G.ox + 0.5, G.oy + 0.5, G.iw, G.ih); g.setLineDash([]);
    if (res) g.drawImage(res.canvas, G.ox + res.nb[0] * G.iw, G.oy + res.nb[1] * G.ih, (res.nb[2] - res.nb[0]) * G.iw, (res.nb[3] - res.nb[1]) * G.ih);
    g.lineWidth = 1; g.strokeStyle = 'rgba(80,160,255,.9)';
    M.guides(st.mode, st.pts).forEach(function (line) { g.beginPath(); line.forEach(function (p, i) { var X = G.ox + p.x * G.iw, Y = G.oy + p.y * G.ih; if (i) g.lineTo(X, Y); else g.moveTo(X, Y); }); g.stroke(); });
    st.pts.forEach(function (p, i) { var X = G.ox + p.x * G.iw, Y = G.oy + p.y * G.ih; g.beginPath(); g.arc(X, Y, i === st.drag ? 7 : 5.5, 0, 6.2832); g.fillStyle = i === st.drag ? '#ffd24a' : '#fff'; g.fill(); g.lineWidth = 1.5; g.strokeStyle = '#1a5fd0'; g.stroke(); });
  }

  function renderMesh() {
    if (!st.srcLo || !st.pts) return;
    var res = M.render(st.srcLo, spec(), { maxSide: PREVIEW_MAX * 1.6, quality: 'low' });
    st.nb = res.nb; st.last = res; drawStage(res);
    sendFrame(res.canvas, res.nb);
  }
  function scheduleMesh() {
    window.clearTimeout(st.settleTimer); st.settleTimer = window.setTimeout(settleMesh, SETTLE_MS);
    if (st.raf) return; st.raf = true; (window.requestAnimationFrame || window.setTimeout)(function () { st.raf = false; renderMesh(); });
  }
  function settleMesh() {
    var L = st.live; if (!L || !L.on || !st.srcHi) return;
    var res = M.render(st.srcHi, spec(), { maxSide: HI_MAX, quality: 'high' });
    st.nb = res.nb; sendFrame(res.canvas, res.nb);
  }

  /* live frames (single-flight, latest wins) */
  function tmpDir() { var p = st.info.outPath, i = Math.max(p.lastIndexOf('\\'), p.lastIndexOf('/')); return { dir: p.substring(0, i), sep: p.charAt(i) }; }
  function writeFrame(cv) {
    var L = st.live, b64 = cv.toDataURL('image/png').split(',')[1], d = tmpDir();
    var path = d.dir + d.sep + 'abs_xf_' + L.stamp + '_' + (++L.n) + '.png';
    var wr = window.cep.fs.writeFile(path, b64, window.cep.encoding.Base64);
    return (!wr || wr.err !== 0) ? null : path;
  }
  function dropFile(p) { if (p) try { window.cep.fs.deleteFile(p); } catch (e) {} }
  function sendFrame(cv, nb) {
    var L = st.live; if (!L || !L.on) return;
    if (L.inflight) { L.pending = true; return; }
    var path = writeFrame(cv); if (!path) { stopLive('تعذّرت كتابة إطار المعاينة؛ استمر التشويه داخل اللوحة فقط.'); return; }
    L.inflight = true; L.pending = false;
    hostEval('AIArtboardStudio.liveFrame(' + jsq(path) + ',' + JSON.stringify(nb) + ')', function (ok, msg) {
      L.inflight = false; dropFile(L.last); L.last = path;
      if (!ok) { stopLive('توقفت المعاينة المباشرة: ' + msg + ' — يمكنك متابعة التشويه داخل اللوحة ثم «تطبيق».'); return; }
      if (L.pending) { L.pending = false; window.setTimeout(scheduleMesh, 60); }
    });
  }
  function liveLabel(on) { var el = $('xfLiveState'); el.className = 'cr-livestate' + (on ? ' on' : ''); el.textContent = on ? 'مباشر على الصورة في Illustrator' : (isMatrix() ? 'يُطبَّق مباشرةً على الصورة' : 'معاينة داخل اللوحة فقط'); }

  function startLive(done) {
    st.live = null;
    var base = st.info; if (!$('xfLive').checked) { liveLabel(false); return done(false); }
    var L = { on: false, inflight: false, pending: false, n: 0, stamp: new Date().getTime(), last: null }; st.live = L;
    var res = M.render(st.srcLo, spec(), { maxSide: PREVIEW_MAX, quality: 'low' }), path = writeFrame(res.canvas);
    if (!path) { st.live = null; return done(false); }
    hostEval('AIArtboardStudio.liveBegin(' + jsq(path) + ',' + JSON.stringify(base.bounds) + ',' + JSON.stringify(res.nb) + ')', function (ok, msg) {
      if (!ok) { dropFile(path); st.live = null; liveLabel(false); status('تعذّر بدء المعاينة على الصورة (' + msg + ')؛ سيتم التشويه داخل اللوحة.', 'error'); return done(false); }
      L.on = true; L.last = path; liveLabel(true); done(true);
    });
  }
  function endLive(cb) {
    var L = st.live; st.live = null; window.clearTimeout(st.settleTimer); liveLabel(false);
    if (!L || !L.on) { if (L) dropFile(L.last); return cb && cb(true); }
    hostEval('AIArtboardStudio.liveEnd()', function (ok, msg) {
      dropFile(L.last);
      if (ok && st.info) { try { var r = JSON.parse(msg); if (r && r.bounds && r.bounds.length === 4) st.info.bounds = r.bounds; } catch (e) {} }
      if (cb) cb(ok, msg);
    });
  }
  function stopLive(msg) { endLive(function () { status(msg, 'error'); }); }

  /* proxy export for mesh modes */
  function ensureProxy(cb) {
    if (st.srcLo) return cb(null);
    var ppi = parseFloat($('xfPpi').value) || 300;
    window.ABSBusy.show('جارٍ تحميل الصورة من Illustrator…');
    SH.exportAndDecode(ppi, PROXY_MAX, function (err, info, id) {
      if (err) { window.ABSBusy.hide(); return cb(err); }
      try {
        st.full = canvasOf(id); st.srcHi = scaled(st.full, HI_MAX); st.srcLo = scaled(st.full, PREVIEW_MAX);
        st.info.outPath = info.outPath; st.info.bounds = info.bounds; st.info.ar = id.width / id.height;
      } catch (e) { window.ABSBusy.hide(); return cb('تعذّر فتح الصورة: ' + (e.message || e)); }
      window.ABSBusy.hide(); cb(null);
    });
  }

  function startMesh(cb) {
    ensureProxy(function (err) {
      if (err) return cb(err);
      st.pts = M.identityPoints(st.mode); st.drag = -1;
      var res = M.render(st.srcLo, spec(), { maxSide: PREVIEW_MAX * 1.6, quality: 'low' }); st.nb = res.nb; drawStage(res);
      startLive(function () { cb(null); });
    });
  }

  /* ---------- modes / sessions ---------- */
  function setMode(m) {
    if (m === st.mode) return;
    var wasMatrix = isMatrix(); st.mode = m;
    if (!st.session) { syncUI(); return; }
    var nowMatrix = isMatrix();
    if (wasMatrix && nowMatrix) { syncUI(); return; }
    if (!wasMatrix && !nowMatrix) { // between mesh modes: fresh grid, keep the live session
      st.pts = M.identityPoints(m); st.drag = -1; syncUI(); renderMesh(); return;
    }
    // switching category: undo the current one first
    st.busy = true;
    var next = function () {
      st.vals = defVals(); syncUI();
      if (nowMatrix) { st.session.kind = 'matrix'; liveLabel(false); st.busy = false; status('جاهز: حرّك الأشرطة وشاهد التغيير على الصورة مباشرةً.', 'success'); }
      else { st.session.kind = 'mesh'; startMesh(function (err) { st.busy = false; if (err) { status(err, 'error'); closeSession(false); return; } status(st.live ? 'المعاينة المباشرة تعمل: اسحب النقاط في اللوحة وشاهد الصورة تتغير في Illustrator.' : 'اسحب النقاط لتشويه الصورة ثم اضغط «تطبيق».', 'success'); }); }
    };
    if (wasMatrix) hostEval('AIArtboardStudio.xfSet(100,100,0,0,0,0,0)', function () { next(); });
    else endLive(function () { st.pts = null; next(); });
  }

  function load() {
    if (st.busy) return;
    if (!SH.fsOk()) { status('هذه الميزة تعمل داخل Illustrator فقط.', 'error'); return; }
    if (window.ABSSession && window.ABSSession.owner && window.ABSSession.owner !== 'xf') { status('أنهِ أو ألغِ جلسة «تعديل الصور» أولًا ثم حمّل الصورة هنا.', 'error'); return; }
    if (st.session) { closeSession(false, function () { load(); }); return; }
    st.busy = true; $('xfLoad').disabled = true; status('جارٍ قراءة الصورة المحددة…');
    hostEval('AIArtboardStudio.xfBegin()', function (ok, body) {
      if (!ok) { st.busy = false; $('xfLoad').disabled = false; status(body, 'error'); return; }
      var info; try { info = JSON.parse(body); } catch (e) { st.busy = false; $('xfLoad').disabled = false; status('استجابة غير مفهومة من Illustrator.', 'error'); return; }
      info.ar = Math.max(1e-6, (info.bounds[2] - info.bounds[0])) / Math.max(1e-6, (info.bounds[1] - info.bounds[3]));
      st.info = info; st.vals = defVals(); st.srcLo = st.srcHi = st.full = null; st.pts = null;
      st.session = { kind: isMatrix() ? 'matrix' : 'mesh' }; owner(true);
      $('xfWorkspace').classList.remove('hidden'); $('xfCancel').classList.remove('hidden'); syncUI();
      var fin = function (err) {
        st.busy = false; $('xfLoad').disabled = false;
        if (err) { status(err, 'error'); closeSession(false); return; }
        status(isMatrix() ? 'جاهز: حرّك الأشرطة وشاهد التغيير على الصورة مباشرةً.' : (st.live ? 'المعاينة المباشرة تعمل: اسحب النقاط في اللوحة وشاهد الصورة تتغير في Illustrator.' : 'اسحب النقاط لتشويه الصورة ثم اضغط «تطبيق».'), 'success');
      };
      if (isMatrix()) { liveLabel(false); fin(null); } else startMesh(fin);
    });
  }

  /* leave the session; revert = true restores the original */
  function closeSession(keep, cb) {
    var s = st.session, matrix = s && s.kind === 'matrix';
    st.session = null; st.flight = false; st.dirty = false; st.pts = null; st.srcLo = st.srcHi = st.full = null;
    $('xfWorkspace').classList.add('hidden'); $('xfCancel').classList.add('hidden'); owner(false);
    var done = function () { st.info = null; if (cb) cb(); };
    if (!s) return done();
    if (matrix) hostEval('AIArtboardStudio.xfEnd(' + (keep ? 'true' : 'false') + ')', function () { done(); });
    else endLive(function () { done(); });
  }

  function apply() {
    if (st.busy || !st.session) return;
    if (st.session.kind === 'matrix') {
      st.busy = true;
      hostEval('AIArtboardStudio.xfEnd(true)', function (ok, msg) {
        st.busy = false; var s = st.session; st.session = null; $('xfWorkspace').classList.add('hidden'); $('xfCancel').classList.add('hidden'); owner(false); st.info = null;
        status(ok ? 'تم تثبيت التحويل على الصورة.' : msg, ok ? 'success' : 'error');
      });
      return;
    }
    if (M.isIdentity(st.mode, st.pts)) { status('لم تحرّك أي نقطة بعد.', 'error'); return; }
    var mode = $('xfApplyMode').value;
    if (mode === 'replace' && !ABSDialog.gate('xfApply', 'سيُستبدل الأصل بنسخة مشوّهة مضمّنة في الملف (لا يتغير الملف الأصلي على القرص، ويمكنك التراجع بـ Ctrl+Z). هل تريد المتابعة؟', apply, { title: 'تطبيق التشويه', ok: 'تطبيق' })) return;
    st.busy = true; $('xfApply').disabled = true; $('xfCancel').disabled = true; window.ABSBusy.show('جارٍ تطبيق التشويه بالدقة الكاملة…');
    var hadLive = !!st.live, ppi = parseFloat($('xfPpi').value) || 300, pts = JSON.parse(JSON.stringify(st.pts)), outPath = st.info.outPath, md = st.mode;
    var fail = function (msg) {
      window.ABSBusy.hide(); st.busy = false; $('xfApply').disabled = false; $('xfCancel').disabled = false;
      status(msg + (hadLive ? ' — أُعيدت المعاينة المباشرة.' : ''), 'error');
      if (hadLive) startLive(function () { scheduleMesh(); });
    };
    endLive(function () {
      window.setTimeout(function () {
        SH.exportAndDecode(ppi, 4096, function (err, info, id) {
          if (err) return fail(err);
          var bounds = info.bounds, res, path;
          try {
            res = M.render(canvasOf(id), { mode: md, pts: pts }, { maxSide: 4096, quality: 'high' });
            var b64 = res.canvas.toDataURL('image/png').split(',')[1];
            var wr = window.cep.fs.writeFile(outPath, b64, window.cep.encoding.Base64);
            if (!wr || wr.err !== 0) throw new Error('تعذّرت كتابة الملف المؤقت (رمز ' + (wr && wr.err) + ').');
          } catch (e) { return fail('فشلت المعالجة: ' + (e.message || e)); }
          var w = bounds[2] - bounds[0], h = bounds[1] - bounds[3], nb = res.nb;
          var place = [bounds[0] + nb[0] * w, bounds[1] - nb[1] * h, bounds[0] + nb[2] * w, bounds[1] - nb[3] * h];
          hostEval('AIArtboardStudio.applyEditedImage(' + jsq(outPath) + ',' + JSON.stringify(bounds) + ',' + jsq(mode) + ',' + JSON.stringify(place) + ')', function (ok, msg) {
            try { window.cep.fs.deleteFile(outPath); } catch (e3) {}
            if (!ok) return fail(msg);
            window.ABSBusy.hide(); st.busy = false; $('xfApply').disabled = false; $('xfCancel').disabled = false;
            st.session = null; st.pts = null; st.srcLo = st.srcHi = st.full = null; st.info = null; owner(false);
            $('xfWorkspace').classList.add('hidden'); $('xfCancel').classList.add('hidden'); status(msg, 'success');
          });
        });
      }, 30);
    });
  }

  function cancel() {
    if (st.busy || !st.session) return;
    closeSession(false, function () { status('أُلغي التحويل وأُعيدت الصورة الأصلية كما كانت.', 'success'); });
  }

  function reset() {
    if (!st.session) return;
    if (st.session.kind === 'matrix') { st.vals = defVals(); syncUI(); pumpMatrix(); }
    else { st.pts = M.identityPoints(st.mode); st.drag = -1; renderMesh(); }
  }

  /* ---------- stage pointer handling (mesh) ---------- */
  function pos(e) { var s = $('xfStage'), r = s.getBoundingClientRect(), t = (e.touches && e.touches[0]) || e; return { x: (t.clientX - r.left) * s.width / r.width, y: (t.clientY - r.top) * s.height / r.height }; }
  function onDown(e) {
    if (!st.pts || st.session.kind !== 'mesh' || st.busy) return;
    var p = pos(e), G = geom(), best = -1, bd = 18 * 18;
    st.pts.forEach(function (q, i) { var dx = G.ox + q.x * G.iw - p.x, dy = G.oy + q.y * G.ih - p.y, d = dx * dx + dy * dy; if (d < bd) { bd = d; best = i; } });
    if (best < 0) return; e.preventDefault();
    st.drag = best; st.grab = { dx: G.ox + st.pts[best].x * G.iw - p.x, dy: G.oy + st.pts[best].y * G.ih - p.y };
    drawStage(st.last);
  }
  function onMove(e) {
    if (st.drag < 0) return; e.preventDefault();
    var p = pos(e), G = geom(), i = st.drag;
    var x = (p.x + st.grab.dx - G.ox) / G.iw, y = (p.y + st.grab.dy - G.oy) / G.ih;
    x = Math.max(-0.9, Math.min(1.9, x)); y = Math.max(-0.9, Math.min(1.9, y));
    st.pts[i].x = x; st.pts[i].y = y;
    if (st.mode === 'perspective') { st.pts[i ^ 1].x = 1 - x; st.pts[i ^ 2].y = 1 - y; }
    scheduleMesh();
  }
  function onUp() { if (st.drag < 0) return; st.drag = -1; drawStage(st.last); }

  function init() {
    st.vals = defVals(); build();
    $('xfLoad').addEventListener('click', load);
    $('xfApply').addEventListener('click', apply);
    $('xfCancel').addEventListener('click', cancel);
    $('xfReset').addEventListener('click', reset);
    $('xfNative').addEventListener('click', function () { hostEval('AIArtboardStudio.xfNativeTool(' + jsq(st.mode) + ')', function (ok, msg) { status(ok ? 'فُعّلت أداة Illustrator الأصلية؛ استخدمها مباشرةً على الصورة (الأشرطة أعلاه تبقى متاحة).' : msg, ok ? 'success' : 'error'); }); });
    $('xfLive').addEventListener('change', function () {
      if (!st.session || st.session.kind !== 'mesh' || st.busy || !st.srcLo) return;
      if (this.checked) startLive(function (ok) { if (ok) { scheduleMesh(); status('المعاينة المباشرة تعمل.', 'success'); } });
      else endLive(function () { status('أُوقفت المعاينة على الصورة؛ المعاينة داخل اللوحة فقط.', 'success'); });
    });
    var s = $('xfStage'); s.width = 320; s.height = 320;
    ['mousedown', 'touchstart'].forEach(function (ev) { s.addEventListener(ev, onDown, { passive: false }); });
    window.addEventListener('mousemove', onMove); window.addEventListener('touchmove', onMove, { passive: false });
    ['mouseup', 'touchend', 'touchcancel'].forEach(function (ev) { window.addEventListener(ev, onUp); });
    window.addEventListener('beforeunload', function () {
      if (!st.session) return;
      try { window.__adobe_cep__.evalScript(st.session.kind === 'matrix' ? 'AIArtboardStudio.xfEnd(true)' : 'AIArtboardStudio.liveEnd()'); } catch (e) {}
    });
  }
  init();
  window.ABSTransformUI = { _state: st, load: load, apply: apply, cancel: cancel, setMode: setMode, _render: renderMesh, _settle: settleMesh };
})();
