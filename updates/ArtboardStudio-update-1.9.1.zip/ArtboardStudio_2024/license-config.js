/* Set this to the HTTPS URL of your deployed Artboard Studio license server before distribution. */
window.ARTBOARD_STUDIO_BUILD = '1.4.0';
window.ARTBOARD_STUDIO_LICENSE_CONFIG = {
  serverUrl: 'https://artboard-studio-license.rafat-hamed.workers.dev',
  product: 'artboard-studio',
  purchaseUrl: 'https://wa.me/201127502899?text=%D8%A3%D8%B1%D8%BA%D8%A8%20%D9%81%D9%8A%20%D8%B4%D8%B1%D8%A7%D8%A1%20Artboard%20Studio'
};
