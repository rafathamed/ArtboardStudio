/* Artboard Studio - image adjustment engine (Camera-Raw-style controls).
   Pure JavaScript, no dependencies, works on ImageData-like objects {data, width, height}.
   All tone math runs in a simple gamma-2.2 space; local-contrast tools use cached gaussian blurs. */
(function (global) {
  'use strict';

  var BAND_CENTERS = [0, 30, 60, 120, 180, 240, 270, 300];
  var GAMMA = 2.2;

  function zeros(n) { var a = []; for (var i = 0; i < n; i++) a.push(0); return a; }

  function defaults() {
    return {
      exposure: 0, contrast: 0, highlights: 0, shadows: 0, whites: 0, blacks: 0,
      temp: 0, tint: 0, vibrance: 0, saturation: 0,
      texture: 0, clarity: 0, dehaze: 0,
      vignette: 0, vigMid: 50, vigFeather: 50,
      grain: 0, grainSize: 25,
      sharpen: 0, sharpenRadius: 1, nrLum: 0, nrColor: 0,
      bw: false,
      hue: zeros(8), sat: zeros(8), lum: zeros(8)
    };
  }

  function normalize(p) {
    var d = defaults(), out = {}, k;
    for (k in d) if (Object.prototype.hasOwnProperty.call(d, k)) out[k] = d[k];
    if (p) for (k in p) if (Object.prototype.hasOwnProperty.call(p, k) && p[k] !== undefined) out[k] = p[k];
    ['hue', 'sat', 'lum'].forEach(function (key) {
      var src = out[key] && out[key].length === 8 ? out[key] : zeros(8), a = [];
      for (var i = 0; i < 8; i++) a.push(Number(src[i]) || 0);
      out[key] = a;
    });
    return out;
  }

  function isNeutral(p) {
    p = normalize(p);
    var d = defaults(), k;
    for (k in d) {
      if (k === 'hue' || k === 'sat' || k === 'lum') {
        for (var i = 0; i < 8; i++) if (p[k][i] !== 0) return false;
      } else if (p[k] !== d[k]) {
        // vignette/grain sub-settings only matter when their amount is non-zero
        if ((k === 'vigMid' || k === 'vigFeather') && !p.vignette) continue;
        if (k === 'grainSize' && !p.grain) continue;
        if (k === 'sharpenRadius' && !p.sharpen) continue;
        return false;
      }
    }
    return true;
  }

  /* ---------- gaussian blur (3 box passes, edge-clamped) ---------- */
  function boxesForGauss(sigma, n) {
    var wIdeal = Math.sqrt((12 * sigma * sigma / n) + 1);
    var wl = Math.floor(wIdeal); if (wl % 2 === 0) wl--;
    var wu = wl + 2;
    var mIdeal = (12 * sigma * sigma - n * wl * wl - 4 * n * wl - 3 * n) / (-4 * wl - 4);
    var m = Math.round(mIdeal), sizes = [];
    for (var i = 0; i < n; i++) sizes.push(i < m ? wl : wu);
    return sizes;
  }

  function boxH(src, dst, w, h, r) {
    var iarr = 1 / (r + r + 1);
    for (var y = 0; y < h; y++) {
      var base = y * w, ti = base, li = base, ri = base + r;
      var fv = src[base], lv = src[base + w - 1], val = (r + 1) * fv, j;
      for (j = 0; j < r; j++) val += src[base + Math.min(j, w - 1)];
      for (j = 0; j <= r; j++) { val += (ri < base + w ? src[ri] : lv) - fv; ri++; dst[ti++] = val * iarr; }
      for (j = r + 1; j < w - r; j++) { val += src[ri++] - src[li++]; dst[ti++] = val * iarr; }
      for (j = w - r; j < w; j++) { val += lv - src[li++]; dst[ti++] = val * iarr; }
    }
  }

  function boxV(src, dst, w, h, r) {
    var iarr = 1 / (r + r + 1);
    for (var x = 0; x < w; x++) {
      var ti = x, li = x, ri = x + r * w;
      var fv = src[x], lv = src[x + w * (h - 1)], val = (r + 1) * fv, j;
      for (j = 0; j < r; j++) val += src[x + Math.min(j, h - 1) * w];
      for (j = 0; j <= r; j++) { val += (ri < w * h ? src[ri] : lv) - fv; ri += w; dst[ti] = val * iarr; ti += w; }
      for (j = r + 1; j < h - r; j++) { val += src[ri] - src[li]; ri += w; li += w; dst[ti] = val * iarr; ti += w; }
      for (j = h - r; j < h; j++) { val += lv - src[li]; li += w; dst[ti] = val * iarr; ti += w; }
    }
  }

  function gaussBlur(src, w, h, sigma) {
    var out = new Float32Array(src.length); out.set(src);
    if (sigma < 0.3) return out;
    var tmp = new Float32Array(src.length), sizes = boxesForGauss(sigma, 3);
    var maxR = Math.max(0, Math.floor((Math.min(w, h) - 1) / 2) - 1);
    for (var i = 0; i < 3; i++) {
      var r = Math.min(Math.max(0, (sizes[i] - 1) / 2), maxR);
      if (r < 1) continue;
      boxH(out, tmp, w, h, r);
      boxV(tmp, out, w, h, r);
    }
    return out;
  }

  /* ---------- analysis context (cached per loaded image) ---------- */
  function createContext(src, opts) {
    opts = opts || {};
    var w = src.width, h = src.height, n = w * h, d = src.data;
    var luma = new Float32Array(n), j = 0;
    for (var i = 0; i < n; i++, j += 4) luma[i] = (0.2126 * d[j] + 0.7152 * d[j + 1] + 0.0722 * d[j + 2]) / 255;
    var maxDim = Math.max(w, h);
    var ctx = {
      src: src, w: w, h: h, n: n, maxDim: maxDim, fullMax: opts.fullMax || maxDim,
      luma: luma, _cache: {}
    };
    ctx.noCache = !!opts.noCache; // one-shot full-resolution runs: do not keep big arrays alive
    ctx.blur = function (sigma) {
      var key = 'b' + Math.round(sigma * 100);
      if (ctx.noCache) return gaussBlur(luma, w, h, sigma);
      if (!ctx._cache[key]) ctx._cache[key] = gaussBlur(luma, w, h, sigma);
      return ctx._cache[key];
    };
    ctx.chroma = function (sigma) { // [blur(ch - L) - (ch - L)] for R,G,B
      var key = 'c' + Math.round(sigma * 100);
      if (!ctx.noCache && ctx._cache[key]) return ctx._cache[key];
      var res = [];
      for (var c = 0; c < 3; c++) {
        var ch = new Float32Array(n), q = c;
        for (var i = 0; i < n; i++, q += 4) ch[i] = d[q] / 255 - luma[i];
        var bl = gaussBlur(ch, w, h, sigma);
        for (i = 0; i < n; i++) bl[i] -= ch[i];
        res.push(bl);
      }
      if (!ctx.noCache) ctx._cache[key] = res;
      return res;
    };
    ctx.dark = function () {
      if (ctx.noCache || !ctx._cache.dark) {
        var m = new Float32Array(n), q = 0;
        for (var k = 0; k < n; k++, q += 4) m[k] = Math.min(d[q], d[q + 1], d[q + 2]) / 255;
        var dk = gaussBlur(m, w, h, Math.max(2, 0.02 * maxDim));
        if (ctx.noCache) return dk;
        ctx._cache.dark = dk;
      }
      return ctx._cache.dark;
    };
    ctx.release = function () { ctx._cache = {}; };
    return ctx;
  }

  /* ---------- lookup tables ---------- */
  var BAND_I0 = new Uint8Array(361), BAND_T = new Float32Array(361);
  (function () {
    var c = BAND_CENTERS.concat([360]);
    for (var deg = 0; deg <= 360; deg++) {
      var i = 0;
      while (i < 7 && deg >= c[i + 1]) i++;
      var t = (deg - c[i]) / (c[i + 1] - c[i]);
      BAND_I0[deg] = i; BAND_T[deg] = t * t * (3 - 2 * t);
    }
  }());

  function contrastLUT(c) {
    var lut = new Float32Array(1025);
    for (var i = 0; i <= 1024; i++) {
      var v = i / 1024, s = v * v * v * (v * (v * 6 - 15) + 10);
      lut[i] = v + c * (s - v);
    }
    return lut;
  }

  function hash2(x, y) {
    var h = (Math.imul ? Math.imul(x, 374761393) + Math.imul(y, 668265263) : (x * 374761393 + y * 668265263)) | 0;
    h = (h ^ (h >>> 13)) | 0;
    h = (Math.imul ? Math.imul(h, 1274126177) : (h * 1274126177)) | 0;
    h = h ^ (h >>> 16);
    return (h & 0xffff) / 65535;
  }

  /* ---------- main pipeline ---------- */
  function process(ctx, params) {
    var p = normalize(params);
    var w = ctx.w, h = ctx.h, n = ctx.n, src = ctx.src.data, L0 = ctx.luma;
    var out = new Uint8ClampedArray(src.length);
    var maxDim = ctx.maxDim, scale = maxDim / ctx.fullMax;

    // white balance multipliers
    var t = p.temp / 100, ti = p.tint / 100;
    var wr = (1 + 0.28 * t) * (1 + 0.06 * ti), wg = 1 - 0.18 * ti, wb = (1 - 0.28 * t) * (1 + 0.06 * ti);
    var wbOn = p.temp !== 0 || p.tint !== 0;
    var expMul = p.exposure !== 0 ? Math.pow(2, p.exposure / GAMMA) : 1; // 2^EV in linear == 2^(EV/gamma) in gamma space
    var expOn = p.exposure !== 0;
    var shS = p.shadows / 100, hiS = p.highlights / 100, hsOn = p.shadows !== 0 || p.highlights !== 0;
    var shGain = shS * (shS > 0 ? 1.2 : 0.8), shAdd = shS * (shS > 0 ? 0.05 : 0.03), hiGain = hiS * (hiS < 0 ? 0.30 : 0.25);
    var bp = -p.blacks * 0.002, wp = 1 - p.whites * 0.002, lvOn = p.blacks !== 0 || p.whites !== 0;
    var lvInv = 1 / Math.max(0.2, wp - bp);
    var cOn = p.contrast !== 0, LC = cOn ? contrastLUT(p.contrast / 100) : null;
    var dzPos = p.dehaze > 0 ? p.dehaze / 100 * 0.85 : 0, dzNeg = p.dehaze < 0 ? -p.dehaze / 100 * 0.4 : 0;
    var D = dzPos ? ctx.dark() : null;
    var satAmt = p.saturation / 100, vibAmt = p.vibrance / 100, svOn = p.saturation !== 0 || p.vibrance !== 0;
    var mixOn = false, i;
    for (i = 0; i < 8; i++) if (p.hue[i] || p.sat[i] || p.lum[i]) mixOn = true;
    var hslOn = mixOn || p.bw;
    var vigA = p.vignette / 100 * 0.9, vigOn = p.vignette !== 0;
    var vigStart = p.vigMid / 100 * 0.9, vigW = Math.max(0.05, p.vigFeather / 100 * 0.9);
    var grainOn = p.grain > 0, grainAmp = p.grain / 100 * 0.12;
    var grainBlock = Math.max(1, Math.round((1 + p.grainSize / 100 * 3) * maxDim / 1500));

    // local-detail layer (texture / clarity / sharpen / luminance NR) - additive, from source luma
    var detail = null;
    if (p.texture || p.clarity || p.sharpen || p.nrLum) {
      detail = new Float32Array(n);
      var B, k, l, m;
      if (p.texture) {
        B = ctx.blur(Math.max(0.8, 0.0035 * maxDim)); k = p.texture / 100 * 1.3;
        for (i = 0; i < n; i++) detail[i] += k * (L0[i] - B[i]);
      }
      if (p.clarity) {
        B = ctx.blur(Math.max(3, 0.02 * maxDim)); k = p.clarity / 100 * 1.1;
        for (i = 0; i < n; i++) { l = L0[i]; m = 4 * l * (1 - l); detail[i] += k * (l - B[i]) * (0.35 + 0.65 * m); }
      }
      if (p.sharpen) {
        B = ctx.blur(Math.max(0.6, p.sharpenRadius * scale)); k = p.sharpen / 100 * 1.2;
        for (i = 0; i < n; i++) detail[i] += k * (L0[i] - B[i]);
      }
      if (p.nrLum) {
        B = ctx.blur(Math.max(1.5, 0.004 * maxDim));
        var amt = p.nrLum / 100, thr = 0.04 + 0.16 * amt;
        for (i = 0; i < n; i++) {
          var dd = B[i] - L0[i], ad = dd < 0 ? -dd : dd;
          if (ad < thr) detail[i] += dd * amt * (1 - ad / thr);
        }
      }
    }

    // chroma noise reduction (blur of colour-minus-luma, applied as a delta)
    var chromaD = null, amtC = 0;
    if (p.nrColor) { chromaD = ctx.chroma(Math.max(1.5, 0.008 * maxDim)); amtC = p.nrColor / 100; }

    var hslTmp = [0, 0, 0];
    var cx = (w - 1) / 2 || 1, cy = (h - 1) / 2 || 1;
    var r, g, b, a, L, Lc, d0, lum, mx, mn, sat, f, j = 0, x = 0, y = 0;

    for (i = 0; i < n; i++, j += 4) {
      a = src[j + 3];
      if (a === 0) { out[j] = src[j]; out[j + 1] = src[j + 1]; out[j + 2] = src[j + 2]; out[j + 3] = 0; x++; if (x === w) { x = 0; y++; } continue; }
      r = src[j] / 255; g = src[j + 1] / 255; b = src[j + 2] / 255;

      if (wbOn) { r *= wr; g *= wg; b *= wb; }
      if (expOn) { r *= expMul; g *= expMul; b *= expMul; }
      if (hsOn) {
        // gain-based (keeps hue and saturation) plus a small offset so true blacks can lift too
        L = 0.2126 * r + 0.7152 * g + 0.0722 * b; Lc = L < 0 ? 0 : (L > 1.5 ? 1.5 : L);
        var ls = 1 - (Lc > 1 ? 1 : Lc), ms = ls * ls, mh = Lc * Lc;
        var gain = 1 + shGain * ms + hiGain * mh; if (gain < 0) gain = 0;
        d0 = shAdd * ms;
        r = r * gain + d0; g = g * gain + d0; b = b * gain + d0;
      }
      if (lvOn) { r = (r - bp) * lvInv; g = (g - bp) * lvInv; b = (b - bp) * lvInv; }
      if (cOn) {
        r = LC[r <= 0 ? 0 : (r >= 1 ? 1024 : (r * 1024 + 0.5) | 0)];
        g = LC[g <= 0 ? 0 : (g >= 1 ? 1024 : (g * 1024 + 0.5) | 0)];
        b = LC[b <= 0 ? 0 : (b >= 1 ? 1024 : (b * 1024 + 0.5) | 0)];
      }
      if (dzPos) {
        var dv = D[i] * dzPos, den = 1 - dv; if (den < 0.05) den = 0.05;
        r = (r - dv) / den; g = (g - dv) / den; b = (b - dv) / den;
      } else if (dzNeg) {
        r = r * (1 - dzNeg) + dzNeg * 0.82; g = g * (1 - dzNeg) + dzNeg * 0.82; b = b * (1 - dzNeg) + dzNeg * 0.82;
      }
      if (detail) { d0 = detail[i]; r += d0; g += d0; b += d0; }
      if (chromaD) { r += chromaD[0][i] * amtC; g += chromaD[1][i] * amtC; b += chromaD[2][i] * amtC; }

      if (svOn) {
        lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
        mx = r > g ? (r > b ? r : b) : (g > b ? g : b); mn = r < g ? (r < b ? r : b) : (g < b ? g : b);
        sat = mx > 0.0001 ? (mx - mn) / mx : 0; if (sat > 1) sat = 1; if (sat < 0) sat = 0;
        var inv = 1 - sat, vw = inv * inv;
        if (vibAmt !== 0 && r > g && g > b && sat > 0.15 && sat < 0.7) vw *= 0.6; // protect skin tones
        f = 1 + satAmt + vibAmt * vw * 1.5; if (f < 0) f = 0;
        r = lum + (r - lum) * f; g = lum + (g - lum) * f; b = lum + (b - lum) * f;
      }

      if (hslOn) {
        var rr = r < 0 ? 0 : (r > 1 ? 1 : r), gg = g < 0 ? 0 : (g > 1 ? 1 : g), bb = b < 0 ? 0 : (b > 1 ? 1 : b);
        rgb2hsl(rr, gg, bb, hslTmp);
        var hh = hslTmp[0], ss = hslTmp[1], ll = hslTmp[2];
        var deg = Math.round(hh) | 0; if (deg > 360) deg = 360;
        var i0 = BAND_I0[deg], i1 = (i0 + 1) % 8, tt = BAND_T[deg], w0 = 1 - tt;
        if (p.bw) {
          lum = 0.2126 * rr + 0.7152 * gg + 0.0722 * bb;
          var adj = (w0 * p.lum[i0] + tt * p.lum[i1]) / 100 * Math.min(1, ss * 2);
          lum = lum * (1 + adj * 0.8);
          r = g = b = lum;
        } else {
          var dh = (w0 * p.hue[i0] + tt * p.hue[i1]) / 100 * 30;
          var ds = (w0 * p.sat[i0] + tt * p.sat[i1]) / 100;
          var dl = (w0 * p.lum[i0] + tt * p.lum[i1]) / 100 * 0.3;
          hh += dh; if (hh < 0) hh += 360; else if (hh >= 360) hh -= 360;
          ss = ss * (1 + ds); if (ss > 1) ss = 1; if (ss < 0) ss = 0;
          ll += dl * Math.min(1, ss * 1.6); if (ll > 1) ll = 1; if (ll < 0) ll = 0;
          hsl2rgb(hh, ss, ll, hslTmp); r = hslTmp[0]; g = hslTmp[1]; b = hslTmp[2];
        }
      }

      if (vigOn) {
        var dx = (x - cx) / cx, dy = (y - cy) / cy, dist = Math.sqrt(dx * dx + dy * dy) * 0.70710678;
        var tv = (dist - vigStart) / vigW; tv = tv < 0 ? 0 : (tv > 1 ? 1 : tv); tv = tv * tv * (3 - 2 * tv);
        if (vigA < 0) { var fv = 1 + vigA * tv; r *= fv; g *= fv; b *= fv; }
        else { var av = vigA * tv; r += (1 - r) * av; g += (1 - g) * av; b += (1 - b) * av; }
      }

      if (grainOn) {
        var nz = (hash2((x / grainBlock) | 0, (y / grainBlock) | 0) + hash2(((x / grainBlock) | 0) + 7919, ((y / grainBlock) | 0) + 104729) - 1);
        L = 0.2126 * r + 0.7152 * g + 0.0722 * b; Lc = L < 0 ? 0 : (L > 1 ? 1 : L);
        var gm = 0.4 + 0.6 * 4 * Lc * (1 - Lc);
        d0 = nz * grainAmp * gm; r += d0; g += d0; b += d0;
      }

      out[j] = r * 255 + 0.5; out[j + 1] = g * 255 + 0.5; out[j + 2] = b * 255 + 0.5; out[j + 3] = a;
      x++; if (x === w) { x = 0; y++; }
    }
    return out;
  }

  function rgb2hsl(r, g, b, o) {
    var mx = r > g ? (r > b ? r : b) : (g > b ? g : b), mn = r < g ? (r < b ? r : b) : (g < b ? g : b);
    var l = (mx + mn) / 2, d = mx - mn, hh = 0, s = 0;
    if (d > 1e-6) {
      s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
      if (mx === r) hh = (g - b) / d + (g < b ? 6 : 0);
      else if (mx === g) hh = (b - r) / d + 2;
      else hh = (r - g) / d + 4;
      hh *= 60;
    }
    o[0] = hh; o[1] = s; o[2] = l;
  }
  function hue2rgb(p, q, t) {
    if (t < 0) t += 1; if (t > 1) t -= 1;
    if (t < 1 / 6) return p + (q - p) * 6 * t;
    if (t < 1 / 2) return q;
    if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
    return p;
  }
  function hsl2rgb(h, s, l, o) {
    if (s <= 1e-6) { o[0] = o[1] = o[2] = l; return; }
    var q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q, hk = h / 360;
    o[0] = hue2rgb(p, q, hk + 1 / 3); o[1] = hue2rgb(p, q, hk); o[2] = hue2rgb(p, q, hk - 1 / 3);
  }

  /* ---------- histogram ---------- */
  function histogram(rgba) {
    var hr = new Uint32Array(256), hg = new Uint32Array(256), hb = new Uint32Array(256), hl = new Uint32Array(256);
    for (var j = 0; j < rgba.length; j += 4) {
      if (rgba[j + 3] === 0) continue;
      hr[rgba[j]]++; hg[rgba[j + 1]]++; hb[rgba[j + 2]]++;
      hl[(0.2126 * rgba[j] + 0.7152 * rgba[j + 1] + 0.0722 * rgba[j + 2] + 0.5) | 0]++;
    }
    return { r: hr, g: hg, b: hb, l: hl };
  }

  /* ---------- auto tone ---------- */
  function autoParams(src) {
    var hist = histogram(src.data).l, total = 0, i;
    for (i = 0; i < 256; i++) total += hist[i];
    if (!total) return {};
    function pct(q) { var acc = 0, target = total * q; for (var k = 0; k < 256; k++) { acc += hist[k]; if (acc >= target) return k / 255; } return 1; }
    var lo = pct(0.005), hi = Math.max(pct(0.995), lo + 0.1), med = Math.max(pct(0.5), 0.02);
    // exposure: centre the median, but never push the bright end into clipping
    var evMed = GAMMA * Math.log(0.45 / med) / Math.LN2, evHi = GAMMA * Math.log(0.96 / hi) / Math.LN2, ev;
    if (evMed > 0) ev = Math.max(0, Math.min(evMed, evHi)); else ev = evMed * 0.6;
    ev = Math.max(-2, Math.min(3, ev * 0.85)); if (Math.abs(ev) < 0.1) ev = 0;
    var k = Math.pow(2, ev / GAMMA), res = { exposure: Math.round(ev * 100) / 100 };
    res.blacks = Math.round(Math.max(-60, Math.min(30, -(lo * k) * 500)));
    var medK = med * k;
    res.shadows = medK < 0.35 ? Math.round(Math.min(45, (0.35 - medK) * 140)) : 0;
    res.highlights = medK > 0.62 ? -Math.round(Math.min(45, (medK - 0.62) * 160)) : 0;
    if (hi * k > 1.02) res.highlights = Math.min(res.highlights, -20);
    res.contrast = 8; res.vibrance = 8;
    return res;
  }

  /* ---------- presets (partial parameter sets) ---------- */
  function hueArr(map) { var a = zeros(8); for (var k in map) a[Number(k)] = map[k]; return a; }
  var PRESETS = [
    { id: 'none', name: 'بدون', params: {} },
    { id: 'vivid', name: 'حيوي', params: { contrast: 20, vibrance: 35, saturation: 8, clarity: 15 } },
    { id: 'matte', name: 'ماتي', params: { blacks: 55, contrast: -12, saturation: -10, highlights: -18 } },
    { id: 'warm', name: 'دافئ', params: { temp: 30, tint: 5, vibrance: 15, shadows: 10 } },
    { id: 'cool', name: 'بارد', params: { temp: -30, tint: -3, contrast: 8 } },
    { id: 'cinema', name: 'سينمائي', params: { contrast: 22, highlights: -25, shadows: 15, saturation: -8, clarity: 10, vignette: -25, sat: hueArr({ 1: 25, 5: -10 }) } },
    { id: 'bw', name: 'أبيض وأسود', params: { bw: true, contrast: 20, clarity: 15 } },
    { id: 'bwhigh', name: 'أبيض وأسود عالي التباين', params: { bw: true, contrast: 45, blacks: -25, whites: 15, clarity: 25 } },
    { id: 'dehaze', name: 'إزالة الضباب', params: { dehaze: 40, contrast: 10, vibrance: 10 } },
    { id: 'soft', name: 'بورتريه ناعم', params: { clarity: -25, texture: -20, highlights: -15, vibrance: 8, nrLum: 20 } },
    { id: 'crisp', name: 'حدّة وتفاصيل', params: { texture: 35, clarity: 20, sharpen: 60 } }
  ];

  global.ABSCameraRaw = {
    defaults: defaults, normalize: normalize, isNeutral: isNeutral, createContext: createContext,
    process: process, histogram: histogram, autoParams: autoParams, presets: PRESETS,
    bandCenters: BAND_CENTERS, _gaussBlur: gaussBlur
  };
}(typeof window !== 'undefined' ? window : this));
