/* Artboard Studio updater.
   1) Reads version.json from the product website and shows a banner when a newer version exists.
   2) "Update now" downloads the signed update package, verifies it (SHA-256 + ECDSA P-256 signature made with the
      developer's private key, version consistency, safe file names) and installs it over this extension folder,
      keeping an in-memory backup so any failure rolls back to the previous files.
   If anything is missing (public key, file access, package) the banner falls back to a manual download link. */
(function () {
  'use strict';
  var CFG = window.ARTBOARD_STUDIO_UPDATE || {};
  var VERSION_URL = CFG.versionUrl || 'https://rafathamed.github.io/ArtboardStudio/version.json';
  var ALLOWED_PREFIX = CFG.allowedPrefix || 'https://rafathamed.github.io/ArtboardStudio/';
  var MAX_ZIP = CFG.maxZipBytes || 8 * 1024 * 1024;
  var PUBLIC_KEY = CFG.publicKey || null;
  var MAX_ENTRIES = 400, MAX_FILE = 4 * 1024 * 1024;
  var DISMISS_KEY = 'artboardStudio.updateDismissed.v1';
  var AUTO_KEY = 'artboardStudio.autoUpdate.v1';
  var FAILED_KEY = 'artboardStudio.autoFailed.v1';
  var current = String(window.ARTBOARD_STUDIO_VERSION || '0.0.0');
  var year = String(window.ARTBOARD_STUDIO_YEAR || '');
  var checked = false, running = false;
  var $ = function (id) { return document.getElementById(id); };

  /* ---------------- small helpers ---------------- */
  function parts(v) { var p = String(v || '').replace(/^v/i, '').split('.'), o = []; for (var i = 0; i < 3; i++) o.push(parseInt(p[i], 10) || 0); return o; }
  function compare(a, b) { var x = parts(a), y = parts(b); for (var i = 0; i < 3; i++) { if (x[i] > y[i]) return 1; if (x[i] < y[i]) return -1; } return 0; }
  function isMac() { return /Mac/i.test(navigator.platform || navigator.userAgent || ''); }
  function safeUrl(u) { return typeof u === 'string' && /^https:\/\/[^\s]+$/i.test(u) ? u : ''; }
  function openUrl(url) {
    try { if (window.cep && window.cep.util && typeof window.cep.util.openURLInDefaultBrowser === 'function') { window.cep.util.openURLInDefaultBrowser(url); return; } } catch (e) {}
    window.open(url, '_blank');
  }
  function store(key, val) { try { if (val === null) localStorage.removeItem(key); else localStorage.setItem(key, val); } catch (e) {} }
  function load(key) { try { return localStorage.getItem(key); } catch (e) { return null; } }

  var CRC_TABLE = (function () { var t = new Uint32Array(256); for (var n = 0; n < 256; n++) { var c = n; for (var k = 0; k < 8; k++) c = c & 1 ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1); t[n] = c >>> 0; } return t; }());
  function crc32(u8) { var c = 0xFFFFFFFF; for (var i = 0; i < u8.length; i++) c = CRC_TABLE[(c ^ u8[i]) & 0xFF] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
  function bytesToB64(u8) { var s = '', CH = 0x8000; for (var i = 0; i < u8.length; i += CH) s += String.fromCharCode.apply(null, u8.subarray(i, i + CH)); return btoa(s); }
  function b64ToBytes(b64) { var s = atob(b64), u = new Uint8Array(s.length); for (var i = 0; i < s.length; i++) u[i] = s.charCodeAt(i); return u; }
  function toHex(buf) { var u = new Uint8Array(buf), s = ''; for (var i = 0; i < u.length; i++) s += (u[i] < 16 ? '0' : '') + u[i].toString(16); return s; }
  function utf8(u8) { try { return decodeURIComponent(escape(String.fromCharCode.apply(null, u8))); } catch (e) { throw new Error('اسم ملف غير صالح داخل الحزمة.'); } }

  /* ---------------- ZIP (stored entries only) ---------------- */
  function parseZip(buf) {
    var dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength), i, min = Math.max(0, buf.length - 22 - 65535);
    for (i = buf.length - 22; i >= min; i--) if (dv.getUint32(i, true) === 0x06054b50) break;
    if (i < min) throw new Error('الحزمة ليست ملف ZIP صالحًا.');
    var total = dv.getUint16(i + 10, true), cdOff = dv.getUint32(i + 16, true);
    if (total > MAX_ENTRIES) throw new Error('عدد الملفات في الحزمة كبير جدًا.');
    var p = cdOff, out = [];
    for (var n = 0; n < total; n++) {
      if (p + 46 > buf.length || dv.getUint32(p, true) !== 0x02014b50) throw new Error('فهرس الحزمة تالف.');
      var flags = dv.getUint16(p + 8, true), method = dv.getUint16(p + 10, true), crc = dv.getUint32(p + 16, true);
      var csize = dv.getUint32(p + 20, true), usize = dv.getUint32(p + 24, true);
      var nlen = dv.getUint16(p + 28, true), elen = dv.getUint16(p + 30, true), clen = dv.getUint16(p + 32, true), lho = dv.getUint32(p + 42, true);
      var name = utf8(buf.subarray(p + 46, p + 46 + nlen)); p += 46 + nlen + elen + clen;
      if (name.charAt(name.length - 1) === '/') continue;
      if (flags & 1) throw new Error('الحزمة مشفّرة.');
      if (method !== 0 || csize !== usize) throw new Error('صيغة الحزمة غير مدعومة (يجب أن تكون بدون ضغط).');
      if (usize > MAX_FILE) throw new Error('ملف كبير جدًا داخل الحزمة: ' + name);
      if (lho + 30 > buf.length || dv.getUint32(lho, true) !== 0x04034b50) throw new Error('رأس ملف تالف: ' + name);
      var start = lho + 30 + dv.getUint16(lho + 26, true) + dv.getUint16(lho + 28, true);
      if (start + usize > buf.length) throw new Error('ملف مقطوع: ' + name);
      var data = buf.subarray(start, start + usize);
      if (crc32(data) !== crc) throw new Error('فشل فحص سلامة الملف: ' + name);
      out.push({ name: name, data: data, crc: crc });
    }
    return out;
  }

  var NAME_RE = /^[A-Za-z0-9_][A-Za-z0-9_\-.]*(\/[A-Za-z0-9_][A-Za-z0-9_\-.]*)*$/;
  var EXT_RE = /\.(js|jsx|html|css|xml|json|png|svg|ico|txt|md)$/i;
  function checkNames(entries) {
    var seen = {};
    for (var i = 0; i < entries.length; i++) {
      var nm = entries[i].name;
      if (!NAME_RE.test(nm) || !EXT_RE.test(nm)) throw new Error('الحزمة تحتوي ملفًا غير مسموح: ' + nm);
      if (seen[nm.toLowerCase()]) throw new Error('الحزمة تحتوي اسمًا مكررًا: ' + nm);
      seen[nm.toLowerCase()] = 1;
    }
  }

  /* ---------------- crypto ---------------- */
  function subtle() { return window.crypto && window.crypto.subtle ? window.crypto.subtle : null; }
  function sha256Hex(u8) { return subtle().digest('SHA-256', u8).then(toHex); }
  function verifySignature(u8, sigB64) {
    var sig = b64ToBytes(sigB64);
    if (sig.length !== 64) return Promise.reject(new Error('صيغة التوقيع غير صالحة.'));
    return subtle().importKey('jwk', PUBLIC_KEY, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']).then(function (key) {
      return subtle().verify({ name: 'ECDSA', hash: { name: 'SHA-256' } }, key, sig, u8);
    });
  }

  /* ---------------- file system (CEP) ---------------- */
  function fs() { return window.cep && window.cep.fs && window.cep.encoding ? window.cep.fs : null; }
  function extDir() {
    var h = decodeURIComponent(String(location.href).split('#')[0].split('?')[0]);
    if (h.indexOf('file://') !== 0) return '';
    h = h.replace(/^file:\/\/\/?/, '');
    if (!/^[A-Za-z]:/.test(h)) h = '/' + h.replace(/^\/+/, '');
    return h.replace(/\/[^\/]*$/, '');
  }
  function ensureDir(path) {
    var F = fs(), st = F.stat(path);
    if (st && st.err === 0 && st.data && st.data.isDirectory && st.data.isDirectory()) return;
    var parent = path.replace(/\/[^\/]+$/, '');
    if (parent && parent !== path && parent.length > 2) ensureDir(parent);
    var r = F.makedir(path);
    if (!r || r.err !== 0) { st = F.stat(path); if (!(st && st.err === 0 && st.data && st.data.isDirectory && st.data.isDirectory())) throw new Error('تعذّر إنشاء المجلد: ' + path); }
  }

  function installFiles(files, base, version) {
    var F = fs(), B64 = window.cep.encoding.Base64, backups = [], i, f;
    var order = files.slice().sort(function (a, b) { // critical entry files last
      function w(n) { return n === 'CSXS/manifest.xml' ? 2 : (n === 'index.html' ? 1 : 0); }
      return w(a.name) - w(b.name);
    });
    try {
      for (i = 0; i < order.length; i++) {
        f = order[i]; var dest = base + '/' + f.name;
        ensureDir(dest.replace(/\/[^\/]+$/, ''));
        var old = F.readFile(dest, B64);
        backups.push({ dest: dest, old: old && old.err === 0 ? old.data : null });
        var wr = F.writeFile(dest, bytesToB64(f.data), B64);
        if (!wr || wr.err !== 0) throw new Error('تعذّرت كتابة الملف: ' + f.name + ' (رمز ' + (wr && wr.err) + '). قد تحتاج صلاحيات أو أن الملف قيد الاستخدام.');
        var rb = F.readFile(dest, B64);
        if (!rb || rb.err !== 0 || crc32(b64ToBytes(rb.data)) !== f.crc) throw new Error('فشل التحقق بعد الكتابة: ' + f.name);
      }
    } catch (e) {
      var failed = 0;
      for (var k = backups.length - 1; k >= 0; k--) {
        var b = backups[k], r2;
        if (b.old !== null) r2 = F.writeFile(b.dest, b.old, B64); else r2 = F.deleteFile(b.dest);
        if (!r2 || r2.err !== 0) failed++;
      }
      throw new Error(e.message + (failed ? ' — تعذّر استرجاع ' + failed + ' ملف، أعد التثبيت يدويًا.' : ' — تم الرجوع إلى النسخة السابقة.'));
    }
  }

  /* ---------------- download + full update pipeline ---------------- */
  function download(url, onProgress) {
    return new Promise(function (resolve, reject) {
      var x = new XMLHttpRequest(); x.open('GET', url + (url.indexOf('?') < 0 ? '?_=' : '&_=') + new Date().getTime(), true);
      x.responseType = 'arraybuffer'; x.timeout = 60000;
      x.onprogress = function (e) { if (e.lengthComputable && onProgress) onProgress(Math.round(e.loaded / e.total * 100)); };
      x.onload = function () {
        if (x.status < 200 || x.status >= 300) return reject(new Error('تعذّر تنزيل الحزمة (HTTP ' + x.status + ').'));
        var u = new Uint8Array(x.response); if (u.length > MAX_ZIP) return reject(new Error('حجم الحزمة أكبر من المسموح.')); resolve(u);
      };
      x.onerror = function () { reject(new Error('تعذّر الاتصال بالإنترنت لتنزيل التحديث.')); };
      x.ontimeout = function () { reject(new Error('انتهت مهلة تنزيل التحديث.')); };
      x.send(null);
    });
  }

  function autoPossible(info) {
    var pk = info && info.package;
    return !!(pk && PUBLIC_KEY && subtle() && fs() && extDir() && year && typeof pk.url === 'string' && pk.url.indexOf(ALLOWED_PREFIX) === 0 &&
      /^[0-9a-f]{64}$/i.test(pk.sha256 || '') && typeof pk.signature === 'string' && pk.signature.length > 60 && (!pk.size || pk.size <= MAX_ZIP));
  }

  function runUpdate(info, ui) {
    if (running) return Promise.reject(new Error('هناك تحديث قيد التنفيذ.'));
    if (!autoPossible(info)) return Promise.reject(new Error('التحديث التلقائي غير متاح لهذا الإصدار.'));
    running = true;
    var pk = info.package, zip, entries, base = extDir();
    ui('download', 0);
    return download(pk.url, function (pct) { ui('download', pct); }).then(function (u8) {
      zip = u8;
      if (pk.size && zip.length !== pk.size) throw new Error('حجم الحزمة لا يطابق المعلن.');
      ui('verify');
      return sha256Hex(zip);
    }).then(function (hex) {
      if (hex.toLowerCase() !== pk.sha256.toLowerCase()) throw new Error('بصمة الحزمة (SHA-256) لا تطابق. أُلغي التحديث.');
      return verifySignature(zip, pk.signature);
    }).then(function (valid) {
      if (!valid) throw new Error('التوقيع الرقمي غير صالح. أُلغي التحديث لحمايتك.');
      entries = parseZip(zip); checkNames(entries);
      var infoFile = null, i;
      for (i = 0; i < entries.length; i++) if (entries[i].name === 'package-info.json') infoFile = entries[i];
      if (!infoFile) throw new Error('الحزمة ينقصها package-info.json.');
      var meta; try { meta = JSON.parse(utf8(infoFile.data)); } catch (e) { throw new Error('package-info.json تالف.'); }
      if (meta.name !== 'artboard-studio') throw new Error('الحزمة ليست لهذه الإضافة.');
      if (meta.version !== info.version) throw new Error('إصدار الحزمة (' + meta.version + ') لا يطابق المعلن (' + info.version + ').');
      if (compare(meta.version, current) <= 0) throw new Error('الحزمة ليست أحدث من الإصدار الحالي.');
      var prefix = 'ArtboardStudio_' + year + '/', files = [];
      for (i = 0; i < entries.length; i++) if (entries[i].name.indexOf(prefix) === 0) files.push({ name: entries[i].name.substring(prefix.length), data: entries[i].data, crc: entries[i].crc });
      if (!files.length) throw new Error('الحزمة لا تحتوي إصدار Illustrator ' + year + '.');
      var names = {}; files.forEach(function (f) { names[f.name] = f; });
      ['CSXS/manifest.xml', 'index.html', 'version.js'].forEach(function (req) { if (!names[req]) throw new Error('الحزمة ناقصة: ' + req); });
      var vtxt = utf8(names['version.js'].data), m = /ARTBOARD_STUDIO_VERSION\s*=\s*'([^']+)'/.exec(vtxt);
      if (!m || m[1] !== meta.version) throw new Error('ملف version.js داخل الحزمة لا يطابق رقم الإصدار.');
      if (utf8(names['CSXS/manifest.xml'].data).indexOf('ExtensionBundleVersion="' + meta.version + '"') < 0) throw new Error('manifest.xml داخل الحزمة لا يطابق رقم الإصدار.');
      ui('install');
      installFiles(files, base, meta.version);
      running = false; return meta.version;
    }).then(function (v) { ui('done', v); try { if (window.ABSRestart) window.ABSRestart.mark(v); } catch (e) {} return v; }, function (err) { running = false; throw err; });
  }

  /* ---------------- banner ---------------- */
  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text) e.textContent = text; return e; }

  function showBanner(info, required) {
    if ($('updateBanner')) return;
    var shell = $('appRoot'); if (!shell) return;
    var host = shell.querySelector('.host-line');
    var box = el('div', 'update-banner' + (required ? ' required' : '')); box.id = 'updateBanner'; box.setAttribute('role', 'status');
    var text = el('div', 'update-text'), title = el('b', '', (required ? 'تحديث مطلوب: ' : 'يتوفر تحديث جديد ') + info.version); text.appendChild(title);
    var note = info.notes && info.notes.length ? String(info.notes[0]) : (typeof info.notes === 'string' ? info.notes : '');
    var small = el('small', '', note.slice(0, 140)); if (note) text.appendChild(small);
    var bar = el('div', 'update-progress'); bar.appendChild(el('i')); bar.style.display = 'none'; text.appendChild(bar);
    var actions = el('div', 'update-actions');
    var url = safeUrl(isMac() ? (info.downloadUrlMac || info.downloadUrl) : (info.downloadUrlWin || info.downloadUrl));
    var canAuto = autoPossible(info);
    var autoBtn = null, manual = el('button', 'update-btn secondary', 'تنزيل يدوي'); manual.type = 'button';
    manual.addEventListener('click', function () { if (url) openUrl(url); });

    function setState(kind, arg) {
      var msg = '';
      if (kind === 'download') { bar.style.display = 'block'; bar.firstChild.style.width = (arg || 0) + '%'; msg = 'جارٍ التنزيل… ' + (arg || 0) + '%'; }
      else if (kind === 'verify') { bar.firstChild.style.width = '100%'; msg = 'جارٍ التحقق من التوقيع الرقمي…'; }
      else if (kind === 'install') { msg = 'جارٍ التثبيت…'; }
      else if (kind === 'done') {
        box.classList.add('done'); box.classList.remove('required'); bar.style.display = 'none'; title.textContent = 'تم التحديث إلى ' + arg;
        small.textContent = 'أعد تحميل اللوحة لتفعيل الإصدار الجديد، وأعد تشغيل Illustrator إن بقي شيء قديمًا.'; if (!small.parentNode) text.insertBefore(small, bar);
        actions.innerHTML = ''; var rl = el('button', 'update-btn', 'إعادة تحميل اللوحة'); rl.type = 'button'; rl.addEventListener('click', function () { window.location.reload(); }); actions.appendChild(rl); return;
      } else if (kind === 'error') {
        bar.style.display = 'none'; box.classList.add('failed'); small.textContent = arg; if (!small.parentNode) text.insertBefore(small, bar); small.style.whiteSpace = 'normal';
        if (autoBtn) { autoBtn.disabled = false; autoBtn.textContent = 'إعادة المحاولة'; } return;
      }
      small.textContent = msg; if (!small.parentNode) text.insertBefore(small, bar); if (autoBtn) autoBtn.disabled = true;
    }
    function start(auto) {
      box.classList.remove('failed');
      runUpdate(info, setState).catch(function (e) { if (auto) store(FAILED_KEY, info.version); setState('error', e && e.message ? e.message : String(e)); });
    }
    if (canAuto) {
      autoBtn = el('button', 'update-btn', 'تحديث الآن'); autoBtn.type = 'button';
      autoBtn.addEventListener('click', function () {
        ABSDialog.confirm('سيتم تنزيل التحديث ' + info.version + ' والتحقق من توقيعه الرقمي ثم تثبيته فوق النسخة الحالية. بعد الانتهاء ستحتاج إلى إغلاق Illustrator وفتحه مرة أخرى. هل تريد المتابعة؟', function () { start(false); }, { title: 'تحديث الإضافة', ok: 'تحديث الآن' });
      });
      actions.appendChild(autoBtn);
    }
    actions.appendChild(manual);
    box.appendChild(text); box.appendChild(actions);
    if (canAuto) {
      var lab = el('label', 'update-auto'), cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = load(AUTO_KEY) === '1';
      cb.addEventListener('change', function () { store(AUTO_KEY, cb.checked ? '1' : null); if (cb.checked && !running && load(FAILED_KEY) !== info.version) start(true); });
      lab.appendChild(cb); lab.appendChild(document.createTextNode(' حدّث تلقائيًا في المرات القادمة')); box.appendChild(lab);
    }
    if (!required) {
      var close = el('button', 'update-close', '×'); close.type = 'button'; close.setAttribute('aria-label', 'لاحقًا');
      close.addEventListener('click', function () { store(DISMISS_KEY, info.version); if (box.parentNode) box.parentNode.removeChild(box); }); box.appendChild(close);
    }
    if (host && host.parentNode) host.parentNode.insertBefore(box, host); else shell.insertBefore(box, shell.firstChild);
    if (canAuto && load(AUTO_KEY) === '1' && load(FAILED_KEY) !== info.version) start(true);
  }

  function check() {
    if (checked) return; checked = true;
    var xhr = new XMLHttpRequest();
    xhr.open('GET', VERSION_URL + '?_=' + new Date().getTime(), true); xhr.timeout = 8000;
    xhr.onreadystatechange = function () {
      if (xhr.readyState !== 4 || xhr.status < 200 || xhr.status >= 300) return;
      var info; try { info = JSON.parse(xhr.responseText); } catch (e) { return; }
      if (!info || typeof info.version !== 'string' || !/^v?\d+\.\d+\.\d+$/.test(info.version)) return;
      if (compare(info.version, current) <= 0) return;
      var required = typeof info.minVersion === 'string' && compare(current, info.minVersion) < 0;
      if (!required && load(DISMISS_KEY) === info.version && load(AUTO_KEY) !== '1') return;
      showBanner(info, required);
    };
    try { xhr.send(null); } catch (e) {}
  }

  var tries = 0, timer = window.setInterval(function () {
    tries++;
    if (window.ArtboardStudioLicensed) { window.clearInterval(timer); window.setTimeout(check, 1500); }
    else if (tries > 240) window.clearInterval(timer);
  }, 500);

  window.ABSUpdater = { compare: compare, parseZip: parseZip, checkNames: checkNames, runUpdate: runUpdate, autoPossible: autoPossible, _extDir: extDir };
}());
