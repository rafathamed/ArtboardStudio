/* Artboard Studio host bridge for Adobe Illustrator (ExtendScript / ES3). */
#target illustrator

if (typeof AIArtboardStudio === 'undefined') {
    var AIArtboardStudio = {};
}

AIArtboardStudio._result = function (ok, message) {
    var s = String(message || '').replace(/[\r\n]+/g, ' ');
    return (ok ? 'OK|' : 'ERR|') + s;
};

AIArtboardStudio._doc = function () {
    if (app.documents.length < 1) throw new Error('افتح مستندًا في Illustrator أولًا.');
    return app.activeDocument;
};

AIArtboardStudio._artboard = function (doc) {
    var index = doc.artboards.getActiveArtboardIndex();
    return doc.artboards[index].artboardRect;
};

AIArtboardStudio._directItems = function (layer) {
    var out = [];
    var items = layer.pageItems;
    for (var i = 0; i < items.length; i++) {
        var item = items[i];
        try {
            if (item.parent == layer && !item.guides) out.push(item);
        } catch (e) {}
    }
    return out;
};

AIArtboardStudio._collectLayers = function (layers, out) {
    for (var i = 0; i < layers.length; i++) {
        var layer = layers[i];
        out.push(layer);
        if (layer.layers && layer.layers.length) AIArtboardStudio._collectLayers(layer.layers, out);
    }
};

AIArtboardStudio._layerFromItem = function (item) {
    var current = item;
    while (current) {
        try {
            if (current.typename == 'Layer') return current;
            current = current.parent;
        } catch (e) { break; }
    }
    return null;
};

AIArtboardStudio._pushUniqueLayer = function (list, layer) {
    if (!layer || layer.typename != 'Layer') return;
    for (var i = 0; i < list.length; i++) if (list[i] == layer) return;
    list.push(layer);
};

/* scope='all': every document layer (including nested layers).
   scope='selected': the active layer plus layers containing selected artwork. */
AIArtboardStudio._targetLayers = function (doc, scope) {
    var all = [];
    AIArtboardStudio._collectLayers(doc.layers, all);
    scope = String(scope || 'all').toLowerCase();
    if (scope != 'selected') return all;

    var targets = [], foundSelectedArtwork = false;
    try {
        var selection = doc.selection;
        if (selection && typeof selection.length == 'number') {
            for (var i = 0; i < selection.length; i++) {
                var ownerLayer = AIArtboardStudio._layerFromItem(selection[i]);
                if (ownerLayer) {
                    AIArtboardStudio._pushUniqueLayer(targets, ownerLayer);
                    foundSelectedArtwork = true;
                }
            }
        }
    } catch (selectionError) {}

    /* If no artwork is selected, use the layer currently active in Illustrator. */
    if (!foundSelectedArtwork) {
        try { AIArtboardStudio._pushUniqueLayer(targets, doc.activeLayer); } catch (activeError) {}
    }

    if (!targets.length) throw new Error('لم يتم العثور على طبقة مستهدفة. حدد عناصر داخل الطبقات المطلوبة أو اختر الطبقة النشطة من لوحة Layers.');
    return targets;
};

/* Normalize a selected Illustrator object to the nearest editable object
   whose parent is a Layer or GroupItem. This keeps compound paths/text selections
   as one logical artwork item instead of targeting an internal sub-part. */
AIArtboardStudio._normalizeSelectedElement = function (item) {
    var current = item, guard = 0;
    while (current && guard++ < 60) {
        var parent = null;
        try { parent = current.parent; } catch (e) { return null; }
        if (!parent) return null;
        if (parent.typename == 'Layer' || parent.typename == 'GroupItem') return current;
        if (parent.typename == 'Document') return null;
        current = parent;
    }
    return null;
};

AIArtboardStudio._isDescendantOf = function (item, ancestor) {
    var current = null, guard = 0;
    try { current = item.parent; } catch (e) { return false; }
    while (current && guard++ < 60) {
        if (current == ancestor) return true;
        if (current.typename == 'Document' || current.typename == 'Layer') return false;
        try { current = current.parent; } catch (e2) { return false; }
    }
    return false;
};

AIArtboardStudio._addBatch = function (batches, parent, layer, item) {
    var batch = null;
    for (var i = 0; i < batches.length; i++) {
        if (batches[i].parent == parent) { batch = batches[i]; break; }
    }
    if (!batch) {
        batch = { parent: parent, layer: layer, items: [] };
        batches.push(batch);
    }
    for (var j = 0; j < batch.items.length; j++) if (batch.items[j] == item) return;
    batch.items.push(item);
};

/* scope='all': all top-level artwork objects in every document layer (nested
   groups remain intact as one object). scope='selected': only actual objects in
   doc.selection; no fallback to the active layer. Batches are split by parent
   container because Illustrator cannot safely group objects across containers. */
AIArtboardStudio._elementBatches = function (doc, scope, includeHidden) {
    var batches = [];
    scope = String(scope || 'all').toLowerCase();
    if (scope != 'selected') {
        var allLayers = [];
        AIArtboardStudio._collectLayers(doc.layers, allLayers);
        for (var i = 0; i < allLayers.length; i++) {
            var layer = allLayers[i];
            var items = AIArtboardStudio._directItems(layer);
            if (!includeHidden) {
                var visibleItems = [];
                for (var vi = 0; vi < items.length; vi++) {
                    var hiddenOrLocked = false;
                    try { if (items[vi].hidden || items[vi].locked) hiddenOrLocked = true; } catch (visibilityError) {}
                    if (!hiddenOrLocked) visibleItems.push(items[vi]);
                }
                items = visibleItems;
            }
            if (items.length) batches.push({ parent: layer, layer: layer, items: items });
        }
        return batches;
    }

    var selection = null, selected = [];
    try { selection = doc.selection; } catch (selectionError) {}
    if (selection && selection.typename == 'TextRange') {
        /* Illustrator can return a TextRange instead of an array when text is active. */
        var textFrame = null;
        try { textFrame = selection.parent; } catch (textParentError) {}
        var textElement = textFrame ? AIArtboardStudio._normalizeSelectedElement(textFrame) : null;
        if (textElement) selected.push(textElement);
    } else if (selection && typeof selection.length == 'number') {
        for (var s = 0; s < selection.length; s++) {
            var normalized = AIArtboardStudio._normalizeSelectedElement(selection[s]);
            if (!normalized) continue;
            var duplicate = false;
            for (var d = 0; d < selected.length; d++) if (selected[d] == normalized) { duplicate = true; break; }
            if (!duplicate) selected.push(normalized);
        }
    } else if (selection && selection.typename) {
        var single = AIArtboardStudio._normalizeSelectedElement(selection);
        if (single) selected.push(single);
    }
    if (!selected.length) throw new Error('حدد عنصرًا واحدًا أو أكثر داخل مساحة العمل أولًا، ثم اختر «العناصر المحددة فقط».');

    /* If a selected group contains another selected object, process the group only. */
    var filtered = [];
    for (var a = 0; a < selected.length; a++) {
        var covered = false;
        for (var b = 0; b < selected.length; b++) {
            if (a != b && AIArtboardStudio._isDescendantOf(selected[a], selected[b])) { covered = true; break; }
        }
        if (!covered) filtered.push(selected[a]);
    }

    for (var k = 0; k < filtered.length; k++) {
        var element = filtered[k], parent = null, ownerLayer = null;
        try { parent = element.parent; } catch (parentError) {}
        ownerLayer = AIArtboardStudio._layerFromItem(element);
        if (!parent || !ownerLayer || (parent.typename != 'Layer' && parent.typename != 'GroupItem')) continue;
        AIArtboardStudio._addBatch(batches, parent, ownerLayer, element);
    }
    if (!batches.length) throw new Error('تعذّر تحديد عناصر قابلة للمعالجة. اختر عناصر رسومية مباشرة داخل لوحة الرسم.');
    return batches;
};

AIArtboardStudio._unlockBatchObjects = function (batch) {
    var refs = [], states = [];
    function add(ref) {
        if (!ref) return;
        for (var x = 0; x < refs.length; x++) if (refs[x] == ref) return;
        refs.push(ref);
    }
    add(batch.parent);
    for (var i = 0; i < batch.items.length; i++) add(batch.items[i]);
    for (var j = 0; j < refs.length; j++) {
        var ref = refs[j], state = { ref: ref, locked: null, hidden: null };
        try { if (typeof ref.locked == 'boolean') { state.locked = ref.locked; ref.locked = false; } } catch (lockError) {}
        try { if (typeof ref.hidden == 'boolean') { state.hidden = ref.hidden; ref.hidden = false; } } catch (hiddenError) {}
        states.push(state);
    }
    return states;
};

AIArtboardStudio._restoreBatchObjects = function (states) {
    for (var i = states.length - 1; i >= 0; i--) {
        var state = states[i];
        try { if (state.locked !== null) state.ref.locked = state.locked; } catch (lockError) {}
        try { if (state.hidden !== null) state.ref.hidden = state.hidden; } catch (hiddenError) {}
    }
};

AIArtboardStudio._shouldSkipLayer = function (layer, includeHidden) {
    if (includeHidden) return false;
    var current = layer;
    while (current && current.typename == 'Layer') {
        try { if (!current.visible || current.locked) return true; } catch (e) { return true; }
        current = current.parent;
    }
    return false;
};

AIArtboardStudio._openLayerChain = function (layer) {
    var chain = [], current = layer;
    while (current && current.typename == 'Layer') {
        chain.push({ ref: current, visible: current.visible, locked: current.locked });
        current.visible = true;
        current.locked = false;
        current = current.parent;
    }
    return chain;
};

AIArtboardStudio._restoreLayerChain = function (chain) {
    for (var i = chain.length - 1; i >= 0; i--) {
        try { chain[i].ref.visible = chain[i].visible; } catch (e) {}
        try { chain[i].ref.locked = chain[i].locked; } catch (e2) {}
    }
};

AIArtboardStudio.getDocumentInfo = function () {
    try {
        var doc = AIArtboardStudio._doc();
        var r = AIArtboardStudio._artboard(doc);
        var layers = [];
        AIArtboardStudio._collectLayers(doc.layers, layers);
        return AIArtboardStudio._result(true, 'المستند: ' + doc.name + ' — لوحات الرسم: ' + doc.artboards.length + ' — الطبقات: ' + layers.length + ' — لوحة الرسم النشطة: ' + (r[2] - r[0]).toFixed(1) + ' × ' + (r[1] - r[3]).toFixed(1) + ' pt');
    } catch (e) {
        return AIArtboardStudio._result(false, e.message || e);
    }
};

AIArtboardStudio._hexColor = function (hex, doc) {
    var value = String(hex || '#919BAA').replace('#', '');
    if (!/^[0-9a-fA-F]{6}$/.test(value)) throw new Error('لون HEX غير صالح.');
    var rr = parseInt(value.substr(0, 2), 16), gg = parseInt(value.substr(2, 2), 16), bb = parseInt(value.substr(4, 2), 16);
    if (doc.documentColorSpace == DocumentColorSpace.CMYK) {
        var rgb = new RGBColor(); rgb.red = rr; rgb.green = gg; rgb.blue = bb;
        return rgb;
    }
    var color = new RGBColor(); color.red = rr; color.green = gg; color.blue = bb; return color;
};

AIArtboardStudio.addArtboardShape = function (strokeWidth, hexColor, style) {
    var layer = null, relock = false, rehide = false;
    try {
        var doc = AIArtboardStudio._doc();
        var r = AIArtboardStudio._artboard(doc);
        var left = r[0], top = r[1], width = r[2] - r[0], height = r[1] - r[3];
        // Draw on the layer that is already active - never create a new layer.
        layer = doc.activeLayer;
        try { if (layer.locked) { layer.locked = false; relock = true; } } catch (e1) {}
        try { if (!layer.visible) { layer.visible = true; rehide = true; } } catch (e2) {}
        var rect = layer.pathItems.rectangle(top, left, width, height);
        rect.name = 'Artboard Size';
        var color = AIArtboardStudio._hexColor(hexColor, doc);
        style = String(style || 'fill');
        var sw = Number(strokeWidth); if (!(sw >= 0)) sw = 0;
        rect.filled = (style == 'fill' || style == 'both');
        rect.stroked = ((style == 'stroke' || style == 'both') && sw > 0);
        if (rect.filled) rect.fillColor = color;
        if (rect.stroked) { rect.strokeColor = color; rect.strokeWidth = sw; }
        doc.selection = null;
        rect.selected = true;
        try { if (relock) layer.locked = true; } catch (e3) {}
        try { if (rehide) layer.visible = false; } catch (e4) {}
        return AIArtboardStudio._result(true, 'تم إنشاء مستطيل مطابق لمقاس لوحة الرسم داخل اللير الحالي (' + layer.name + ').');
    } catch (e) {
        try { if (layer && relock) layer.locked = true; } catch (e5) {}
        return AIArtboardStudio._result(false, e.message || e);
    }
};

AIArtboardStudio.maskAllLayers = function (includeHidden, scope) {
    var doc, originalLayer, batches, processed = 0, elementCount = 0, skipped = 0, errors = [];
    try {
        doc = AIArtboardStudio._doc();
        originalLayer = doc.activeLayer;
        var r = AIArtboardStudio._artboard(doc);
        var left = r[0], top = r[1], width = r[2] - r[0], height = r[1] - r[3];
        batches = AIArtboardStudio._elementBatches(doc, scope, includeHidden);

        for (var i = 0; i < batches.length; i++) {
            var batch = batches[i], layer = batch.layer;
            if (AIArtboardStudio._shouldSkipLayer(layer, includeHidden)) { skipped += batch.items.length; continue; }
            var layerChain = AIArtboardStudio._openLayerChain(layer);
            var objectStates = AIArtboardStudio._unlockBatchObjects(batch);
            var group = null, moved = [];
            try {
                doc.activeLayer = layer;
                group = batch.parent.groupItems.add();
                group.name = 'Artboard Mask — ' + (scope == 'selected' ? 'Selected Elements' : 'Document Elements');
                for (var j = 0; j < batch.items.length; j++) {
                    batch.items[j].move(group, ElementPlacement.PLACEATEND);
                    moved.push(batch.items[j]);
                }
                var clip = group.pathItems.rectangle(top, left, width, height);
                clip.name = 'Artboard Clipping Path';
                clip.stroked = false;
                clip.filled = false;
                clip.clipping = true;
                try { clip.zOrder(ZOrderMethod.BRINGTOFRONT); } catch (zerr) {}
                group.clipped = true;
                elementCount += batch.items.length;
                processed++;
                AIArtboardStudio._restoreBatchObjects(objectStates);
                AIArtboardStudio._restoreLayerChain(layerChain);
            } catch (batchError) {
                /* Best-effort rollback: move artwork back to its original container. */
                for (var m = moved.length - 1; m >= 0; m--) {
                    try { moved[m].move(batch.parent, ElementPlacement.PLACEATEND); } catch (moveBackError) {}
                }
                try { if (group) group.remove(); } catch (removeGroupError) {}
                AIArtboardStudio._restoreBatchObjects(objectStates);
                AIArtboardStudio._restoreLayerChain(layerChain);
                errors.push((scope == 'selected' ? 'مجموعة عناصر' : layer.name) + ': ' + (batchError.message || batchError));
            }
        }
        try { doc.activeLayer = originalLayer; } catch (activeError) {}
        if (processed < 1) throw new Error('لم يتم إنشاء أي ماسك. تأكد من وجود عناصر في النطاق المحدد، أو ألغِ قفل الطبقات والعناصر المستهدفة.');
        var msg = 'تم إنشاء ماسك داخل حدود لوحة الرسم لـ ' + elementCount + ' عنصر في ' + processed + ' مجموعة.';
        if (scope == 'selected') msg += ' تمت معالجة العناصر المحددة فقط.';
        else msg += ' تمت معالجة جميع العناصر المباشرة في طبقات المستند، بما فيها العناصر المجمعة.';
        if (skipped) msg += ' تم تجاوز ' + skipped + ' عنصرًا في طبقات مخفية أو مقفلة.';
        if (errors.length) msg += ' لم تكتمل بعض المجموعات: ' + errors.join(' | ');
        return AIArtboardStudio._result(true, msg);
    } catch (e) {
        try { if (doc && originalLayer) doc.activeLayer = originalLayer; } catch (restoreError) {}
        return AIArtboardStudio._result(false, e.message || e);
    }
};

AIArtboardStudio._collectImageItems = function (container, out) {
    var items = container.pageItems;
    for (var i = 0; i < items.length; i++) {
        var item = items[i];
        try {
            if (item.parent == container && (item.typename == 'PlacedItem' || item.typename == 'RasterItem')) out.push(item);
            else if (item.parent == container && item.typename == 'GroupItem') AIArtboardStudio._collectImageItems(item, out);
        } catch (e) {}
    }
};

AIArtboardStudio.maskImagesOnly = function (includeHidden) {
    var doc, originalLayer, layers, processed = 0, imageCount = 0, skipped = 0, errors = [];
    try {
        doc = AIArtboardStudio._doc(); originalLayer = doc.activeLayer;
        var r = AIArtboardStudio._artboard(doc), left = r[0], top = r[1], width = r[2] - r[0], height = r[1] - r[3];
        layers = []; AIArtboardStudio._collectLayers(doc.layers, layers);
        for (var i = 0; i < layers.length; i++) {
            var layer = layers[i];
            if (AIArtboardStudio._shouldSkipLayer(layer, includeHidden)) { skipped++; continue; }
            var chain = AIArtboardStudio._openLayerChain(layer);
            try {
                var images = []; AIArtboardStudio._collectImageItems(layer, images);
                if (!images.length) { skipped++; AIArtboardStudio._restoreLayerChain(chain); continue; }
                var group = layer.groupItems.add(); group.name = 'Artboard Image Mask — ' + layer.name;
                for (var j = 0; j < images.length; j++) {
                    try { images[j].locked = false; } catch (unlockImage) {}
                    images[j].move(group, ElementPlacement.PLACEATEND);
                }
                var clip = group.pathItems.rectangle(top, left, width, height);
                clip.name = 'Artboard Image Clipping Path'; clip.stroked = false; clip.filled = false; clip.clipping = true;
                try { clip.zOrder(ZOrderMethod.BRINGTOFRONT); } catch (zerr) {}
                group.clipped = true;
                imageCount += images.length; processed++;
                AIArtboardStudio._restoreLayerChain(chain);
            } catch (layerError) { AIArtboardStudio._restoreLayerChain(chain); errors.push(layer.name + ': ' + (layerError.message || layerError)); }
        }
        try { doc.activeLayer = originalLayer; } catch (activeError) {}
        if (!processed) throw new Error('لم يتم العثور على صور مرتبطة أو مضمّنة في الطبقات المستهدفة.');
        var msg = 'تم إنشاء ماسك للصور فقط في ' + processed + ' طبقة، بإجمالي ' + imageCount + ' صورة. لم يتم نقل النصوص والأشكال المتجهية.';
        if (skipped) msg += ' تم تجاوز ' + skipped + ' طبقة لا تحتوي صورًا أو غير مستهدفة.';
        if (errors.length) msg += ' أخطاء: ' + errors.join(' | ');
        return AIArtboardStudio._result(true, msg);
    } catch (e) { try { if (doc && originalLayer) doc.activeLayer = originalLayer; } catch (restoreError) {} return AIArtboardStudio._result(false, e.message || e); }
};

AIArtboardStudio._imageBounds = function (item) {
    try { return item.visibleBounds; } catch (e) { return item.geometricBounds; }
};

AIArtboardStudio._collectSelectedImages = function (doc, out) {
    var sel = doc.selection;
    if (!sel || !sel.length) throw new Error('حدد صورة أو أكثر أولًا، أو اختر نطاق «جميع الصور».');
    for (var i = 0; i < sel.length; i++) {
        var item = sel[i];
        try {
            if (item.typename == 'PlacedItem' || item.typename == 'RasterItem') out.push(item);
            else if (item.typename == 'GroupItem') AIArtboardStudio._collectImageItems(item, out);
        } catch (e) {}
    }
};

AIArtboardStudio._cropOneImage = function (doc, item, rect, ppi, includeHidden) {
    // Returns 'cropped' | 'inside' | 'outside' | 'skipped'.
    var wasLocked = false, wasHidden = false;
    try { wasLocked = item.locked; } catch (e1) {}
    try { wasHidden = item.hidden; } catch (e2) {}
    if (wasHidden && !includeHidden) return 'skipped';
    try { item.locked = false; } catch (e3) {}
    try { item.hidden = false; } catch (e4) {}

    var b = AIArtboardStudio._imageBounds(item); // [left, top, right, bottom]
    var l = Math.max(b[0], rect[0]), t = Math.min(b[1], rect[1]), r = Math.min(b[2], rect[2]), bt = Math.max(b[3], rect[3]);
    if (r - l <= 0.01 || t - bt <= 0.01) {
        try { item.locked = wasLocked; } catch (e5) {}
        try { item.hidden = wasHidden; } catch (e6) {}
        return 'outside';
    }
    var tol = 0.05;
    if (b[0] >= rect[0] - tol && b[1] <= rect[1] + tol && b[2] <= rect[2] + tol && b[3] >= rect[3] - tol) {
        try { item.locked = wasLocked; } catch (e7) {}
        try { item.hidden = wasHidden; } catch (e8) {}
        return 'inside';
    }

    var name = '';
    try { name = item.name; } catch (e9) {}

    // Linked image: embed first so the cropped pixels are kept inside the document.
    if (item.typename == 'PlacedItem') {
        doc.selection = null;
        item.selected = true;
        item.embed();
        var embedded = doc.selection;
        if (!embedded || !embedded.length) throw new Error('تعذّر تضمين الصورة المرتبطة.');
        item = embedded[0];
        if (item.typename != 'RasterItem') throw new Error('الملف المرتبط ليس صورة نقطية (قد يكون PDF أو AI).');
    }

    // Remember the stacking position so the result stays where the original was.
    var marker = null;
    try { marker = item.parent.groupItems.add(); marker.move(item, ElementPlacement.PLACEBEFORE); } catch (e10) { marker = null; }

    var opts = new RasterizeOptions();
    try { opts.resolution = ppi; } catch (e11) {}
    try { opts.transparency = true; } catch (e12) {}
    try { opts.backgroundBlack = false; } catch (e13) {}
    try { opts.padding = 0; } catch (e14) {}
    try { opts.antiAliasingMethod = AntiAliasingMethod.ARTOPTIMIZED; } catch (e15) {}

    var result = doc.rasterize(item, [l, t, r, bt], opts);

    // Some versions keep the source art; remove it if it is still alive.
    var alive = false;
    try { alive = (item.typename !== undefined && item !== result); } catch (e16) { alive = false; }
    if (alive) { try { item.remove(); } catch (e17) {} }

    if (marker) {
        try { result.move(marker, ElementPlacement.PLACEBEFORE); } catch (e18) {}
        try { marker.remove(); } catch (e19) {}
    }
    try { if (name) result.name = name; } catch (e20) {}
    try { result.locked = wasLocked; } catch (e21) {}
    try { result.hidden = wasHidden; } catch (e22) {}
    return 'cropped';
};

AIArtboardStudio.cropImagesToArtboard = function (includeHidden, scope, ppi) {
    var doc, originalLayer, cropped = 0, inside = 0, outside = 0, skipped = 0, errors = [];
    try {
        doc = AIArtboardStudio._doc(); originalLayer = doc.activeLayer;
        ppi = parseFloat(ppi); if (!isFinite(ppi) || ppi < 36) ppi = 300; if (ppi > 2400) ppi = 2400;
        var rect = AIArtboardStudio._artboard(doc); // [left, top, right, bottom]
        var jobs = []; // {layer, chain, items}
        if (scope == 'selected') {
            var picked = []; AIArtboardStudio._collectSelectedImages(doc, picked);
            jobs.push({ layer: null, chain: null, items: picked });
        } else {
            var layers = []; AIArtboardStudio._collectLayers(doc.layers, layers);
            for (var i = 0; i < layers.length; i++) {
                var layer = layers[i];
                if (AIArtboardStudio._shouldSkipLayer(layer, includeHidden)) { skipped++; continue; }
                var chain = AIArtboardStudio._openLayerChain(layer);
                var found = []; AIArtboardStudio._collectImageItems(layer, found);
                if (!found.length) { AIArtboardStudio._restoreLayerChain(chain); continue; }
                jobs.push({ layer: layer, chain: chain, items: found });
            }
        }
        for (var j = 0; j < jobs.length; j++) {
            var job = jobs[j];
            for (var k = 0; k < job.items.length; k++) {
                try {
                    var res = AIArtboardStudio._cropOneImage(doc, job.items[k], rect, ppi, includeHidden || scope == 'selected');
                    if (res == 'cropped') cropped++; else if (res == 'inside') inside++; else if (res == 'outside') outside++; else skipped++;
                } catch (imgError) { errors.push((imgError.message || imgError)); }
            }
            if (job.chain) AIArtboardStudio._restoreLayerChain(job.chain);
        }
        try { doc.selection = null; } catch (selError) {}
        try { doc.activeLayer = originalLayer; } catch (activeError) {}
        if (!cropped && !inside && !outside && !errors.length) throw new Error('لم يتم العثور على صور في النطاق المحدد.');
        var msg = 'تم قص ' + cropped + ' صورة بحدود الـArtboard (دقة ' + ppi + ' ppi).';
        if (inside) msg += ' ' + inside + ' صورة داخل الحدود أصلًا فلم تتغيّر.';
        if (outside) msg += ' ' + outside + ' صورة خارج الـArtboard بالكامل فتُركت دون حذف.';
        if (skipped) msg += ' تم تجاوز ' + skipped + ' عنصر مخفي/غير مستهدف.';
        if (errors.length) msg += ' أخطاء: ' + errors.join(' | ');
        return AIArtboardStudio._result(cropped > 0 || !errors.length, msg);
    } catch (e) { try { if (doc && originalLayer) doc.activeLayer = originalLayer; } catch (restoreError) {} return AIArtboardStudio._result(false, e.message || e); }
};

AIArtboardStudio._jsq = function (value) {
    // JSON-safe string literal (ASCII only, so it survives the evalScript text channel).
    var s = String(value), out = '"';
    for (var i = 0; i < s.length; i++) {
        var c = s.charCodeAt(i), ch = s.charAt(i);
        if (ch == '"') out += '\\"';
        else if (ch == '\\') out += '\\\\';
        else if (c < 32 || c > 126) { var hex = c.toString(16); while (hex.length < 4) hex = '0' + hex; out += '\\u' + hex; }
        else out += ch;
    }
    return out + '"';
};

AIArtboardStudio._firstSelectedImage = function (doc) {
    var sel = doc.selection;
    if (!sel || !sel.length) return null;
    for (var i = 0; i < sel.length; i++) {
        try { if (sel[i].typename == 'RasterItem' || sel[i].typename == 'PlacedItem') return sel[i]; } catch (e) {}
    }
    return null;
};

AIArtboardStudio._progressOpen = function (text) {
    // Small native progress window (like Illustrator's own export dialog); purely cosmetic, never fatal.
    try {
        var w = new Window('palette', 'Artboard Studio');
        w.orientation = 'column'; w.alignChildren = 'fill'; w.margins = 22; w.spacing = 12;
        var t = w.add('statictext', undefined, text); t.preferredSize.width = 300;
        var pb = w.add('progressbar', undefined, 0, 100); pb.preferredSize.width = 300; pb.value = 60;
        w.center(); w.show(); try { w.update(); } catch (e1) {}
        return w;
    } catch (e) { return null; }
};
AIArtboardStudio._progressClose = function (w) { try { if (w) w.close(); } catch (e) {} };

AIArtboardStudio.exportImageForEdit = function (ppi, maxSide) {
    var w = AIArtboardStudio._progressOpen('Loading image... please wait');
    try { return AIArtboardStudio._exportImageForEditCore(ppi, maxSide); }
    finally { AIArtboardStudio._progressClose(w); }
};
AIArtboardStudio.applyEditedImage = function (path, bounds, mode, placeBounds) {
    var w = AIArtboardStudio._progressOpen('Applying changes... please wait');
    try { return AIArtboardStudio._applyEditedImageCore(path, bounds, mode, placeBounds); }
    finally { AIArtboardStudio._progressClose(w); }
};

AIArtboardStudio._exportInPlace = function (doc, item, pct, file) {
    // Exports only the given item from the current document - no new document window is opened.
    var saved = [], i, ok = false;
    try { for (i = 0; i < doc.selection.length; i++) saved.push(doc.selection[i]); } catch (e0) {}
    try {
        try { if (file.exists) file.remove(); } catch (e1) {}
        doc.selection = null; item.selected = true;
        var o = new ExportOptionsPNG24();
        o.antiAliasing = true; o.transparency = true; o.artBoardClipping = false;
        o.horizontalScale = pct; o.verticalScale = pct;
        doc.exportSelectedArtwork(file, ExportType.PNG24, o);
        ok = !!file.exists;
    } catch (e2) { ok = false; }
    try { doc.selection = null; for (i = 0; i < saved.length; i++) saved[i].selected = true; } catch (e3) {}
    return ok;
};

AIArtboardStudio._exportImageForEditCore = function (ppi, maxSide) {
    var doc = null, tmp = null;
    try {
        doc = AIArtboardStudio._doc();
        ppi = parseFloat(ppi); if (!isFinite(ppi) || ppi < 36) ppi = 300; if (ppi > 600) ppi = 600;
        maxSide = parseFloat(maxSide); if (!isFinite(maxSide) || maxSide < 256) maxSide = 4096;
        var item = AIArtboardStudio._firstSelectedImage(doc);
        if (!item) throw new Error('حدد صورة واحدة (مضمّنة أو مرتبطة) داخل Illustrator أولًا.');
        var b = item.visibleBounds; // [left, top, right, bottom]
        var w = b[2] - b[0], h = b[1] - b[3];
        if (w <= 0 || h <= 0) throw new Error('أبعاد الصورة غير صالحة.');
        var scale = ppi / 72;
        if (Math.max(w, h) * scale > maxSide) scale = maxSide / Math.max(w, h);
        var pct = scale * 100;
        var stamp = new Date().getTime();
        var srcFile = new File(Folder.temp.fsName + '/abs_src_' + stamp + '.png');
        var outFile = new File(Folder.temp.fsName + '/abs_edit_' + stamp + '.png');

        var method = 'selection';
        if (!AIArtboardStudio._exportInPlace(doc, item, pct, srcFile)) {
            // Fallback for versions without exportSelectedArtwork: a temporary document (briefly visible).
            method = 'tempdoc';
            tmp = app.documents.add(DocumentColorSpace.RGB, Math.max(1, w), Math.max(1, h));
            var dup = item.duplicate(tmp.layers[0], ElementPlacement.PLACEATBEGINNING);
            tmp.artboards[0].artboardRect = dup.visibleBounds;
            var opts = new ExportOptionsPNG24();
            opts.antiAliasing = true; opts.transparency = true; opts.artBoardClipping = true;
            opts.horizontalScale = pct; opts.verticalScale = pct;
            tmp.exportFile(srcFile, ExportType.PNG24, opts);
            tmp.close(SaveOptions.DONOTSAVECHANGES); tmp = null;
            app.activeDocument = doc;
        }
        if (!srcFile.exists) throw new Error('تعذّر تصدير الصورة المحددة.');

        var name = ''; try { name = item.name; } catch (e1) {}
        if (!name) name = (item.typename == 'PlacedItem') ? 'صورة مرتبطة' : 'صورة مضمّنة';
        var json = '{"path":' + AIArtboardStudio._jsq(srcFile.fsName) +
            ',"outPath":' + AIArtboardStudio._jsq(outFile.fsName) +
            ',"bounds":[' + b[0] + ',' + b[1] + ',' + b[2] + ',' + b[3] + ']' +
            ',"name":' + AIArtboardStudio._jsq(name) +
            ',"kind":' + AIArtboardStudio._jsq(item.typename) + ',"method":' + AIArtboardStudio._jsq(method) + '}';
        return 'OK|' + json;
    } catch (e) {
        try { if (tmp) tmp.close(SaveOptions.DONOTSAVECHANGES); } catch (c1) {}
        try { if (doc) app.activeDocument = doc; } catch (c2) {}
        return AIArtboardStudio._result(false, e.message || e);
    }
};

AIArtboardStudio._sameBounds = function (item, bounds) {
    try {
        var b = item.visibleBounds;
        for (var i = 0; i < 4; i++) if (Math.abs(b[i] - bounds[i]) > 0.6) return false;
        return true;
    } catch (e) { return false; }
};

AIArtboardStudio._findImageByBounds = function (doc, bounds) {
    var i, sel = doc.selection;
    if (sel && sel.length) {
        for (i = 0; i < sel.length; i++) {
            try { if ((sel[i].typename == 'RasterItem' || sel[i].typename == 'PlacedItem') && AIArtboardStudio._sameBounds(sel[i], bounds)) return sel[i]; } catch (e0) {}
        }
    }
    for (i = 0; i < doc.rasterItems.length; i++) { if (AIArtboardStudio._sameBounds(doc.rasterItems[i], bounds)) return doc.rasterItems[i]; }
    for (i = 0; i < doc.placedItems.length; i++) { if (AIArtboardStudio._sameBounds(doc.placedItems[i], bounds)) return doc.placedItems[i]; }
    return null;
};

AIArtboardStudio._applyEditedImageCore = function (path, bounds, mode, placeBounds) {
    var doc = null, pb = (placeBounds && placeBounds.length === 4) ? placeBounds : bounds;
    try {
        doc = AIArtboardStudio._doc();
        var f = new File(path);
        if (!f.exists) throw new Error('الملف المعدّل غير موجود.');
        var target = AIArtboardStudio._findImageByBounds(doc, bounds);
        if (!target) throw new Error('تعذّر العثور على الصورة الأصلية (قد تكون تحركت أو حُذفت). حدّدها وحمّلها من جديد.');
        try { target.locked = false; } catch (e1) {}
        var wasHidden = false; try { wasHidden = target.hidden; target.hidden = false; } catch (e2) {}
        var container = target.parent;
        var placed;
        try { placed = container.placedItems.add(); } catch (e3) { placed = target.layer.placedItems.add(); }
        placed.file = f;
        placed.width = pb[2] - pb[0];
        placed.height = pb[1] - pb[3];
        placed.left = pb[0];
        placed.top = pb[1];
        doc.selection = null;
        placed.selected = true;
        placed.embed();
        var result = (doc.selection && doc.selection.length) ? doc.selection[0] : null;
        if (!result) { try { result = container.pageItems[0]; } catch (e4) {} }
        if (!result) throw new Error('تعذّر تضمين الصورة المعدّلة في المستند.');
        try { result.move(target, ElementPlacement.PLACEBEFORE); } catch (e5) {}
        var name = ''; try { name = target.name; } catch (e6) {}
        if (mode == 'replace') {
            try { target.remove(); } catch (e7) { throw new Error('أُضيفت الصورة المعدّلة لكن تعذّر حذف الأصل (قد يكون مقفلًا).'); }
            try { if (name) result.name = name; } catch (e8) {}
            try { result.hidden = wasHidden; } catch (e9) {}
        } else {
            try { target.hidden = wasHidden; } catch (e10) {}
            try { result.name = (name ? name + ' ' : '') + '(معدّلة)'; } catch (e11) {}
        }
        try { doc.selection = null; result.selected = true; } catch (e12) {}
        return AIArtboardStudio._result(true, mode == 'replace' ? 'تم استبدال الصورة بالنسخة المعدّلة.' : 'تمت إضافة نسخة معدّلة فوق الصورة الأصلية.');
    } catch (e) { return AIArtboardStudio._result(false, e.message || e); }
};


/* ---------- live on-canvas preview ----------
   A linked placeholder image sits on top of the real image and is re-linked to a fresh low-resolution
   frame after every change, so the edit is visible on the artwork itself. The original is only hidden
   during the session and is restored on end/cancel.
   L.bounds = rectangle of the original image, L.frame = rectangle currently occupied by the placeholder
   (differs from L.bounds for warps, whose result may extend beyond the original). */
AIArtboardStudio._live = null;

AIArtboardStudio._liveFrameRect = function (b, nb) {
    // nb = [x0, y0, x1, y1] in units of the original image (x right, y down), or null for "same as original"
    if (!nb || nb.length !== 4) return [b[0], b[1], b[2], b[3]];
    var w = b[2] - b[0], h = b[1] - b[3];
    return [b[0] + nb[0] * w, b[1] - nb[1] * h, b[0] + nb[2] * w, b[1] - nb[3] * h];
};

AIArtboardStudio._liveFit = function (ph, r) {
    ph.width = r[2] - r[0];
    ph.height = r[1] - r[3];
    ph.left = r[0];
    ph.top = r[1];
};

AIArtboardStudio._liveSync = function (L) {
    // If the user moved/resized the preview image, the hidden original follows (no duplicates, no snapping back).
    var ph = L.ph, cur = [ph.left, ph.top, ph.left + ph.width, ph.top - ph.height], f = L.frame, b = L.bounds, moved = false, i;
    for (i = 0; i < 4; i++) if (Math.abs(cur[i] - f[i]) > 0.01) moved = true;
    if (!moved) return;
    var fw = f[2] - f[0], fh = f[1] - f[3], cw = cur[2] - cur[0], ch = cur[1] - cur[3];
    if (fw <= 0 || fh <= 0 || cw <= 0 || ch <= 0) return;
    var rw = cw / fw, rh = ch / fh;
    var nl = cur[0] + (b[0] - f[0]) * rw, nt = cur[1] + (b[1] - f[1]) * rh;
    var nw = (b[2] - b[0]) * rw, nh = (b[1] - b[3]) * rh;
    var t = L.target;
    try { t.locked = false; } catch (e0) {}
    try { t.width = nw; t.height = nh; } catch (e1) {}
    try { t.left = nl; t.top = nt; } catch (e2) {}
    L.bounds = [nl, nt, nl + nw, nt - nh];
    L.frame = cur;
};

AIArtboardStudio.liveBegin = function (framePath, bounds, nb) {
    var doc = null, ph = null;
    try {
        if (AIArtboardStudio._live) AIArtboardStudio.liveEnd();
        doc = AIArtboardStudio._doc();
        var f = new File(framePath);
        if (!f.exists) throw new Error('ملف المعاينة غير موجود.');
        var target = AIArtboardStudio._findImageByBounds(doc, bounds);
        if (!target) throw new Error('تعذّر العثور على الصورة الأصلية في المستند.');
        var container = target.parent;
        try { ph = container.placedItems.add(); } catch (e1) { ph = target.layer.placedItems.add(); }
        ph.file = f;
        var fr = AIArtboardStudio._liveFrameRect(bounds, nb);
        AIArtboardStudio._liveFit(ph, fr);
        try { ph.name = '__ABS_LIVE__'; } catch (e2) {}
        try { ph.move(target, ElementPlacement.PLACEBEFORE); } catch (e3) {}
        var wasHidden = false;
        try { wasHidden = target.hidden; target.hidden = true; } catch (e4) {}
        AIArtboardStudio._live = { doc: doc, target: target, ph: ph, bounds: bounds, frame: fr, wasHidden: wasHidden };
        try { app.redraw(); } catch (e5) {}
        return AIArtboardStudio._result(true, 'live');
    } catch (e) {
        try { if (ph) ph.remove(); } catch (c1) {}
        return AIArtboardStudio._result(false, e.message || e);
    }
};

AIArtboardStudio.liveFrame = function (framePath, nb) {
    var L = AIArtboardStudio._live, lvl = null;
    try {
        if (!L) throw new Error('انتهت جلسة المعاينة المباشرة.');
        if (app.activeDocument !== L.doc) throw new Error('تغيّر المستند النشط أثناء المعاينة.');
        try { L.ph.typename; } catch (e0) { AIArtboardStudio._live = null; throw new Error('حُذفت صورة المعاينة من المستند.'); }
        var f = new File(framePath);
        if (!f.exists) throw new Error('ملف الإطار غير موجود.');
        try { lvl = app.userInteractionLevel; app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS; } catch (e1) {}
        AIArtboardStudio._liveSync(L);
        L.ph.file = f;
        L.frame = AIArtboardStudio._liveFrameRect(L.bounds, nb);
        AIArtboardStudio._liveFit(L.ph, L.frame);
        try { app.redraw(); } catch (e2) {}
        try { if (lvl !== null) app.userInteractionLevel = lvl; } catch (e3) {}
        return AIArtboardStudio._result(true, 'frame');
    } catch (e) {
        try { if (lvl !== null) app.userInteractionLevel = lvl; } catch (e4) {}
        return AIArtboardStudio._result(false, e.message || e);
    }
};

AIArtboardStudio.liveEnd = function () {
    var L = AIArtboardStudio._live;
    AIArtboardStudio._live = null;
    if (!L) return AIArtboardStudio._result(true, 'none');
    var err = '', b = L.bounds;
    try { AIArtboardStudio._liveSync(L); b = L.bounds; } catch (e0) {}
    try { L.ph.remove(); } catch (e1) {}
    try { L.target.hidden = L.wasHidden; } catch (e2) { err = 'تعذّر إظهار الصورة الأصلية.'; }
    try { L.doc.selection = null; L.target.selected = true; } catch (e3) {}
    try { app.redraw(); } catch (e4) {}
    if (err) return AIArtboardStudio._result(false, err);
    return 'OK|{"bounds":[' + b[0] + ',' + b[1] + ',' + b[2] + ',' + b[3] + ']}';
};

/* ---------- direct transforms (Scale / Rotate / Skew / Free Transform) ----------
   Applied to the real image through a matrix about its centre; every update first undoes the previous one,
   so the image is always "original x current settings" and can be reverted exactly. */
AIArtboardStudio._xf = null;

AIArtboardStudio._mmul = function (p, q) { // apply q first, then p
    return { a: p.a * q.a + p.c * q.b, b: p.b * q.a + p.d * q.b, c: p.a * q.c + p.c * q.d, d: p.b * q.c + p.d * q.d };
};
AIArtboardStudio._minv = function (m) {
    var det = m.a * m.d - m.b * m.c;
    if (Math.abs(det) < 1e-9) throw new Error('إعدادات التحويل غير صالحة (المساحة صفر).');
    return { a: m.d / det, b: -m.b / det, c: -m.c / det, d: m.a / det };
};
AIArtboardStudio._xfMatrix = function (sx, sy, rot, skx, sky, fh, fv) {
    var D = Math.PI / 180, mul = AIArtboardStudio._mmul;
    var S = { a: (sx / 100) * (fh ? -1 : 1), b: 0, c: 0, d: (sy / 100) * (fv ? -1 : 1) };
    var K = { a: 1, b: Math.tan(sky * D), c: Math.tan(skx * D), d: 1 };
    var c = Math.cos(rot * D), s = Math.sin(rot * D), R = { a: c, b: s, c: -s, d: c };
    return mul(R, mul(K, S));
};
AIArtboardStudio._toMatrix = function (m) {
    var mx = new Matrix();
    mx.mValueA = m.a; mx.mValueB = m.b; mx.mValueC = m.c; mx.mValueD = m.d; mx.mValueTX = 0; mx.mValueTY = 0;
    return mx;
};

AIArtboardStudio.xfBegin = function () {
    try {
        if (AIArtboardStudio._xf) AIArtboardStudio.xfEnd(true);
        var doc = AIArtboardStudio._doc();
        var item = AIArtboardStudio._firstSelectedImage(doc);
        if (!item) throw new Error('حدد صورة واحدة (مضمّنة أو مرتبطة) داخل Illustrator أولًا.');
        var b = item.visibleBounds, name = ''; try { name = item.name; } catch (e1) {}
        AIArtboardStudio._xf = { doc: doc, target: item, cur: { a: 1, b: 0, c: 0, d: 1 } };
        return 'OK|{"bounds":[' + b[0] + ',' + b[1] + ',' + b[2] + ',' + b[3] + '],"name":' + AIArtboardStudio._jsq(name || item.typename) + '}';
    } catch (e) { return AIArtboardStudio._result(false, e.message || e); }
};

AIArtboardStudio.xfSet = function (sx, sy, rot, skx, sky, fh, fv) {
    try {
        var X = AIArtboardStudio._xf;
        if (!X) throw new Error('لم تبدأ جلسة التحويل.');
        if (app.activeDocument !== X.doc) throw new Error('تغيّر المستند النشط أثناء التحويل.');
        try { X.target.typename; } catch (e0) { AIArtboardStudio._xf = null; throw new Error('الصورة لم تعد موجودة في المستند.'); }
        if (!(sx > 0.5 && sy > 0.5)) throw new Error('نسبة التحجيم صغيرة جدًا.');
        try { X.target.locked = false; } catch (e1) {}
        var next = AIArtboardStudio._xfMatrix(sx, sy, rot, skx, sky, !!fh, !!fv);
        var delta = AIArtboardStudio._mmul(next, AIArtboardStudio._minv(X.cur));
        X.target.transform(AIArtboardStudio._toMatrix(delta), true, true, true, true, 1, Transformation.CENTER);
        X.cur = next;
        try { app.redraw(); } catch (e2) {}
        return AIArtboardStudio._result(true, 'xf');
    } catch (e) { return AIArtboardStudio._result(false, e.message || e); }
};

AIArtboardStudio.xfEnd = function (keep) {
    var X = AIArtboardStudio._xf;
    AIArtboardStudio._xf = null;
    if (!X) return AIArtboardStudio._result(true, 'none');
    try {
        if (!keep) {
            var inv = AIArtboardStudio._minv(X.cur);
            X.target.transform(AIArtboardStudio._toMatrix(inv), true, true, true, true, 1, Transformation.CENTER);
        }
        try { X.doc.selection = null; X.target.selected = true; } catch (e1) {}
        try { app.redraw(); } catch (e2) {}
        return AIArtboardStudio._result(true, keep ? 'kept' : 'reverted');
    } catch (e) { return AIArtboardStudio._result(false, e.message || e); }
};

AIArtboardStudio.xfNativeTool = function (name) {
    try {
        var map = { free: 'Adobe Free Transform Tool', scale: 'Adobe Scale Tool', rotate: 'Adobe Rotate Tool', skew: 'Adobe Shear Tool' };
        var t = map[name]; if (!t) throw new Error('أداة غير معروفة.');
        app.selectTool(t);
        return AIArtboardStudio._result(true, 'tool');
    } catch (e) { return AIArtboardStudio._result(false, 'تعذّر تفعيل الأداة الأصلية في هذا الإصدار (' + (e.message || e) + ').'); }
};

AIArtboardStudio.cropAllLayers = function (includeHidden, scope) {
    var doc, originalLayer, batches, processed = 0, elementCount = 0, skipped = 0, errors = [];
    try {
        doc = AIArtboardStudio._doc();
        originalLayer = doc.activeLayer;
        var r = AIArtboardStudio._artboard(doc);
        var left = r[0], top = r[1], width = r[2] - r[0], height = r[1] - r[3];
        batches = AIArtboardStudio._elementBatches(doc, scope, includeHidden);

        for (var i = 0; i < batches.length; i++) {
            var batch = batches[i], layer = batch.layer;
            if (AIArtboardStudio._shouldSkipLayer(layer, includeHidden)) { skipped += batch.items.length; continue; }
            var layerChain = AIArtboardStudio._openLayerChain(layer);
            try {
                doc.activeLayer = layer;
                /* Process each selected/top-level object separately. This prevents one
                   unsupported object from stopping the crop of other elements. */
                for (var j = 0; j < batch.items.length; j++) {
                    var item = batch.items[j];
                    var oneItemBatch = { parent: batch.parent, layer: layer, items: [item] };
                    var objectStates = AIArtboardStudio._unlockBatchObjects(oneItemBatch);
                    var cropRect = null, grouped = false;
                    try {
                        doc.selection = null;
                        item.selected = true;
                        cropRect = batch.parent.pathItems.rectangle(top, left, width, height);
                        cropRect.name = 'TEMP — Artboard Crop Boundary';
                        try { cropRect.zOrder(ZOrderMethod.BRINGTOFRONT); } catch (cropZError) {}
                        cropRect.filled = true;
                        cropRect.stroked = false;
                        if (doc.documentColorSpace == DocumentColorSpace.CMYK) {
                            var whiteC = new CMYKColor(); whiteC.cyan = 0; whiteC.magenta = 0; whiteC.yellow = 0; whiteC.black = 0; cropRect.fillColor = whiteC;
                        } else {
                            var whiteR = new RGBColor(); whiteR.red = 255; whiteR.green = 255; whiteR.blue = 255; cropRect.fillColor = whiteR;
                        }
                        cropRect.selected = true;
                        app.executeMenuCommand('group');
                        grouped = true;
                        app.executeMenuCommand('Live Pathfinder Crop');
                        app.executeMenuCommand('expandStyle');
                        try { app.executeMenuCommand('ungroup'); grouped = false; } catch (ungroupError) {}
                        doc.selection = null;
                        elementCount++;
                        processed++;
                    } catch (itemError) {
                        if (grouped) { try { app.executeMenuCommand('ungroup'); } catch (restoreGroupError) {} }
                        try { if (cropRect) cropRect.remove(); } catch (removeCropError) {}
                        try { doc.selection = null; } catch (selectionResetError) {}
                        var itemName = 'عنصر ' + (j + 1);
                        try { if (item.name) itemName = item.name; } catch (nameError) {}
                        errors.push(itemName + ': ' + (itemError.message || itemError));
                    }
                    AIArtboardStudio._restoreBatchObjects(objectStates);
                }
            } catch (batchError) {
                errors.push((scope == 'selected' ? 'مجموعة عناصر' : layer.name) + ': ' + (batchError.message || batchError));
            }
            AIArtboardStudio._restoreLayerChain(layerChain);
        }
        try { doc.activeLayer = originalLayer; } catch (activeError) {}
        if (processed < 1) throw new Error('لم تنجح عملية القصّ في أي عنصر. تأكد من تحديد عناصر متجهية قابلة للقص. للصور استخدم أداة «ماسك للصور».');
        var msg = 'اكتمل القصّ الفعلي لـ ' + elementCount + ' عنصر باستخدام Pathfinder Crop.';
        if (scope == 'selected') msg += ' تمت معالجة العناصر المحددة فقط.';
        else msg += ' تمت معالجة جميع العناصر المباشرة في طبقات المستند، مع الحفاظ على المجموعات كوحدات مستقلة.';
        msg += ' هذه عملية مدمّرة وقد تدمج الأشكال أو تزيل الحدود والسمات في بعض الحالات.';
        if (skipped) msg += ' تم تجاوز ' + skipped + ' عنصرًا في طبقات مخفية أو مقفلة.';
        if (errors.length) msg += ' عناصر لم تكتمل: ' + errors.join(' | ');
        return AIArtboardStudio._result(true, msg);
    } catch (e) {
        try { if (doc && originalLayer) doc.activeLayer = originalLayer; } catch (restoreError) {}
        return AIArtboardStudio._result(false, e.message || e);
    }
};

AIArtboardStudio.placeQRMatrix = function (matrix, sizeMM) {
    var doc = null, layer = null, group = null, originalLayer = null;
    try {
        doc = AIArtboardStudio._doc();
        if (!matrix || typeof matrix.length != 'number' || matrix.length < 21 || matrix.length > 41) {
            throw new Error('بيانات QR غير صالحة. أعد إنشاء الرمز.');
        }
        var n = matrix.length;
        for (var rowCheck = 0; rowCheck < n; rowCheck++) {
            if (!matrix[rowCheck] || matrix[rowCheck].length != n) throw new Error('مصفوفة QR غير مكتملة.');
        }

        var artboard = AIArtboardStudio._artboard(doc);
        var size = Number(sizeMM) * 2.834645669;
        if (!(size > 5 && size < 2000)) throw new Error('مقاس QR غير صالح.');
        var quiet = 4;
        var total = n + quiet * 2;
        var moduleSize = size / total;
        var centerX = (artboard[0] + artboard[2]) / 2;
        var centerY = (artboard[1] + artboard[3]) / 2;
        var left = centerX - size / 2;
        var top = centerY + size / 2;
        if (size > (artboard[2] - artboard[0]) || size > (artboard[1] - artboard[3])) {
            throw new Error('حجم QR أكبر من لوحة الرسم النشطة. قلّل الحجم أو اختر لوحة أكبر.');
        }

        originalLayer = doc.activeLayer;
        layer = doc.layers.add();
        layer.name = 'QR Code';
        doc.activeLayer = layer;
        group = layer.groupItems.add();
        group.name = 'QR Code — Editable Vector';

        var isRGB = false;
        try { isRGB = doc.documentColorSpace == DocumentColorSpace.RGB; } catch (spaceError) {}
        var white, black;
        if (isRGB) {
            white = new RGBColor(); white.red = 255; white.green = 255; white.blue = 255;
            black = new RGBColor(); black.red = 0; black.green = 0; black.blue = 0;
        } else {
            white = new CMYKColor(); white.cyan = 0; white.magenta = 0; white.yellow = 0; white.black = 0;
            black = new CMYKColor(); black.cyan = 0; black.magenta = 0; black.yellow = 0; black.black = 100;
        }

        // White quiet-zone background, then one black rectangle per horizontal run.
        var background = doc.pathItems.rectangle(top, left, size, size);
        background.name = 'QR — White Quiet Zone';
        background.stroked = false;
        background.filled = true;
        background.fillColor = white;
        background.move(group, ElementPlacement.PLACEATEND);

        var created = 0;
        for (var r = 0; r < n; r++) {
            var c = 0;
            while (c < n) {
                if (matrix[r][c] !== true && matrix[r][c] !== 1) { c++; continue; }
                var runStart = c;
                while (c < n && (matrix[r][c] === true || matrix[r][c] === 1)) c++;
                var runWidth = (c - runStart) * moduleSize;
                var x = left + (quiet + runStart) * moduleSize;
                var y = top - (quiet + r) * moduleSize;
                var bar = doc.pathItems.rectangle(y, x, runWidth, moduleSize);
                bar.name = 'QR Module Row ' + (r + 1) + ' Run ' + (created + 1);
                bar.stroked = false;
                bar.filled = true;
                bar.fillColor = black;
                bar.move(group, ElementPlacement.PLACEATEND);
                created++;
            }
        }
        // Ensure the white quiet-zone remains behind every black module regardless of stacking order.
        try { background.zOrder(ZOrderMethod.SENDTOBACK); } catch (zOrderError) {}

        try { group.selected = true; } catch (selectError) {}
        try { doc.activeLayer = originalLayer; } catch (restoreLayerError) {}
        return AIArtboardStudio._result(true, 'تم إنشاء QR وإدراجه كعناصر متجهية أصلية قابلة للتحرير داخل مجموعة في طبقة مستقلة.');
    } catch (e) {
        try { if (group) group.remove(); } catch (groupError) {}
        try { if (layer && layer.pageItems.length === 0) layer.remove(); } catch (layerError) {}
        try { if (doc && originalLayer) doc.activeLayer = originalLayer; } catch (restoreError) {}
        return AIArtboardStudio._result(false, e.message || e);
    }
};
