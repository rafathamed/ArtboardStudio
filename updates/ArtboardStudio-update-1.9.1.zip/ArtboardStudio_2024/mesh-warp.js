/* Artboard Studio - mesh warp engine (Distort / Perspective / Warp / Split Warp).
   A control grid of points (in units of the source image: x right, y down, 0..1 = the original rectangle)
   defines a smooth surface; the image is drawn onto it with many small textured triangles on a canvas.
   Pure JS + Canvas 2D, no dependencies. window.ABSMesh */
(function () {
  'use strict';

  /* grid layout per mode: gx x gy control points */
  var MODES = {
    distort:     { gx: 2, gy: 2, kind: 'bilinear' },
    perspective: { gx: 2, gy: 2, kind: 'homography' },
    warp:        { gx: 4, gy: 4, kind: 'grid' },
    splitH:      { gx: 2, gy: 3, kind: 'grid' },   // one horizontal split line -> 3 rows of points
    splitV:      { gx: 3, gy: 2, kind: 'grid' },   // one vertical split line
    splitX:      { gx: 3, gy: 3, kind: 'grid' }    // crosswise
  };

  function identityPoints(mode) {
    var m = MODES[mode], pts = [], i, j;
    for (j = 0; j < m.gy; j++) for (i = 0; i < m.gx; i++) pts.push({ x: i / (m.gx - 1), y: j / (m.gy - 1) });
    return pts;
  }

  function isIdentity(mode, pts) {
    var id = identityPoints(mode);
    for (var k = 0; k < id.length; k++) if (Math.abs(id[k].x - pts[k].x) > 1e-4 || Math.abs(id[k].y - pts[k].y) > 1e-4) return false;
    return true;
  }

  /* Catmull-Rom through p0..p3 at t in [0,1] between p1 and p2 */
  function cr(p0, p1, p2, p3, t) {
    var t2 = t * t, t3 = t2 * t;
    return 0.5 * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 + (-p0 + 3 * p1 - 3 * p2 + p3) * t3);
  }
  function crAxis(arr, n, t, key) { // arr: array of values, n points, t in [0,1]
    if (n === 2) return arr[0][key] + (arr[1][key] - arr[0][key]) * t;
    var f = t * (n - 1), i = Math.floor(f); if (i >= n - 1) i = n - 2; if (i < 0) i = 0;
    var lt = f - i, a = arr[Math.max(0, i - 1)], b = arr[i], c = arr[i + 1], d = arr[Math.min(n - 1, i + 2)];
    return cr(a[key], b[key], c[key], d[key], lt);
  }

  /* homography unit square -> quad (p00,p10,p11,p01), returns function (u,v) */
  function homography(q) {
    var x0 = q[0].x, y0 = q[0].y, x1 = q[1].x, y1 = q[1].y, x2 = q[2].x, y2 = q[2].y, x3 = q[3].x, y3 = q[3].y;
    var dx1 = x1 - x2, dx2 = x3 - x2, dx3 = x0 - x1 + x2 - x3, dy1 = y1 - y2, dy2 = y3 - y2, dy3 = y0 - y1 + y2 - y3;
    var a, b, c, d, e, f, g, h;
    if (Math.abs(dx3) < 1e-12 && Math.abs(dy3) < 1e-12) { g = 0; h = 0; a = x1 - x0; b = x2 - x1; c = x0; d = y1 - y0; e = y2 - y1; f = y0; }
    else {
      var det = dx1 * dy2 - dx2 * dy1; if (Math.abs(det) < 1e-12) det = 1e-12;
      g = (dx3 * dy2 - dx2 * dy3) / det; h = (dx1 * dy3 - dx3 * dy1) / det;
      a = x1 - x0 + g * x1; b = x3 - x0 + h * x3; c = x0; d = y1 - y0 + g * y1; e = y3 - y0 + h * y3; f = y0;
    }
    return function (u, v) { var w = g * u + h * v + 1; if (Math.abs(w) < 1e-9) w = 1e-9; return { x: (a * u + b * v + c) / w, y: (d * u + e * v + f) / w }; };
  }

  /* surface function for a mode + control points */
  function surface(mode, pts) {
    var m = MODES[mode], gx = m.gx, gy = m.gy;
    if (m.kind === 'bilinear') {
      var p00 = pts[0], p10 = pts[1], p01 = pts[2], p11 = pts[3];
      return function (u, v) { return { x: (1 - v) * ((1 - u) * p00.x + u * p10.x) + v * ((1 - u) * p01.x + u * p11.x), y: (1 - v) * ((1 - u) * p00.y + u * p10.y) + v * ((1 - u) * p01.y + u * p11.y) }; };
    }
    if (m.kind === 'homography') return homography([pts[0], pts[1], pts[3], pts[2]]);
    return function (u, v) {
      var rows = [], j, i, row;
      for (j = 0; j < gy; j++) { row = []; for (i = 0; i < gx; i++) row.push(pts[j * gx + i]); rows.push({ x: crAxis(row, gx, u, 'x'), y: crAxis(row, gx, u, 'y') }); }
      return { x: crAxis(rows, gy, v, 'x'), y: crAxis(rows, gy, v, 'y') };
    };
  }

  function subdivisions(mode, quality) {
    var m = MODES[mode], base = quality === 'high' ? 48 : 18;
    return Math.max(base, (Math.max(m.gx, m.gy) - 1) * (quality === 'high' ? 24 : 9));
  }

  /* bounding box of the whole surface, in source units */
  function bbox(mode, pts) {
    var S = surface(mode, pts), N = 40, x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9, i, j, p;
    for (j = 0; j <= N; j++) for (i = 0; i <= N; i++) { p = S(i / N, j / N); if (p.x < x0) x0 = p.x; if (p.x > x1) x1 = p.x; if (p.y < y0) y0 = p.y; if (p.y > y1) y1 = p.y; }
    return [x0, y0, x1, y1];
  }

  function tri(ctx, img, s, d) {
    // s, d: [x0,y0,x1,y1,x2,y2]; inflate destination a little to hide seams between neighbours
    var cx = (d[0] + d[2] + d[4]) / 3, cy = (d[1] + d[3] + d[5]) / 3, k = 0.75, e = [], i, vx, vy, len;
    for (i = 0; i < 3; i++) { vx = d[i * 2] - cx; vy = d[i * 2 + 1] - cy; len = Math.sqrt(vx * vx + vy * vy) || 1; e.push(d[i * 2] + vx / len * k, d[i * 2 + 1] + vy / len * k); }
    var sx0 = s[0], sy0 = s[1], sx1 = s[2], sy1 = s[3], sx2 = s[4], sy2 = s[5];
    var det = sx0 * (sy1 - sy2) + sx1 * (sy2 - sy0) + sx2 * (sy0 - sy1);
    if (Math.abs(det) < 1e-9) return;
    var dx0 = d[0], dy0 = d[1], dx1 = d[2], dy1 = d[3], dx2 = d[4], dy2 = d[5];
    var a = (dx0 * (sy1 - sy2) + dx1 * (sy2 - sy0) + dx2 * (sy0 - sy1)) / det;
    var b = (dy0 * (sy1 - sy2) + dy1 * (sy2 - sy0) + dy2 * (sy0 - sy1)) / det;
    var c = (dx0 * (sx2 - sx1) + dx1 * (sx0 - sx2) + dx2 * (sx1 - sx0)) / det;
    var dd = (dy0 * (sx2 - sx1) + dy1 * (sx0 - sx2) + dy2 * (sx1 - sx0)) / det;
    var ee = (dx0 * (sx1 * sy2 - sx2 * sy1) + dx1 * (sx2 * sy0 - sx0 * sy2) + dx2 * (sx0 * sy1 - sx1 * sy0)) / det;
    var ff = (dy0 * (sx1 * sy2 - sx2 * sy1) + dy1 * (sx2 * sy0 - sx0 * sy2) + dy2 * (sx0 * sy1 - sx1 * sy0)) / det;
    ctx.save();
    ctx.beginPath(); ctx.moveTo(e[0], e[1]); ctx.lineTo(e[2], e[3]); ctx.lineTo(e[4], e[5]); ctx.closePath(); ctx.clip();
    ctx.transform(a, b, c, dd, ee, ff);
    ctx.drawImage(img, 0, 0);
    ctx.restore();
  }

  /* render(src, {mode, pts}, {maxSide, quality}) -> { canvas, nb:[x0,y0,x1,y1] }
     src: canvas/image with the original pixels. Output covers the surface bounding box (nb, in source units). */
  function render(src, spec, opt) {
    opt = opt || {};
    var mode = spec.mode, pts = spec.pts, S = surface(mode, pts), nb = bbox(mode, pts);
    var sw = src.width, sh = src.height;
    var bw = Math.max(1e-6, nb[2] - nb[0]), bh = Math.max(1e-6, nb[3] - nb[1]);
    var ow = sw * bw, oh = sh * bh, maxSide = opt.maxSide || 4096, k = Math.min(1, maxSide / Math.max(ow, oh));
    ow = Math.max(1, Math.round(ow * k)); oh = Math.max(1, Math.round(oh * k));
    var cv = document.createElement('canvas'); cv.width = ow; cv.height = oh;
    var ctx = cv.getContext('2d'); ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
    var M = subdivisions(mode, opt.quality), i, j, grid = [], p;
    for (j = 0; j <= M; j++) { var row = []; for (i = 0; i <= M; i++) { p = S(i / M, j / M); row.push([(p.x - nb[0]) / bw * ow, (p.y - nb[1]) / bh * oh]); } grid.push(row); }
    for (j = 0; j < M; j++) for (i = 0; i < M; i++) {
      var u0 = i / M * sw, u1 = (i + 1) / M * sw, v0 = j / M * sh, v1 = (j + 1) / M * sh;
      var A = grid[j][i], B = grid[j][i + 1], C = grid[j + 1][i + 1], D = grid[j + 1][i];
      tri(ctx, src, [u0, v0, u1, v0, u0, v1], [A[0], A[1], B[0], B[1], D[0], D[1]]);
      tri(ctx, src, [u1, v0, u1, v1, u0, v1], [B[0], B[1], C[0], C[1], D[0], D[1]]);
    }
    return { canvas: cv, nb: nb };
  }

  /* points on the surface along every grid row/column (for drawing the guide mesh); returns arrays of {x,y} */
  function guides(mode, pts) {
    var m = MODES[mode], S = surface(mode, pts), out = [], N = 24, i, j, line;
    for (j = 0; j < m.gy; j++) { line = []; for (i = 0; i <= N; i++) line.push(S(i / N, j / (m.gy - 1))); out.push(line); }
    for (i = 0; i < m.gx; i++) { line = []; for (j = 0; j <= N; j++) line.push(S(i / (m.gx - 1), j / N)); out.push(line); }
    return out;
  }

  window.ABSMesh = { MODES: MODES, identityPoints: identityPoints, isIdentity: isIdentity, surface: surface, bbox: bbox, render: render, guides: guides, homography: homography };
})();
