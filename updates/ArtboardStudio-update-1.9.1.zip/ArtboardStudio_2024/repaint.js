/* Artboard Studio first-open paint fix (CEP/Chromium).
   On the first open the panel's browser surface can be created hidden / 0x0 and never repainted
   until the panel is closed and reopened. This forces layout + repaint whenever the panel
   becomes visible, is resized, or receives focus, and during the first few seconds after load. */
(function () {
  'use strict';
  var lastW = -1, lastH = -1;
  function kick() {
    try {
      var de = document.documentElement, b = document.body;
      if (!de) return;
      // Force synchronous layout.
      void de.offsetHeight;
      // Force a compositor repaint by toggling a harmless style.
      var prev = de.style.opacity;
      de.style.opacity = '0.999';
      void de.offsetHeight;
      de.style.opacity = prev || '';
      if (b) { b.style.webkitTransform = 'translateZ(0)'; void b.offsetHeight; b.style.webkitTransform = ''; }
      var w = window.innerWidth, h = window.innerHeight;
      if (w !== lastW || h !== lastH) {
        lastW = w; lastH = h;
        try {
          var ev = document.createEvent('Event');
          ev.initEvent('resize', true, true);
          window.dispatchEvent(ev);
        } catch (e) {}
      }
    } catch (e) {}
  }
  var schedule = [0, 30, 80, 150, 300, 500, 800, 1200, 1800, 2600, 3600, 5000];
  for (var i = 0; i < schedule.length; i++) window.setTimeout(kick, schedule[i]);
  // Keep nudging until the panel reports a real size (covers a slow first open).
  var tries = 0;
  var timer = window.setInterval(function () {
    tries++;
    kick();
    if ((window.innerWidth > 100 && window.innerHeight > 100 && tries > 12) || tries > 60) window.clearInterval(timer);
  }, 250);
  window.addEventListener('load', kick);
  window.addEventListener('resize', function () { window.setTimeout(kick, 0); });
  window.addEventListener('focus', kick);
  window.addEventListener('pageshow', kick);
  document.addEventListener('DOMContentLoaded', kick);
  document.addEventListener('visibilitychange', kick);
  document.addEventListener('mouseover', function once() { kick(); document.removeEventListener('mouseover', once); });
}());
