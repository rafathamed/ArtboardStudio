/* Artboard Studio - in-panel dialogs (CEP panels do not reliably support window.confirm/alert).
   ABSDialog.confirm(msg, onOk)   ABSDialog.gate(key, msg, retry) -> true when already confirmed
   ABSDialog.block(title, msg)    non-dismissable notice (used after an update: restart Illustrator)
   ABSRestart.mark(version) / ABSRestart.check()  restart-required handling after auto-update */
(function () {
  'use strict';
  var ok = {}, el = null;
  function ensure() {
    if (el) return el;
    el = document.createElement('div'); el.className = 'abs-dialog hidden'; el.setAttribute('role', 'alertdialog');
    el.innerHTML = '<div class="abs-dialog-card"><h3 class="abs-dialog-title"></h3><div class="abs-dialog-msg"></div><div class="abs-dialog-actions"></div></div>';
    ['mousedown', 'mouseup', 'click', 'wheel', 'touchstart'].forEach(function (ev) { el.addEventListener(ev, function (e) { if (e.target === el) { e.preventDefault(); e.stopPropagation(); } }, true); });
    (document.body || document.documentElement).appendChild(el); return el;
  }
  function btn(text, cls, fn) { var b = document.createElement('button'); b.type = 'button'; b.className = 'abs-dialog-btn ' + cls; b.textContent = text; b.addEventListener('click', fn); return b; }
  function show(title, msg, buttons) {
    var d = ensure(); d.querySelector('.abs-dialog-title').textContent = title || '';
    d.querySelector('.abs-dialog-msg').textContent = msg || ''; var a = d.querySelector('.abs-dialog-actions'); a.innerHTML = '';
    buttons.forEach(function (b) { a.appendChild(b); }); d.classList.remove('hidden');
  }
  function hide() { if (el) el.classList.add('hidden'); }
  window.ABSDialog = {
    confirm: function (msg, onOk, opts) {
      opts = opts || {};
      show(opts.title || 'تأكيد', msg, [btn(opts.ok || 'متابعة', 'primary', function () { hide(); if (onOk) onOk(); }), btn(opts.cancel || 'إلغاء', '', hide)]);
    },
    gate: function (key, msg, retry, opts) {
      if (ok[key]) { ok[key] = false; return true; }
      window.ABSDialog.confirm(msg, function () { ok[key] = true; retry(); }, opts); return false;
    },
    block: function (title, msg) { show(title, msg, []); ensure().classList.add('abs-dialog-block'); },
    hide: hide
  };
  window.ABSRestart = {
    mark: function (version) {
      try { window.__adobe_cep__.evalScript("$.global.__ABS_RESTART_PENDING = '1'; 'OK'"); } catch (e) {}
      window.ABSDialog.block('تم تحديث Artboard Studio' + (version ? ' إلى ' + version : ''), 'برجاء إغلاق Illustrator وفتحه مرة أخرى حتى تتمكن الإضافة من العمل بسلاسة.\n\nلن تُفتح الإضافة إلا بعد إعادة تشغيل Illustrator.');
    },
    check: function () {
      try {
        window.__adobe_cep__.evalScript("typeof $.global.__ABS_RESTART_PENDING", function (r) {
          if (String(r) === 'string') window.ABSDialog.block('إعادة تشغيل Illustrator مطلوبة', 'تم تحديث الإضافة. برجاء إغلاق Illustrator وفتحه مرة أخرى حتى تتمكن الإضافة من العمل بسلاسة.\n\nلن تُفتح الإضافة إلا بعد إعادة التشغيل.');
        });
      } catch (e) {}
    }
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', window.ABSRestart.check); else window.ABSRestart.check();
})();
