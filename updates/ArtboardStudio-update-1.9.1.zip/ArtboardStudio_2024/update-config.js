/* Updater settings. The public key verifies update packages signed with your private key (never put the private key here). */
window.ARTBOARD_STUDIO_UPDATE = {
  versionUrl: 'https://rafathamed.github.io/ArtboardStudio/version.json',
  allowedPrefix: 'https://rafathamed.github.io/ArtboardStudio/',
  maxZipBytes: 8388608,
  publicKey: {"kty": "EC", "crv": "P-256", "x": "rmMEWkRa5zTuXRzHUbficDdYOLSAr_S9-9NteDcmPQs", "y": "I2VXEyWSzwh-Y3CTu_vp_2S7xITrjE1GtvLbRMqL0XY"}
};
