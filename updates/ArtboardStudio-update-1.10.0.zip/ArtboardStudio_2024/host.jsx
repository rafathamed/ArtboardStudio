// Artboard Studio - protected package. The real host script is loaded after the integrity check.
