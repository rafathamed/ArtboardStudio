# Artboard Studio — Illustrator 2024 على macOS

## التثبيت
1. فك الضغط عن الملف **على الماك** (يفضّل بالنقر المزدوج على الـ zip من Finder).
2. افتح مجلد `Illustrator_2024`.
3. انقر **كليك يمين** على `Install_Illustrator_2024.command` ثم **Open** ثم **Open** مرة أخرى (أول مرة فقط بسبب حماية macOS).
4. أغلق Illustrator تمامًا (Cmd+Q) ثم افتحه من جديد.
5. من القائمة: **Window ‹ Extensions (Legacy) ‹ Artboard Studio 2024**.

## إذا لم يعمل الملف .command
افتح Terminal ونفّذ:
```
cd ~/Downloads/<مسار المجلد>/Illustrator_2024
chmod +x *.command
./Install_Illustrator_2024.command
```

## يدويًا (بدون سكربت)
- انسخ المجلد `ArtboardStudio_2024` إلى:
  `~/Library/Application Support/Adobe/CEP/extensions/com.rafat.artboardstudio.ai2024`
  (للوصول: Finder ‹ Go ‹ Go to Folder، والصق مسار `~/Library/Application Support/Adobe/CEP`)
- في Terminal:  ; defaults write com.adobe.CSXS.11 PlayerDebugMode 1

## الإزالة
شغّل `Uninstall_Illustrator_2024.command`.

## ملاحظات
- الإضافة تحتاج اتصال إنترنت لتفعيل السريال أول مرة.
- لم تُختبر داخل Illustrator على ماك في بيئة البناء.


## حماية الملفات والتفعيل
- قبل تحميل الأدوات، تتحقق الإضافة من بصمات SHA-256 للملفات الأساسية، ومنها واجهة التفعيل وملفات JavaScript وCSS وملفات ExtendScript وملف manifest.
- إذا كان أي ملف أساسي مفقودًا أو تغير محتواه، تتوقف الإضافة ولا تحمّل أدواتها، وتطلب إعادة تثبيت الحزمة الأصلية كاملةً.
- لا تُحمّل وظائف Illustrator إلا بعد نجاح التحقق من الترخيص عبر خادم Artboard Studio واكتمال فحص الملفات.
- التحديثات المستقبلية يجب أن تتضمن integrity.js وكل الملفات الأساسية، ويجري التحقق من حزمة التحديث الموقعة قبل تثبيتها.
- **ملاحظة أمنية:** هذه طبقة كشف عبث ومنع تجاوز عادي، وليست حماية مطلقة من الهندسة العكسية؛ فـCEP يعتمد على ملفات عميل محلية ويمكن لمهاجم خبير تعديل نقطة بدء التشغيل أو بيئة Illustrator. حماية أقوى ضد النسخ والتعديل تتطلب نقل الوظائف الحساسة إلى مكوّن Native موقّع أو بنية UXP/مكوّن أصلي، مع بقاء التفعيل والتحقق على الخادم.
