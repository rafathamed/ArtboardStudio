(function () {
  'use strict';
  var config = window.ARTBOARD_STUDIO_LICENSE_CONFIG || {};
  window.ArtboardStudioLicensed = false;
  window.ArtboardStudioLicenseVerified = false;
  var baseUrl = String(config.serverUrl || '').replace(/\/+$/, '');
  var product = config.product || 'artboard-studio';
  var TOKEN_KEY = 'artboardStudio.licenseToken.v1';
  var DEVICE_KEY = 'artboardStudio.deviceId.v1';
  var $ = function (id) { return document.getElementById(id); };

  function status(message, kind) {
    var el = $('licenseStatus');
    if (!el) return;
    el.className = 'license-status' + (kind ? ' ' + kind : '');
    el.textContent = message;
  }
  function isLocalServer() {
    return /^https?:\/\/(127\.0\.0\.1|localhost)(:\d+)?$/i.test(baseUrl);
  }
  function serverHint() {
    var el = $('licenseServerHint');
    if (el) el.textContent = 'Server: ' + (baseUrl || 'لم يتم ضبط الرابط');
  }
  function connectionHelp() {
    if (isLocalServer()) {
      return 'خادم التفعيل المحلي غير متاح. شغّل start_windows.bat من مجلد Licensing_Admin\\server على نفس الكمبيوتر، واترك نافذة الخادم مفتوحة. ثم اختبر: ' + baseUrl + '/health';
    }
    return 'تعذّر الوصول إلى خادم التفعيل. تأكد من صحة رابط الخادم، وأنه يعمل عبر HTTPS، وأن المسار /health متاح.';
  }
  function randomId() {
    var bytes = new Uint8Array(16);
    try {
      if (window.crypto && window.crypto.getRandomValues) window.crypto.getRandomValues(bytes);
      else throw new Error('no crypto');
      var out = '';
      for (var i = 0; i < bytes.length; i++) out += ('0' + bytes[i].toString(16)).slice(-2);
      return out;
    } catch (e) {
      return String(new Date().getTime()) + '-' + String(Math.random()).slice(2) + '-' + String(Math.random()).slice(2);
    }
  }
  function deviceId() {
    try {
      var existing = localStorage.getItem(DEVICE_KEY);
      if (existing) return existing;
      var created = randomId();
      localStorage.setItem(DEVICE_KEY, created);
      return created;
    } catch (e) { return randomId(); }
  }
  function request(path, payload, callback) {
    if (!baseUrl || baseUrl.indexOf('YOUR_') >= 0) {
      callback(new Error('لم يتم إعداد رابط خادم التفعيل. راجع ملف license-config.js.'));
      return;
    }
    var xhr = new XMLHttpRequest();
    xhr.open('POST', baseUrl + path, true);
    xhr.timeout = 10000;
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onreadystatechange = function () {
      if (xhr.readyState !== 4) return;
      var data = {};
      try { data = JSON.parse(xhr.responseText || '{}'); } catch (e) {}
      if (xhr.status >= 200 && xhr.status < 300 && data.ok) callback(null, data);
      else if (xhr.status === 0) callback(new Error(connectionHelp()));
      else callback(new Error(data.message || ('تعذّر التحقق من السريال (HTTP ' + xhr.status + '). تحقق من مسارات API في الخادم.')));
    };
    xhr.onerror = function () { callback(new Error(connectionHelp())); };
    xhr.ontimeout = function () { callback(new Error('انتهت مهلة الاتصال بخادم التفعيل بعد 10 ثوانٍ. ' + connectionHelp())); };
    try { xhr.send(JSON.stringify(payload)); }
    catch (e) { callback(new Error('تعذّر إرسال طلب التفعيل: ' + (e.message || e))); }
  }
  function healthCheck() {
    var button = $('checkLicenseServer');
    if (button) button.disabled = true;
    status('جارٍ اختبار الاتصال بخادم التفعيل…', '');
    if (!baseUrl) {
      status('رابط خادم التفعيل غير مضبوط. راجع license-config.js.', 'error');
      if (button) button.disabled = false;
      return;
    }
    var xhr = new XMLHttpRequest();
    xhr.open('GET', baseUrl + '/health', true);
    xhr.timeout = 8000;
    xhr.onreadystatechange = function () {
      if (xhr.readyState !== 4) return;
      if (button) button.disabled = false;
      var data = {};
      try { data = JSON.parse(xhr.responseText || '{}'); } catch (e) {}
      if (xhr.status >= 200 && xhr.status < 300 && data.ok && data.product === product) {
        status('الاتصال ناجح. خادم Artboard Studio يعمل ويمكن متابعة التفعيل.', 'success');
      } else if (xhr.status === 0) {
        status(connectionHelp(), 'error');
      } else {
        status('تم الوصول إلى العنوان لكن استجابة الخادم غير صحيحة (HTTP ' + xhr.status + '). تأكد أنك تستخدم خادم Artboard Studio الصحيح.', 'error');
      }
    };
    xhr.onerror = function () {
      if (button) button.disabled = false;
      status(connectionHelp(), 'error');
    };
    xhr.ontimeout = function () {
      if (button) button.disabled = false;
      status('انتهت مهلة اختبار الخادم. ' + connectionHelp(), 'error');
    };
    try { xhr.send(null); }
    catch (e) {
      if (button) button.disabled = false;
      status('تعذّر بدء اختبار الاتصال: ' + (e.message || e), 'error');
    }
  }
  function showApp(token) {
    token = String(token || '');
    if (!token) { status('الخادم لم يُرجع رمز ترخيص صالحًا. أعد المحاولة.', 'error'); return; }
    try { localStorage.setItem(TOKEN_KEY, token); } catch (e) {}
    // This flag means the server accepted the license. It does not unlock the UI
    // until the integrity bootstrap has also loaded every verified runtime file.
    window.ArtboardStudioLicenseVerified = true;
    if (typeof window.ArtboardStudioUnlockAfterLicense !== 'function') {
      status('تعذّر بدء مكونات الإضافة المحمية. أعد تثبيت النسخة الأصلية.', 'error');
      return;
    }
    window.ArtboardStudioUnlockAfterLicense();
  }

  function dismissBootSplash() { var splash = $('bootSplash'); if (splash) splash.classList.add('hidden'); }

  function ensureStartupSurface() {
    var gate = $('licenseGate'), app = $('appRoot');
    if (window.ArtboardStudioLicensed) {
      if (gate) gate.classList.add('hidden');
      if (app) app.classList.remove('hidden');
    } else {
      if (app) app.classList.add('hidden');
      if (gate) gate.classList.remove('hidden');
    }
    dismissBootSplash();
  }

  function verifyCached() {
    var token = '';
    try { token = localStorage.getItem(TOKEN_KEY) || ''; } catch (e) {}
    if (!token) {
      status('أدخل السريال ثم اضغط تفعيل. استخدم اختبار الاتصال عند ظهور مشكلة في الخادم.', '');
      return;
    }
    status('جارٍ التحقق من الترخيص…', '');
    request('/api/verify', { token: token, deviceId: deviceId(), product: product }, function (err, result) {
      if (err) { status(err.message, 'error'); return; }
      showApp(result.token || token);
    });
  }
  function activate() {
    var button = $('activateLicense');
    var input = $('licenseKey');
    var key = String(input && input.value || '').toUpperCase().replace(/\s+/g, '');
    if (!key) { status('أدخل سريال التفعيل أولًا.', 'error'); return; }
    if (!/^AS26-(?:[A-Z2-9]{4}-){5}[A-Z2-9]{4}$/.test(key)) {
      status('صيغة السريال غير صحيحة. تأكد من نسخه كاملًا.', 'error'); return;
    }
    if (button) button.disabled = true;
    status('جارٍ تفعيل السريال وربطه بهذا الجهاز…', '');
    request('/api/activate', { key: key, deviceId: deviceId(), product: product, build: window.ARTBOARD_STUDIO_BUILD || '1.9.1' }, function (err, result) {
      if (button) button.disabled = false;
      if (err) { status(err.message, 'error'); return; }
      status('تم تفعيل Artboard Studio بنجاح.', 'success');
      showApp(result.token);
    });
  }
  function init() {
    var activateButton = $('activateLicense');
    if (activateButton) activateButton.addEventListener('click', activate);
    var healthButton = $('checkLicenseServer');
    if (healthButton) healthButton.addEventListener('click', healthCheck);
    var purchaseLink = $('purchaseWhatsApp');
    if (purchaseLink) purchaseLink.addEventListener('click', function (event) {
      event.preventDefault();
      var targetUrl = this.getAttribute('href');
      try {
        if (window.cep && window.cep.util && typeof window.cep.util.openURLInDefaultBrowser === 'function') {
          window.cep.util.openURLInDefaultBrowser(targetUrl); return;
        }
      } catch (e) {}
      window.open(targetUrl, '_blank');
    });
    var keyInput = $('licenseKey');
    if (keyInput) keyInput.addEventListener('keydown', function (event) { if (event.key === 'Enter') activate(); });
    serverHint();
    ensureStartupSurface();
    // Let the HTML panel paint before contacting the licensing server.
    window.setTimeout(verifyCached, 220);
    window.setTimeout(ensureStartupSurface, 1200);
    window.addEventListener('pageshow', function () { ensureStartupSurface(); });
  }
  var licenseInitialized = false;
  function startLicense() {
    if (licenseInitialized) return;
    licenseInitialized = true;
    init();
  }
  if (document.readyState === 'complete') startLicense();
  else {
    window.addEventListener('load', startLicense);
    document.addEventListener('DOMContentLoaded', function () { window.setTimeout(startLicense, 80); });
    window.setTimeout(startLicense, 900);
  }
}());
