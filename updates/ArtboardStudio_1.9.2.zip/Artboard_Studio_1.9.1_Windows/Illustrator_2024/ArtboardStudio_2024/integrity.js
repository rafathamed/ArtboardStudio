/* Artboard Studio local integrity gate. The bootstrap in index.html pins this file. */
(function () {
  'use strict';
  var INTEGRITY_PIN = '__INTEGRITY_PIN__';
  var FILE_HASHES = {"CSXS/manifest.xml":"e145b88d34f4bce8ec9d3805c86b1dc915c400a94d53a4d9588cde36038d36db","app.js":"d135a66bb8a0a9345c87f60248c5e856167a161eeb0d54b91368b82a4792d609","camera-raw-ui.js":"afe12f51af89dd9404a0cbd4852ffe8fdfc91304bc17da6e0a95928e287df01a","camera-raw.js":"2fe328720a3c2246436a0bd05d6f0d9735298474e2fe79fc147341c5a3e436a8","host.jsx":"e4a4e7e0cc53ceb9c0c92580bfa2a38ea9b8383865c5dd7922750c5046076ac9","host/host.jsx":"e4a4e7e0cc53ceb9c0c92580bfa2a38ea9b8383865c5dd7922750c5046076ac9","index.html":"ba76b8ba3909be6a2104696a11ec5d2221ea5739b51aa27b17d2f5d289362bc9","license-config.js":"05831a73e4515f2ddbf895e9be8207ef6c08525d93323866b639b6b7e4394c02","license.js":"db509eaeea7f37a86092bf48a49e7f743edddb71098d00f5435712a18204765f","mesh-warp.js":"63b47b3db11040e0539d908f8846cdee99c4445b4769c7a10495552ac815ff41","qr.js":"0953101bca0809a862c24970868e8f1eb89f2fe1f3488e1a8bdb70954b93a7d1","repaint.js":"76b75efa5de314b574bca74906d60cf55d79f3b65386d84898ee1eceecd93cf3","styles.css":"27aa52c05b3df5b4a2b38fabfc3cb8af20e4364f834558299c4b9cf1824ea412","transform-ui.js":"02905fbcafb18f179ed1c191c940251649e6f3ecac0b41337f23cb2d61d5b22a","update-config.js":"01669a1d6c65ee7e734b1f81598689d040cecd3bbce8c93feff06253f62ab55b","update.js":"7f11cd5505cc172c635ab7c70b347469a1bb461d39a14c3ac729207cc85e27e5","version.js":"5e9344b961de7838d4d4a855fad62516f5c7435fd63f0958d0e95efdf02e994d"};
  var root = '';
  var failure = false;
  var $ = function (id) { return document.getElementById(id); };

  window.ArtboardStudioIntegrityOK = false;
  window.ArtboardStudioLicensed = false;
  window.ArtboardStudioLicenseVerified = false;
  window.ArtboardStudioRuntimeReady = false;

  function fail(reason) {
    if (failure) return;
    failure = true;
    window.ArtboardStudioIntegrityOK = false;
    window.ArtboardStudioLicensed = false;
    window.ArtboardStudioRuntimeReady = false;
    var app = $('appRoot'); if (app) app.style.display = 'none';
    var gate = $('licenseGate'); if (gate) gate.classList.add('hidden');
    var overlay = $('integrityFailure');
    if (!overlay) {
      overlay = document.createElement('div'); overlay.id = 'integrityFailure';
      overlay.style.cssText = 'position:fixed;inset:0;z-index:100000;background:#171717;color:#f4f4f4;display:flex;align-items:center;justify-content:center;padding:22px;font:14px/1.8 Tahoma,Arial,sans-serif;text-align:center;direction:rtl;';
      var card = document.createElement('div'); card.style.cssText = 'max-width:520px;border:1px solid #754641;border-radius:12px;background:#262626;padding:24px;box-shadow:0 16px 50px #0008;';
      var h = document.createElement('h2'); h.textContent = 'تم إيقاف Artboard Studio لحماية الملفات'; h.style.cssText = 'margin:0 0 12px;color:#ffb9ae;font-size:19px;';
      var p = document.createElement('p'); p.id = 'integrityFailureReason'; p.style.cssText = 'margin:0;color:#ddd;';
      var small = document.createElement('p'); small.textContent = 'اكتُشف ملف مفقود أو تم تعديله. لم يتم تحميل أي أداة. أعد تثبيت النسخة الأصلية كاملةً ولا تستبدل ملفات الإضافة يدويًا.'; small.style.cssText = 'margin:14px 0 0;color:#aaa;font-size:12px;';
      card.appendChild(h); card.appendChild(p); card.appendChild(small); overlay.appendChild(card); document.body.appendChild(overlay);
    }
    var target = $('integrityFailureReason'); if (target) target.textContent = reason || 'فشل فحص سلامة الملفات.';
  }

  function readFile(rel) {
    if (!window.cep || !window.cep.fs || typeof window.cep.fs.readFile !== 'function') throw new Error('واجهة قراءة ملفات CEP غير متاحة.');
    var result = window.cep.fs.readFile(root.replace(/[\\/]$/, '') + '/' + rel);
    if (!result || result.err !== 0 || typeof result.data !== 'string') throw new Error('ملف مفقود أو غير قابل للقراءة: ' + rel);
    return result.data;
  }

  function digest(text) {
    if (!window.crypto || !window.crypto.subtle || typeof TextEncoder === 'undefined') return Promise.reject(new Error('التحقق الرقمي SHA-256 غير مدعوم في إصدار CEP الحالي.'));
    return window.crypto.subtle.digest('SHA-256', new TextEncoder().encode(text)).then(function (buffer) {
      var bytes = new Uint8Array(buffer), out = '';
      for (var i = 0; i < bytes.length; i++) out += ('0' + bytes[i].toString(16)).slice(-2);
      return out;
    });
  }

  function verifyOne(rel) {
    var content;
    try { content = readFile(rel); } catch (e) { return Promise.reject(e); }
    if (rel === 'index.html') content = content.replace(/var INTEGRITY_PIN = '[0-9a-f]{64}';/, "var INTEGRITY_PIN = '__INTEGRITY_PIN__';")
    return digest(content).then(function (actual) {
      if (actual.toLowerCase() !== String(FILE_HASHES[rel] || '').toLowerCase()) throw new Error('تم حذف أو تعديل الملف: ' + rel);
      return true;
    });
  }

  function loadScript(rel) {
    return new Promise(function (resolve, reject) {
      var script = document.createElement('script'); script.src = rel;
      script.onload = function () { resolve(); };
      script.onerror = function () { reject(new Error('تعذّر تحميل ملف تشغيل: ' + rel)); };
      document.body.appendChild(script);
    });
  }

  function loadInOrder(list) {
    var chain = Promise.resolve();
    list.forEach(function (rel) { chain = chain.then(function () { return loadScript(rel); }); });
    return chain;
  }


  function grantHostLicense(attempt) {
    attempt = attempt || 0;
    return new Promise(function (resolve, reject) {
      var api = window.__adobe_cep__;
      if (!api || typeof api.evalScript !== 'function') {
        if (attempt < 12) { window.setTimeout(function () { grantHostLicense(attempt + 1).then(resolve, reject); }, 250); return; }
        reject(new Error('تعذّر الوصول إلى محرك ExtendScript الخاص بـ Illustrator.'));
        return;
      }
      try {
        api.evalScript('AIArtboardStudio._setLicenseReady(true)', function (result) {
          result = String(result || '');
          if (result.indexOf('OK|') === 0) resolve();
          else reject(new Error('رفض محرك Illustrator فتح قناة التنفيذ: ' + (result || 'لا توجد استجابة')));
        });
      } catch (e) { reject(new Error('تعذّر فتح قناة التنفيذ داخل Illustrator: ' + (e.message || e))); }
    });
  }

  function finishUnlock() {
    if (failure || !window.ArtboardStudioIntegrityOK || !window.ArtboardStudioLicenseVerified || window.ArtboardStudioRuntimeReady) return;
    window.ArtboardStudioUnlockAfterLicense = function () {
      if (failure || !window.ArtboardStudioIntegrityOK || !window.ArtboardStudioLicenseVerified || window.ArtboardStudioRuntimeReady) return;
      loadInOrder(['qr.js', 'app.js', 'camera-raw.js', 'camera-raw-ui.js', 'mesh-warp.js', 'transform-ui.js', 'update-config.js', 'update.js']).then(function () {
        if (failure) throw new Error('تم إيقاف التحميل أثناء التحقق.');
        return grantHostLicense(0);
      }).then(function () {
        if (failure) return;
        window.ArtboardStudioRuntimeReady = true;
        window.ArtboardStudioLicensed = true;
        var app = $('appRoot'), gate = $('licenseGate'), splash = $('bootSplash');
        if (gate) gate.classList.add('hidden');
        if (app) { app.style.display = ''; app.classList.remove('hidden'); }
        if (splash) splash.classList.add('hidden');
        try { window.dispatchEvent(new Event('artboardstudio:runtime-ready')); } catch (e) {
          var evt = document.createEvent('Event'); evt.initEvent('artboardstudio:runtime-ready', true, true); window.dispatchEvent(evt);
        }
        window.setTimeout(function () { if (window.ArtboardStudioRefresh) window.ArtboardStudioRefresh(); }, 250);
      }).catch(function (e) { fail(e && e.message ? e.message : 'فشل تحميل مكونات الإضافة المحمية.'); });
    };
    if (window.ArtboardStudioLicenseVerified) window.ArtboardStudioUnlockAfterLicense();
  }

  try {
    if (!window.cep || !window.cep.fs || typeof window.cep.fs.readFile !== 'function') throw new Error('واجهة ملفات CEP غير متاحة.');
    var href = decodeURIComponent(String(location.href).split('#')[0].split('?')[0]);
    if (href.indexOf('file://') !== 0) throw new Error('تعذّر تحديد مجلد الإضافة من مسار اللوحة.');
    href = href.replace(/^file:\/\/\/?/, '');
    if (!/^[A-Za-z]:/.test(href)) href = '/' + href.replace(/^\/+/, '');
    root = href.replace(/\/[^\/]*$/, '');
    if (!root) throw new Error('مسار الإضافة غير متاح.');
    var keys = Object.keys(FILE_HASHES);
    var checks = keys.map(verifyOne);
    Promise.all(checks).then(function () {
      if (failure) return;
      window.ArtboardStudioIntegrityOK = true;
      return loadInOrder(['repaint.js', 'version.js', 'license-config.js', 'license.js']);
    }).then(function () {
      if (failure || !window.ArtboardStudioIntegrityOK) return;
      finishUnlock();
    }).catch(function (e) { fail(e && e.message ? e.message : 'فشل فحص سلامة ملفات الإضافة.'); });
  } catch (e) { fail(e && e.message ? e.message : 'فشل بدء فحص سلامة الملفات.'); }
}());
