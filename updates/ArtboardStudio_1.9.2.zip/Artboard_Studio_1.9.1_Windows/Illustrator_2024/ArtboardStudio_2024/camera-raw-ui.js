/* Artboard Studio - "تعديل الصور" tab (Camera-Raw-style editing for images in Illustrator).
   Flow: selected image -> exported to a temp PNG (no extra window when the host supports it) ->
   every change is rendered at preview size and pushed to a linked placeholder ON the artwork
   (single-flight, latest-wins) -> after release a sharper settled frame is pushed ->
   "apply" renders full resolution and places it back. */
(function () {
  'use strict';
  var E = window.ABSCameraRaw;
  if (!E) return;
  var $ = function (id) { return document.getElementById(id); };

  var PREVIEW_MAX = 640, LIVE_HI = 1400, PROXY_MAX = 1400, SETTLE_MS = 260;
  var state = { info: null, full: null, prevCtx: null, prevSrc: null, params: E.defaults(), busy: false, mixMode: 'hue', rafPending: false, live: null, hiCtx: null, comparing: false, settleTimer: 0 };
  var rows = [];      // {key, idx, input, output, row, def, fmt}
  var mixRows = [];

  var SCHEMA = [
    { id: 'light', title: 'الضوء', open: true, items: [
      ['exposure', 'التعريض', -5, 5, 0.05, 0, 'ev'], ['contrast', 'التباين', -100, 100, 1, 0],
      ['highlights', 'الإضاءات العالية', -100, 100, 1, 0], ['shadows', 'الظلال', -100, 100, 1, 0],
      ['whites', 'الأبيض', -100, 100, 1, 0], ['blacks', 'الأسود', -100, 100, 1, 0] ] },
    { id: 'color', title: 'اللون', open: true, items: [
      ['temp', 'حرارة اللون', -100, 100, 1, 0, '', 'cr-temp'], ['tint', 'الصبغة', -100, 100, 1, 0, '', 'cr-tint'],
      ['vibrance', 'الحيوية', -100, 100, 1, 0], ['saturation', 'التشبع', -100, 100, 1, 0] ] },
    { id: 'mixer', title: 'خلاط الألوان', open: false, mixer: true },
    { id: 'effects', title: 'التأثيرات', open: false, items: [
      ['texture', 'الملمس', -100, 100, 1, 0], ['clarity', 'الوضوح', -100, 100, 1, 0], ['dehaze', 'إزالة الضباب', -100, 100, 1, 0],
      ['vignette', 'تظليل الحواف', -100, 100, 1, 0], ['vigMid', 'منتصف التظليل', 0, 100, 1, 50], ['vigFeather', 'نعومة التظليل', 0, 100, 1, 50],
      ['grain', 'الحبيبات', 0, 100, 1, 0], ['grainSize', 'حجم الحبيبات', 0, 100, 1, 25] ] },
    { id: 'detail', title: 'التفاصيل', open: false, items: [
      ['sharpen', 'الحدّة', 0, 150, 1, 0], ['sharpenRadius', 'نصف القطر', 0.5, 3, 0.1, 1, 'dec1'],
      ['nrLum', 'تقليل الضوضاء (السطوع)', 0, 100, 1, 0], ['nrColor', 'تقليل الضوضاء (اللون)', 0, 100, 1, 0] ] }
  ];
  var BANDS = [['الأحمر', '#e5484d'], ['البرتقالي', '#f08a24'], ['الأصفر', '#e8c21a'], ['الأخضر', '#3fb950'],
               ['السماوي', '#1fc2c2'], ['الأزرق', '#3b82f6'], ['البنفسجي', '#8b5cf6'], ['الأرجواني', '#d946ef']];

  function fmt(v, kind) {
    if (kind === 'ev') return (v > 0 ? '+' : '') + v.toFixed(2);
    if (kind === 'dec1') return v.toFixed(1);
    return (v > 0 ? '+' : '') + Math.round(v);
  }
  function status(msg, type) {
    var el = $('crStatus'); if (!el) return;
    el.className = 'cr-status' + (type ? ' ' + type : ''); el.textContent = msg || '';
  }
  function hostApi() { return window.__adobe_cep__ && typeof window.__adobe_cep__.evalScript === 'function' ? window.__adobe_cep__ : null; }
  function hostEval(expr, cb) {
    if (!window.ArtboardStudioIntegrityOK || !window.ArtboardStudioLicensed || !window.ArtboardStudioRuntimeReady) {
      if (cb) cb(false, 'الأدوات مقفلة حتى اكتمال التحقق من الترخيص وسلامة الملفات.');
      return;
    }
    var api = hostApi();
    if (!api) { cb(false, 'لوحة Illustrator غير جاهزة بعد.'); return; }
    try {
      api.evalScript(expr, function (res) {
        res = String(res || '');
        var ok = res.indexOf('OK|') === 0, body = res.indexOf('|') >= 0 ? res.substring(res.indexOf('|') + 1) : res;
        cb(ok, body);
      });
    } catch (e) { cb(false, e.message || String(e)); }
  }

  /* ---------- blocking "please wait" overlay (looks like Illustrator's export dialog) ---------- */
  (function () {
    window.ABSSession = window.ABSSession || { owner: null };
    if (window.ABSBusy) return;
    var el = null, depth = 0;
    function build() {
      el = document.createElement('div'); el.className = 'abs-busy hidden'; el.setAttribute('role', 'alertdialog'); el.setAttribute('aria-live', 'assertive');
      el.innerHTML = '<div class="abs-busy-box"><div class="abs-busy-title">Artboard Studio</div><div class="abs-busy-msg" id="absBusyMsg"></div><div class="abs-busy-bar"><i></i></div><div class="abs-busy-hint">الرجاء الانتظار… لا يمكن استخدام الأدوات حتى ينتهي</div></div>';
      ['mousedown', 'mouseup', 'click', 'dblclick', 'contextmenu', 'wheel', 'touchstart'].forEach(function (ev) { el.addEventListener(ev, function (e) { e.preventDefault(); e.stopPropagation(); }, true); });
      document.body.appendChild(el);
    }
    function trap(e) { if (e.target && el && el.contains(e.target)) return; e.preventDefault(); e.stopPropagation(); }
    window.ABSBusy = {
      show: function (msg) { if (!el) build(); depth++; document.getElementById('absBusyMsg').textContent = msg || 'جارٍ التحميل…'; el.classList.remove('hidden'); document.body.classList.add('abs-is-busy'); window.addEventListener('keydown', trap, true); try { if (document.activeElement && document.activeElement.blur) document.activeElement.blur(); } catch (e) {} },
      hide: function () { depth = 0; if (!el) return; el.classList.add('hidden'); document.body.classList.remove('abs-is-busy'); window.removeEventListener('keydown', trap, true); },
      isOn: function () { return !!el && !el.classList.contains('hidden'); }
    };
  })();

  function jsq(str) { // ASCII-only JS string literal (safe through the evalScript text channel)
    return JSON.stringify(String(str)).replace(/[\u007f-\uffff]/g, function (c) { return '\\u' + ('0000' + c.charCodeAt(0).toString(16)).slice(-4); });
  }
  function fsOk() { return window.cep && window.cep.fs && window.cep.encoding; }

  /* ---------- UI construction ---------- */
  function buildRow(container, key, label, min, max, step, def, kind, cls, arrKey, idx, color) {
    var row = document.createElement('div'); row.className = 'cr-row' + (cls ? ' ' + cls : '');
    var lab = document.createElement('label'); lab.textContent = label;
    if (color) { var dot = document.createElement('i'); dot.className = 'cr-dot'; dot.style.background = color; lab.insertBefore(dot, lab.firstChild); }
    var input = document.createElement('input'); input.type = 'range'; input.min = min; input.max = max; input.step = step; input.value = def; input.setAttribute('dir', 'ltr');
    input.setAttribute('aria-label', label);
    var out = document.createElement('output'); out.textContent = fmt(def, kind);
    row.appendChild(lab); row.appendChild(input); row.appendChild(out); container.appendChild(row);
    var rec = { key: key, arrKey: arrKey, idx: idx, input: input, output: out, row: row, def: def, kind: kind };
    function setFromInput() {
      var v = parseFloat(input.value);
      if (arrKey) state.params[arrKey][idx] = v; else state.params[key] = v;
      out.textContent = fmt(v, kind); row.classList.toggle('changed', v !== def);
      schedule();
    }
    input.addEventListener('input', setFromInput);
    var reset = function () { input.value = def; setFromInput(); };
    lab.addEventListener('dblclick', reset); out.addEventListener('dblclick', reset);
    return rec;
  }

  function buildUI() {
    var host = $('crSections'); if (!host || host.getAttribute('data-built')) return;
    host.setAttribute('data-built', '1');
    SCHEMA.forEach(function (sec) {
      var d = document.createElement('details'); d.className = 'cr-sec'; if (sec.open) d.open = true;
      var sum = document.createElement('summary'); sum.textContent = sec.title; d.appendChild(sum);
      var body = document.createElement('div'); body.className = 'cr-sec-body'; d.appendChild(body);
      if (sec.mixer) buildMixer(body);
      else sec.items.forEach(function (it) { rows.push(buildRow(body, it[0], it[1], it[2], it[3], it[4], it[5], it[6] || '', it[7] || '')); });
      host.appendChild(d);
    });
  }

  function buildMixer(body) {
    var seg = document.createElement('div'); seg.className = 'cr-seg';
    [['hue', 'درجة اللون'], ['sat', 'التشبع'], ['lum', 'السطوع']].forEach(function (m) {
      var b = document.createElement('button'); b.type = 'button'; b.textContent = m[1]; b.setAttribute('data-mode', m[0]);
      if (m[0] === state.mixMode) b.className = 'active';
      b.addEventListener('click', function () { state.mixMode = m[0]; refreshMixer(); });
      seg.appendChild(b);
    });
    body.appendChild(seg);
    var bw = document.createElement('label'); bw.className = 'cr-check';
    var cb = document.createElement('input'); cb.type = 'checkbox'; cb.id = 'crBw';
    cb.addEventListener('change', function () { state.params.bw = cb.checked; schedule(); });
    bw.appendChild(cb); bw.appendChild(document.createTextNode(' أبيض وأسود (السطوع يتحكم بدرجات الرمادي لكل لون)'));
    body.appendChild(bw);
    var wrap = document.createElement('div'); wrap.id = 'crMixRows'; body.appendChild(wrap);
    refreshMixer();
  }

  function refreshMixer() {
    var wrap = $('crMixRows'); if (!wrap) return;
    var seg = wrap.parentNode.querySelectorAll('.cr-seg button');
    for (var i = 0; i < seg.length; i++) seg[i].classList.toggle('active', seg[i].getAttribute('data-mode') === state.mixMode);
    wrap.innerHTML = ''; mixRows = [];
    for (var b = 0; b < 8; b++) {
      var rec = buildRow(wrap, state.mixMode, BANDS[b][0], -100, 100, 1, 0, '', '', state.mixMode, b, BANDS[b][1]);
      rec.input.value = state.params[state.mixMode][b]; rec.output.textContent = fmt(state.params[state.mixMode][b], '');
      rec.row.classList.toggle('changed', state.params[state.mixMode][b] !== 0);
      mixRows.push(rec);
    }
  }

  function syncUI() { // push state.params into all controls
    rows.forEach(function (r) {
      var v = state.params[r.key]; r.input.value = v; r.output.textContent = fmt(v, r.kind); r.row.classList.toggle('changed', v !== r.def);
    });
    refreshMixer();
    var cb = $('crBw'); if (cb) cb.checked = !!state.params.bw;
  }

  /* ---------- rendering ---------- */
  function schedule() {
    if (!state.prevCtx) return;
    window.clearTimeout(state.settleTimer);
    state.settleTimer = window.setTimeout(settle, SETTLE_MS);
    if (state.rafPending) return;
    state.rafPending = true;
    (window.requestAnimationFrame || window.setTimeout)(function () { state.rafPending = false; render(); });
  }

  function render() {
    if (!state.prevCtx) return;
    var c = $('crPreview'), g = c.getContext('2d'), w = state.prevCtx.w, h = state.prevCtx.h;
    var out = E.process(state.prevCtx, state.params);
    var img = g.createImageData(w, h); img.data.set(out); g.putImageData(img, 0, 0);
    drawHistogram(out);
    if (!state.comparing) sendFrame(out, w, h);
  }

  /* sharper frame for the artwork once the user stops dragging */
  function settle() {
    var L = state.live;
    if (!L || !L.on || !state.full || state.comparing) return;
    var full = state.full, fm = Math.max(full.width, full.height);
    if (fm <= PREVIEW_MAX * 1.15) return;
    if (!state.hiCtx) {
      var f = Math.min(1, LIVE_HI / fm), hw = Math.max(1, Math.round(full.width * f)), hh = Math.max(1, Math.round(full.height * f));
      var a = document.createElement('canvas'); a.width = full.width; a.height = full.height; a.getContext('2d').putImageData(full, 0, 0);
      var b = document.createElement('canvas'); b.width = hw; b.height = hh;
      var bg = b.getContext('2d'); bg.imageSmoothingQuality = 'high'; bg.drawImage(a, 0, 0, hw, hh);
      state.hiCtx = E.createContext(bg.getImageData(0, 0, hw, hh), { fullMax: fm });
    }
    sendFrame(E.process(state.hiCtx, state.params), state.hiCtx.w, state.hiCtx.h);
  }

  /* ---------- live frames on the artwork ---------- */
  function tmpDir() { var p = state.info.outPath, i = Math.max(p.lastIndexOf('\\'), p.lastIndexOf('/')); return { dir: p.substring(0, i), sep: p.charAt(i) }; }
  function writeFrame(rgba, w, h) {
    var L = state.live, cv = L.cv || (L.cv = document.createElement('canvas')); cv.width = w; cv.height = h;
    cv.getContext('2d').putImageData(new ImageData(rgba, w, h), 0, 0);
    var b64 = cv.toDataURL('image/png').split(',')[1], d = tmpDir();
    var path = d.dir + d.sep + 'abs_live_' + L.stamp + '_' + (++L.n) + '.png';
    var wr = window.cep.fs.writeFile(path, b64, window.cep.encoding.Base64);
    if (!wr || wr.err !== 0) return null;
    return path;
  }
  function liveLabel(on) { var el = $('crLiveState'); if (!el) return; el.className = 'cr-livestate' + (on ? ' on' : ''); el.textContent = on ? 'مباشر على الصورة في Illustrator' : 'معاينة داخل اللوحة فقط'; }
  function dropFile(p) { if (p) try { window.cep.fs.deleteFile(p); } catch (e) {} }

  function sendFrame(rgba, w, h) {
    var L = state.live; if (!L || !L.on) return;
    if (L.inflight) { L.pending = true; return; }   // single-flight: newest edit is rendered when this one lands
    var path = writeFrame(rgba, w, h);
    if (!path) { stopLive('تعذّرت كتابة إطار المعاينة؛ استمر التعديل داخل اللوحة فقط.'); return; }
    L.inflight = true; L.pending = false;
    hostEval('AIArtboardStudio.liveFrame(' + jsq(path) + ')', function (ok, msg) {
      L.inflight = false; dropFile(L.last); L.last = path;
      if (!ok) { stopLive('توقفت المعاينة المباشرة: ' + msg + ' — يمكنك متابعة التعديل داخل اللوحة ثم «تطبيق».'); return; }
      if (L.pending) { L.pending = false; if (state.comparing && state.prevSrc) sendFrame(state.prevSrc.data, state.prevSrc.width, state.prevSrc.height); else window.setTimeout(schedule, 60); }
    });
  }

  function startLive(done) {
    state.live = null;
    var cb = $('crLive');
    if (!cb || !cb.checked || !state.prevSrc) { $('crWorkspace').classList.remove('live-on'); liveLabel(false); return done(false); }
    var L = { on: false, inflight: false, pending: false, n: 0, stamp: new Date().getTime(), last: null, cv: null };
    state.live = L;
    var path = writeFrame(state.prevSrc.data, state.prevSrc.width, state.prevSrc.height);
    if (!path) { state.live = null; return done(false); }
    hostEval('AIArtboardStudio.liveBegin(' + jsq(path) + ',' + JSON.stringify(state.info.bounds) + ')', function (ok, msg) {
      if (!ok) { dropFile(path); state.live = null; $('crWorkspace').classList.remove('live-on'); status('تعذّر بدء المعاينة على الصورة (' + msg + ')؛ سيتم التعديل داخل اللوحة.', 'error'); return done(false); }
      L.on = true; L.last = path; $('crWorkspace').classList.add('live-on'); liveLabel(true); done(true);
    });
  }

  /* leaves the session (restores the original image); cb(ok) */
  function endLive(cb) {
    var L = state.live; state.live = null; window.clearTimeout(state.settleTimer);
    $('crWorkspace').classList.remove('live-on'); liveLabel(false);
    if (!L || !L.on) { if (L) dropFile(L.last); return cb && cb(true); }
    hostEval('AIArtboardStudio.liveEnd()', function (ok, msg) {
      dropFile(L.last);
      if (ok && state.info) { try { var r = JSON.parse(msg); if (r && r.bounds && r.bounds.length === 4) state.info.bounds = r.bounds; } catch (e) {} }
      if (cb) cb(ok, msg);
    });
  }
  function stopLive(msg) { endLive(function () { status(msg, 'error'); }); }

  function drawHistogram(rgba) {
    var c = $('crHist'); if (!c) return;
    var g = c.getContext('2d'), W = c.width, H = c.height, hs = E.histogram(rgba), i;
    g.clearRect(0, 0, W, H);
    var max = 1;
    ['r', 'g', 'b', 'l'].forEach(function (k) { for (i = 2; i < 254; i++) if (hs[k][i] > max) max = hs[k][i]; });
    function plot(arr, color) {
      g.beginPath(); g.moveTo(0, H);
      for (var x = 0; x < 256; x++) g.lineTo(x * (W / 255), H - Math.min(1, arr[x] / max) * (H - 2));
      g.lineTo(W, H); g.closePath(); g.fillStyle = color; g.fill();
    }
    g.globalCompositeOperation = 'lighter';
    plot(hs.r, 'rgba(255,60,60,.55)'); plot(hs.g, 'rgba(60,255,90,.5)'); plot(hs.b, 'rgba(70,110,255,.6)');
    g.globalCompositeOperation = 'source-over';
  }

  function showOriginal(on) {
    if (!state.prevSrc) return;
    state.comparing = !!on;
    $('crBefore').classList.toggle('hidden', !on);
    if (on) {
      var g = $('crPreview').getContext('2d'); g.putImageData(state.prevSrc, 0, 0);
      sendFrame(state.prevSrc.data, state.prevSrc.width, state.prevSrc.height);
    } else { render(); schedule(); }
  }

  /* ---------- loading the selected image ---------- */
  function reset(clearImage) {
    state.params = E.defaults(); if (clearImage) { state.full = null; state.prevCtx = null; state.prevSrc = null; state.info = null; }
    syncUI(); var ps = $('crPreset'); if (ps) ps.value = 'none';
  }

  /* exports the selected image (host) and decodes it; cb(errMsg, info, ImageData) */
  function exportAndDecode(ppi, maxSide, cb) {
    hostEval('AIArtboardStudio.exportImageForEdit(' + ppi + ',' + maxSide + ')', function (ok, body) {
      if (!ok) return cb(body);
      var info; try { info = JSON.parse(body); } catch (e) { return cb('استجابة غير مفهومة من Illustrator.'); }
      var rd = window.cep.fs.readFile(info.path, window.cep.encoding.Base64);
      if (!rd || rd.err !== 0) return cb('تعذّرت قراءة الصورة المصدَّرة (رمز ' + (rd && rd.err) + ').');
      var img = new Image();
      img.onload = function () {
        var id;
        try { var w = img.naturalWidth, h = img.naturalHeight, cv = document.createElement('canvas'); cv.width = w; cv.height = h; var g = cv.getContext('2d'); g.drawImage(img, 0, 0); id = g.getImageData(0, 0, w, h); }
        catch (e2) { return cb('تعذّر فتح الصورة: ' + (e2.message || e2)); }
        try { window.cep.fs.deleteFile(info.path); } catch (e3) {}
        cb(null, info, id);
      };
      img.onerror = function () { cb('تعذّر فك ترميز الصورة المصدَّرة.'); };
      img.src = 'data:image/png;base64,' + rd.data;
    });
  }

  function loadImage() {
    if (state.busy) return;
    if (window.ABSSession.owner && window.ABSSession.owner !== 'cr') { status('أنهِ أو ألغِ جلسة «تحويل الصورة» أولًا ثم حمّل الصورة هنا.', 'error'); return; }
    if (state.live) { endLive(function () { loadImage(); }); return; }
    if (!fsOk()) { status('هذه الميزة تعمل داخل Illustrator فقط (لا يتوفر الوصول إلى الملفات المؤقتة).', 'error'); return; }
    var ppi = parseFloat($('crPpi').value); if (!isFinite(ppi) || ppi < 36 || ppi > 600) { status('أدخل دقة بين 36 و600 ppi.', 'error'); return; }
    state.busy = true; $('crLoad').disabled = true; status('جارٍ تصدير الصورة المحددة من Illustrator…');
    ABSBusy.show('جارٍ تحميل الصورة من Illustrator…');
    exportAndDecode(ppi, PROXY_MAX, function (err, info, id) {
      if (err) return fail(err);
      try {
        var w = id.width, h = id.height;
        state.full = id;
        var f = Math.min(1, PREVIEW_MAX / Math.max(w, h)), pw = Math.max(1, Math.round(w * f)), ph = Math.max(1, Math.round(h * f));
        var cv = document.createElement('canvas'); cv.width = w; cv.height = h; cv.getContext('2d').putImageData(id, 0, 0);
        var pc = document.createElement('canvas'); pc.width = pw; pc.height = ph;
        var pg = pc.getContext('2d'); pg.imageSmoothingQuality = 'high'; pg.drawImage(cv, 0, 0, pw, ph);
        state.prevSrc = pg.getImageData(0, 0, pw, ph);
        state.prevCtx = E.createContext(state.prevSrc, { fullMax: Math.max(w, h) });
        state.info = info; var vis = $('crPreview'); vis.width = pw; vis.height = ph;
        $('crPpiInfo').textContent = info.name + ' — معاينة ' + w + '×' + h + ' بكسل (الدقة الكاملة عند التطبيق)';
        state.hiCtx = null; state.comparing = false;
        var ar = (info.bounds[2] - info.bounds[0]) / Math.max(1e-6, info.bounds[1] - info.bounds[3]);
        if (Math.abs(ar - w / h) / ar > 0.03) info.aspectWarn = true;
        reset(false); $('crWorkspace').classList.remove('hidden'); window.ABSSession.owner = 'cr'; render();
      } catch (err2) { return fail('تعذّر فتح الصورة: ' + (err2.message || err2)); }
      startLive(function (live) {
        ABSBusy.hide(); state.busy = false; $('crLoad').disabled = false;
        status(live ? 'المعاينة المباشرة تعمل: حرّك أي شريط وشاهد التغيير على الصورة داخل Illustrator. اضغط «تطبيق» لتثبيت النتيجة.'
                    : 'تم تحميل الصورة. عدّل الإعدادات ثم اضغط «تطبيق».', 'success');
        if (info.aspectWarn) status($('crStatus').textContent + ' (تنبيه: نسبة أبعاد الصورة المصدَّرة تختلف قليلًا عن الأصل.)', 'success');
      });
    });
    function fail(msg) { ABSBusy.hide(); state.busy = false; $('crLoad').disabled = false; status(msg, 'error'); }
  }

  /* ---------- applying the result back to Illustrator ---------- */
  function applyToIllustrator() {
    if (state.busy || !state.full || !state.info) return;
    if (E.isNeutral(state.params)) { status('لم تُجرِ أي تعديل بعد.', 'error'); return; }
    var mode = $('crMode').value;
    if (mode === 'replace' && !window.confirm('سيُستبدل الأصل بنسخة معدّلة مضمّنة في الملف (لا يتغير الملف الأصلي على القرص). هل تريد المتابعة؟')) return;
    state.busy = true; $('crApply').disabled = true; $('crLoad').disabled = true; $('crCancel').disabled = true;
    status('جارٍ تطبيق التعديلات بالدقة الكاملة… قد تستغرق بضع ثوانٍ للصور الكبيرة.');
    ABSBusy.show('جارٍ تطبيق التعديلات على الصورة…');
    var hadLive = !!state.live, ppi = parseFloat($('crPpi').value) || 300, params = JSON.parse(JSON.stringify(state.params)), outPath = state.info.outPath;
    endLive(function () {
      // original is visible and selected again: fetch it at full resolution only now
      status('جارٍ قراءة الصورة بالدقة الكاملة…');
      window.setTimeout(function () {
        exportAndDecode(ppi, 4096, function (err, info, full) {
          if (err) return finish(false, err);
          state.info.bounds = info.bounds; status('جارٍ تطبيق التعديلات بالدقة الكاملة…');
          window.setTimeout(function () { run(full, params); }, 30);
        });
      }, 30);
    });
    function run(full, params) {
      try {
        var ctx = E.createContext(full, { noCache: true, fullMax: Math.max(full.width, full.height) });
        var out = E.process(ctx, params);
        var cv = document.createElement('canvas'); cv.width = full.width; cv.height = full.height;
        cv.getContext('2d').putImageData(new ImageData(out, full.width, full.height), 0, 0);
        var b64 = cv.toDataURL('image/png').split(',')[1];
        var wr = window.cep.fs.writeFile(outPath, b64, window.cep.encoding.Base64);
        if (!wr || wr.err !== 0) throw new Error('تعذّرت كتابة الملف المؤقت (رمز ' + (wr && wr.err) + ').');
      } catch (e) { return finish(false, 'فشلت المعالجة: ' + (e.message || e)); }
      hostEval('AIArtboardStudio.applyEditedImage(' + jsq(outPath) + ',' + JSON.stringify(state.info.bounds) + ',' + jsq(mode) + ')', function (ok, msg) {
        try { window.cep.fs.deleteFile(outPath); } catch (e3) {}
        finish(ok, msg);
      });
    }
    function finish(ok, msg) {
      ABSBusy.hide();
      state.busy = false; $('crApply').disabled = false; $('crLoad').disabled = false; $('crCancel').disabled = false;
      if (ok) { state.full = null; state.prevCtx = null; state.prevSrc = null; state.info = null; state.hiCtx = null; $('crWorkspace').classList.add('hidden'); status(msg, 'success'); }
      else if (hadLive) { status(msg + ' — أُعيدت المعاينة المباشرة.', 'error'); startLive(function () { schedule(); }); }
      else status(msg, 'error');
    }
  }

  /* ---------- wiring ---------- */
  function init() {
    if (!$('panel-cr') || $('panel-cr').getAttribute('data-ready')) return;
    $('panel-cr').setAttribute('data-ready', '1');
    buildUI();
    var sel = $('crPreset');
    E.presets.forEach(function (p) { var o = document.createElement('option'); o.value = p.id; o.textContent = p.name; sel.appendChild(o); });
    sel.addEventListener('change', function () {
      var p = E.presets.filter(function (x) { return x.id === sel.value; })[0];
      state.params = E.normalize(p ? p.params : {}); syncUI(); schedule();
    });
    $('crAuto').addEventListener('click', function () {
      if (!state.prevSrc) return; state.params = E.normalize(E.autoParams(state.prevSrc)); syncUI(); sel.value = 'none'; schedule();
    });
    $('crReset').addEventListener('click', function () { reset(false); schedule(); });
    ['crCompare', 'crCompare2'].forEach(function (id) { var cmp = $(id);
      ['mousedown', 'touchstart'].forEach(function (ev) { cmp.addEventListener(ev, function (e) { e.preventDefault(); showOriginal(true); }); });
      ['mouseup', 'mouseleave', 'touchend', 'touchcancel'].forEach(function (ev) { cmp.addEventListener(ev, function () { showOriginal(false); }); }); });
    $('crLoad').addEventListener('click', loadImage);
    try { new MutationObserver(function () { var h = $('crWorkspace').classList.contains('hidden'); $('crCancel').classList.toggle('hidden', h); if (h && window.ABSSession.owner === 'cr') window.ABSSession.owner = null; }).observe($('crWorkspace'), { attributes: true, attributeFilter: ['class'] }); } catch (e) {}
    $('crCancel').addEventListener('click', function () {
      if (state.busy) return;
      endLive(function () { state.full = null; state.prevCtx = null; state.prevSrc = null; state.info = null; state.hiCtx = null; $('crWorkspace').classList.add('hidden'); status('أُلغي التعديل وأُعيدت الصورة الأصلية كما كانت.', 'success'); });
    });
    $('crLive').addEventListener('change', function () {
      if (!state.prevSrc || state.busy) return;
      if (this.checked) startLive(function (ok) { if (ok) { schedule(); status('المعاينة المباشرة تعمل.', 'success'); } });
      else endLive(function () { status('أُوقفت المعاينة على الصورة؛ المعاينة داخل اللوحة فقط.', 'success'); });
    });
    window.addEventListener('beforeunload', function () { if (state.live && state.live.on) { try { window.__adobe_cep__.evalScript('AIArtboardStudio.liveEnd()'); } catch (e) {} } });
    $('crApply').addEventListener('click', applyToIllustrator);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
  window.ABSCRShared = { hostEval: hostEval, jsq: jsq, exportAndDecode: exportAndDecode, fsOk: fsOk };
  window.ABSCameraRawUI = { _state: state, _render: render, _settle: settle, loadImage: loadImage, apply: applyToIllustrator, cancel: function () { $('crCancel').click(); } };
}());
