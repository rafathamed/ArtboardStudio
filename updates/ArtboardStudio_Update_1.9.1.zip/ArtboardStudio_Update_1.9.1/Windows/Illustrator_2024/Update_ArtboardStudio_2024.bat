@echo off
setlocal EnableExtensions
set "YEAR=2024"
set "EXTROOT=%APPDATA%\Adobe\CEP\extensions"
set "DEST=%EXTROOT%\com.rafat.artboardstudio.ai%YEAR%"
set "SOURCE=%~dp0ArtboardStudio_%YEAR%"
set "BACKUPROOT=%LOCALAPPDATA%\ArtboardStudio\Backups"
for /f %%I in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss"') do set "STAMP=%%I"
set "BACKUP=%BACKUPROOT%\ArtboardStudio_%YEAR%_%STAMP%"
set "STAGE=%TEMP%\ArtboardStudio_%YEAR%_Update_%RANDOM%"

echo ==================================================
echo  Artboard Studio 1.9.1 - Update for Illustrator %YEAR%
echo ==================================================

tasklist /FI "IMAGENAME eq Illustrator.exe" 2>NUL | find /I "Illustrator.exe" >NUL
if not errorlevel 1 (
  echo.
  echo Please close Adobe Illustrator completely, then run this updater again.
  pause
  exit /b 2
)

if not exist "%SOURCE%\CSXS\manifest.xml" (
  echo ERROR: Update source is missing or incomplete.
  pause
  exit /b 3
)

if not exist "%EXTROOT%" mkdir "%EXTROOT%" >nul 2>&1
if not exist "%BACKUPROOT%" mkdir "%BACKUPROOT%" >nul 2>&1
if exist "%STAGE%" rmdir /s /q "%STAGE%"
mkdir "%STAGE%" >nul 2>&1
xcopy "%SOURCE%\*" "%STAGE%\" /E /I /H /Y >nul
if errorlevel 1 (
  echo ERROR: Could not prepare the update files.
  rmdir /s /q "%STAGE%" >nul 2>&1
  pause
  exit /b 4
)

if exist "%DEST%\CSXS\manifest.xml" (
  echo Creating backup: "%BACKUP%"
  xcopy "%DEST%\*" "%BACKUP%\" /E /I /H /Y >nul
  if errorlevel 1 (
    echo ERROR: Backup failed. Existing installation was not changed.
    rmdir /s /q "%STAGE%" >nul 2>&1
    pause
    exit /b 5
  )
)

if exist "%DEST%" rmdir /s /q "%DEST%"
mkdir "%DEST%" >nul 2>&1
xcopy "%STAGE%\*" "%DEST%\" /E /I /H /Y >nul
if errorlevel 1 goto ROLLBACK

if not exist "%DEST%\CSXS\manifest.xml" goto ROLLBACK
if not exist "%DEST%\integrity.js" goto ROLLBACK
if not exist "%DEST%\index.html" goto ROLLBACK
if not exist "%DEST%\version.js" goto ROLLBACK
findstr /C:"ARTBOARD_STUDIO_VERSION = '1.9.1'" "%DEST%\version.js" >nul
if errorlevel 1 goto ROLLBACK

rmdir /s /q "%STAGE%" >nul 2>&1
echo.
echo Update completed successfully.
if exist "%BACKUP%\CSXS\manifest.xml" echo Previous files are backed up at: "%BACKUP%"
echo Restart Illustrator and open Artboard Studio.
echo License information is not intentionally deleted by this updater.
pause
exit /b 0

:ROLLBACK
echo.
echo ERROR: New files did not pass the basic installation checks.
rmdir /s /q "%DEST%" >nul 2>&1
if exist "%BACKUP%\CSXS\manifest.xml" (
  mkdir "%DEST%" >nul 2>&1
  xcopy "%BACKUP%\*" "%DEST%\" /E /I /H /Y >nul
  if errorlevel 1 echo WARNING: Automatic rollback failed. Restore manually from "%BACKUP%".
  if not errorlevel 1 echo Previous installation restored.
) else (
  echo No previous installation was found to restore.
)
rmdir /s /q "%STAGE%" >nul 2>&1
pause
exit /b 6
