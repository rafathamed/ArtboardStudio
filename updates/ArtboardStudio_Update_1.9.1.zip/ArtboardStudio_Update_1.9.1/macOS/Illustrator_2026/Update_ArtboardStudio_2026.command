#!/bin/bash
set -u
YEAR="2026"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SOURCE="$SCRIPT_DIR/ArtboardStudio_${YEAR}"
EXTROOT="$HOME/Library/Application Support/Adobe/CEP/extensions"
DEST="$EXTROOT/com.rafat.artboardstudio.ai${YEAR}"
BACKUPROOT="$HOME/Library/Application Support/ArtboardStudio/Backups"
STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP="$BACKUPROOT/ArtboardStudio_${YEAR}_${STAMP}"
STAGE="$(mktemp -d "${TMPDIR:-/tmp}/ArtboardStudio_${YEAR}_update.XXXXXX")"

cleanup() { rm -rf "$STAGE"; }
trap cleanup EXIT

echo "=================================================="
echo " Artboard Studio 1.9.1 - Illustrator ${YEAR}"
echo "=================================================="

if pgrep -f "Adobe Illustrator" >/dev/null 2>&1; then
  echo "Please quit Adobe Illustrator completely, then run this updater again."
  read -r -p "Press Enter to close..."
  exit 2
fi

if [[ ! -f "$SOURCE/CSXS/manifest.xml" ]]; then
  echo "ERROR: Update source is missing or incomplete."
  read -r -p "Press Enter to close..."
  exit 3
fi

mkdir -p "$EXTROOT" "$BACKUPROOT"
ditto "$SOURCE" "$STAGE/extension" || { echo "ERROR: Could not stage update files."; read -r -p "Press Enter to close..."; exit 4; }

if [[ -f "$DEST/CSXS/manifest.xml" ]]; then
  echo "Creating backup: $BACKUP"
  ditto "$DEST" "$BACKUP" || { echo "ERROR: Backup failed. Existing installation was not changed."; read -r -p "Press Enter to close..."; exit 5; }
fi

rm -rf "$DEST"
if ! ditto "$STAGE/extension" "$DEST"; then
  echo "ERROR: Copy failed. Restoring previous installation..."
  rm -rf "$DEST"
  if [[ -f "$BACKUP/CSXS/manifest.xml" ]]; then
    ditto "$BACKUP" "$DEST" || echo "WARNING: Automatic rollback failed. Restore manually from: $BACKUP"
  fi
  read -r -p "Press Enter to close..."
  exit 6
fi

if [[ ! -f "$DEST/CSXS/manifest.xml" || ! -f "$DEST/integrity.js" || ! -f "$DEST/index.html" || ! -f "$DEST/version.js" ]] || ! grep -q "ARTBOARD_STUDIO_VERSION = '1.9.1'" "$DEST/version.js"; then
  echo "ERROR: Basic installation checks failed. Restoring previous installation..."
  rm -rf "$DEST"
  if [[ -f "$BACKUP/CSXS/manifest.xml" ]]; then
    ditto "$BACKUP" "$DEST" || echo "WARNING: Automatic rollback failed. Restore manually from: $BACKUP"
  fi
  read -r -p "Press Enter to close..."
  exit 7
fi

echo ""
echo "Update completed successfully."
[[ -f "$BACKUP/CSXS/manifest.xml" ]] && echo "Previous files backed up at: $BACKUP"
echo "Restart Illustrator and open Artboard Studio."
echo "License information is not intentionally deleted by this updater."
read -r -p "Press Enter to close..."
exit 0
