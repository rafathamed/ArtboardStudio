(function () {
  'use strict';
  var host = null;
  function getHostApi() {
    if (window.__adobe_cep__ && typeof window.__adobe_cep__.evalScript === 'function') host = window.__adobe_cep__;
    return host;
  }
  var $ = function (id) { return document.getElementById(id); };
  var currentKind = 'phone';
  var busy = false;
  var initialized = false;

  function setStatus(message, type) {
    var area = $('statusArea');
    if (!area) return;
    area.className = 'status-area' + (type ? ' ' + type : '');
    $('statusText').textContent = message || '';
  }

  function hostCall(expression, callback, attempt) {
    attempt = attempt || 0;
    var api = getHostApi();
    if (!api || typeof api.evalScript !== 'function') {
      if (attempt < 8) {
        window.setTimeout(function () { hostCall(expression, callback, attempt + 1); }, 250);
        return;
      }
      setStatus('لوحة Illustrator لم تكتمل تهيئتها بعد. جرّب تحديث معلومات المستند بعد لحظات.', 'error');
      if (callback) callback('ERR|تعذّر الاتصال بالتطبيق');
      return;
    }
    try {
      api.evalScript(expression, function (result) {
        result = String(result || '');
        var ok = result.indexOf('OK|') === 0;
        var msg = result.indexOf('|') >= 0 ? result.substring(result.indexOf('|') + 1) : result;
        setStatus(msg, ok ? 'success' : 'error');
        if (callback) callback(result);
      });
    } catch (e) {
      setStatus('تعذّر تنفيذ أمر Illustrator: ' + (e.message || e), 'error');
      if (callback) callback('ERR|' + (e.message || e));
    }
  }

  function setBusy(value, button) {
    busy = value;
    if (button) button.disabled = value;
  }

  function refreshInfo() {
    if (!window.ArtboardStudioLicensed) return;
    if (getHostApi()) {
      $('hostDot').className = 'host-dot connected';
      $('hostStatus').textContent = 'متصل بـ Illustrator';
    } else {
      $('hostDot').className = 'host-dot';
      $('hostStatus').textContent = 'جاري الاتصال بـ Illustrator…';
    }
    hostCall('AIArtboardStudio.getDocumentInfo()');
  }

  function selectedIncludeHidden() { return $('includeHidden').checked ? 'true' : 'false'; }
  function selectedScope(id) { return $(id).value === 'selected' ? 'selected' : 'all'; }
  function nextFrame(callback) { if (window.requestAnimationFrame) window.requestAnimationFrame(callback); else window.setTimeout(callback, 16); }

  function runDestructiveCrop() {
    if (busy) return;
    var include = selectedIncludeHidden();
    var scope = selectedScope('cropScope');
    var scopeLabel = scope === 'selected' ? 'العنصر أو العناصر المحددة فقط' : 'جميع العناصر داخل المشروع';
    var message = 'سيتم تنفيذ Pathfinder Crop على: ' + scopeLabel + ' في حدود لوحة الرسم النشطة. قد يؤدي ذلك إلى دمج المسارات أو إزالة الحدود والتأثيرات، ولا يمكن ضمان إمكانية التراجع عن كل تغيير.\n\nهل حفظت نسخة من الملف وتريد المتابعة؟';
    if (!window.confirm(message)) return;
    setBusy(true, $('cropBtn'));
    hostCall('AIArtboardStudio.cropAllLayers(' + include + ',' + JSON.stringify(scope) + ')', function () { setBusy(false, $('cropBtn')); });
  }

  function runMask() {
    if (busy) return;
    setBusy(true, $('maskBtn'));
    var scope = selectedScope('maskScope');
    hostCall('AIArtboardStudio.maskAllLayers(' + selectedIncludeHidden() + ',' + JSON.stringify(scope) + ')', function () { setBusy(false, $('maskBtn')); });
  }

  function addShape() {
    if (busy) return;
    var value = parseFloat($('strokeWidth').value || '0');
    if (!isFinite(value) || value < 0 || value > 20) { setStatus('أدخل سُمك حد بين 0 و20 pt.', 'error'); return; }
    var color = $('shapeColor').value || '#919BAA';
    var style = $('shapeStyle').value || 'fill';
    setBusy(true, $('shapeBtn'));
    hostCall('AIArtboardStudio.addArtboardShape(' + value + ',' + JSON.stringify(color) + ',' + JSON.stringify(style) + ')', function () { setBusy(false, $('shapeBtn')); });
  }

  function runImageMask() {
    if (busy) return;
    setBusy(true, $('maskImagesBtn'));
    hostCall('AIArtboardStudio.maskImagesOnly(' + selectedIncludeHidden() + ')', function () { setBusy(false, $('maskImagesBtn')); });
  }

  function runImageCrop() {
    if (busy) return;
    var scope = selectedScope('imgCropScope');
    var ppi = parseFloat($('imgCropPpi').value || '300');
    if (!isFinite(ppi) || ppi < 36 || ppi > 2400) { setStatus('أدخل دقة بين 36 و2400 ppi.', 'error'); return; }
    var label = scope === 'selected' ? 'الصور المحددة فقط' : 'جميع الصور داخل المشروع';
    var message = 'سيتم قص ' + label + ' فعليًا بحدود لوحة الرسم النشطة وحذف البكسلات خارجها نهائيًا. ستُضمَّن الصور المرتبطة وتُعالج بدقة ' + ppi + ' ppi.\n\nهل حفظت نسخة من الملف وتريد المتابعة؟';
    if (!window.confirm(message)) return;
    setBusy(true, $('cropImagesBtn'));
    hostCall('AIArtboardStudio.cropImagesToArtboard(' + selectedIncludeHidden() + ',' + JSON.stringify(scope) + ',' + ppi + ')', function () { setBusy(false, $('cropImagesBtn')); });
  }

  function switchTab(name) {
    var tabs = document.querySelectorAll('.tab');
    for (var i = 0; i < tabs.length; i++) tabs[i].classList.toggle('active', tabs[i].getAttribute('data-tab') === name);
    $('panel-artboard').classList.toggle('active', name === 'artboard');
    $('panel-qr').classList.toggle('active', name === 'qr');
    if ($('panel-cr')) $('panel-cr').classList.toggle('active', name === 'cr');
    if ($('panel-xf')) $('panel-xf').classList.toggle('active', name === 'xf');
  }

  function switchQrKind(kind) {
    currentKind = kind;
    var kinds = document.querySelectorAll('.qr-kind');
    for (var i = 0; i < kinds.length; i++) kinds[i].classList.toggle('active', kinds[i].getAttribute('data-kind') === kind);
    $('phoneForm').classList.toggle('hidden', kind === 'url');
    $('urlForm').classList.toggle('hidden', kind !== 'url');
    $('generatePhone').classList.toggle('hidden', kind !== 'phone');
    $('generateWhatsapp').classList.toggle('hidden', kind !== 'whatsapp');
    $('generateUrl').classList.toggle('hidden', kind !== 'url');
    $('phoneHint').textContent = kind === 'whatsapp'
      ? 'سيُنشأ رابط wa.me لفتح محادثة واتساب مباشرة. اكتب الرقم دون صفر البداية المحلي.'
      : 'سيُنشأ رابط tel: لفتح تطبيق الاتصال. اكتب الرقم دون صفر البداية المحلي.';
  }

  function toWesternDigits(value) {
    return String(value || '').replace(/[٠-٩]/g, function (d) { return String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)); })
      .replace(/[۰-۹]/g, function (d) { return String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)); });
  }

  function phoneParts() {
    var codeRaw = toWesternDigits($('countryCode').value).trim();
    var numberRaw = toWesternDigits($('phoneValue').value).trim();
    var code = codeRaw.replace(/[\s()-]/g, '');
    var number = numberRaw.replace(/[\s().-]/g, '');
    if (!/^\+[1-9][0-9]{0,3}$/.test(code)) throw new Error('أدخل مفتاح دولة صحيحًا يبدأ بعلامة +، مثل +20 أو +966.');
    if (!/^[0-9]{6,14}$/.test(number)) throw new Error('أدخل رقم جوال صحيحًا من 6 إلى 14 رقمًا دون مفتاح الدولة.');
    // Remove a national trunk zero so that the international number is canonical.
    number = number.replace(/^0+/, '');
    var countryDigits = code.substring(1);
    if ((countryDigits + number).length < 7 || (countryDigits + number).length > 15) throw new Error('طول الرقم الدولي غير صحيح. راجع مفتاح الدولة ورقم الجوال.');
    return { e164: '+' + countryDigits + number, digits: countryDigits + number };
  }

  function makePayload() {
    if (currentKind === 'phone') {
      var phone = phoneParts();
      return 'tel:' + phone.e164;
    }
    if (currentKind === 'whatsapp') {
      var whatsapp = phoneParts();
      return 'https://wa.me/' + whatsapp.digits;
    }
    var value = $('urlValue').value.trim();
    if (!value) throw new Error('أدخل رابط URL أولًا.');
    if (!/^https?:\/\//i.test(value)) value = 'https://' + value;
    if (!/^https?:\/\/[^\s.]+(?:\.[^\s.]+)+(?:[\/:?#][^\s]*)?$/i.test(value)) throw new Error('الرابط غير صالح. أدخل نطاقًا صحيحًا مثل https://example.com');
    return value;
  }

  function createQR() {
    if (busy) return;
    var button = currentKind === 'phone' ? $('generatePhone') : (currentKind === 'whatsapp' ? $('generateWhatsapp') : $('generateUrl'));
    var payload, size;
    try {
      payload = makePayload();
      size = parseFloat($('qrSize').value || '35');
      if (!isFinite(size) || size < 10 || size > 500) throw new Error('اختر حجمًا بين 10 و500 mm.');
      if (!window.ArtboardStudioQR) throw new Error('مكتبة QR غير محملة.');
      var qr = window.ArtboardStudioQR.encode(payload);
      // Create native Illustrator vector rectangles. This avoids Illustrator's SVG placed-file parser.
      setBusy(true, button);
      setStatus('جاري إنشاء رمز QR كعناصر متجهية أصلية داخل Illustrator…', '');
      hostCall('AIArtboardStudio.placeQRMatrix(' + JSON.stringify(qr.matrix) + ',' + size + ')', function () {
        setBusy(false, button);
      });
    } catch (e) {
      setBusy(false, button);
      setStatus(e.message || String(e), 'error');
    }
  }

  function init() {
    if (initialized) return;
    initialized = true;
    var tabs = document.querySelectorAll('.tab');
    for (var i = 0; i < tabs.length; i++) tabs[i].addEventListener('click', function () { switchTab(this.getAttribute('data-tab')); });
    var kinds = document.querySelectorAll('.qr-kind');
    for (i = 0; i < kinds.length; i++) kinds[i].addEventListener('click', function () { switchQrKind(this.getAttribute('data-kind')); });
    $('refreshBtn').addEventListener('click', refreshInfo);
    $('cropBtn').addEventListener('click', runDestructiveCrop);
    $('maskBtn').addEventListener('click', runMask);
    $('maskImagesBtn').addEventListener('click', runImageMask);
    $('cropImagesBtn').addEventListener('click', runImageCrop);
    $('shapeBtn').addEventListener('click', addShape);
    $('generatePhone').addEventListener('click', createQR);
    $('generateWhatsapp').addEventListener('click', createQR);
    $('generateUrl').addEventListener('click', createQR);

    function bindExternalLink(id) {
      var link = $(id);
      if (!link) return;
      link.addEventListener('click', function (event) {
        event.preventDefault();
        var targetUrl = this.getAttribute('href');
        try {
          if (window.cep && window.cep.util && typeof window.cep.util.openURLInDefaultBrowser === 'function') {
            window.cep.util.openURLInDefaultBrowser(targetUrl);
            return;
          }
        } catch (openError) {}
        window.open(targetUrl, '_blank');
      });
    }
    bindExternalLink('facebookLink');
    bindExternalLink('footerWhatsapp');
    bindExternalLink('developerContact');
    bindExternalLink('websiteLink');
    $('buildTag').textContent = 'BUILD ' + (window.ARTBOARD_STUDIO_VERSION || window.ARTBOARD_STUDIO_BUILD || '1.4.0');
    window.ArtboardStudioRefresh = refreshInfo;
    // Re-acquire CEP after the panel is painted; CEP may inject its bridge slightly after DOM ready.
    window.setTimeout(function () { if (window.ArtboardStudioLicensed) refreshInfo(); }, 350);
    window.setTimeout(function () { if (window.ArtboardStudioLicensed && !getHostApi()) refreshInfo(); }, 1100);
    window.addEventListener('focus', function () { if (window.ArtboardStudioLicensed) window.setTimeout(refreshInfo, 180); });
    window.addEventListener('pageshow', function () { ensureVisibleSurface(); if (window.ArtboardStudioLicensed) window.setTimeout(refreshInfo, 250); });
    document.addEventListener('visibilitychange', function () { if (!document.hidden) { ensureVisibleSurface(); if (window.ArtboardStudioLicensed) window.setTimeout(refreshInfo, 250); } });
  }

  function hideBootSplash() { var splash = $('bootSplash'); if (splash) splash.classList.add('hidden'); }

  function ensureVisibleSurface() {
    var gate = $('licenseGate'), app = $('appRoot');
    if (window.ArtboardStudioLicensed) {
      if (gate) gate.classList.add('hidden');
      if (app) app.classList.remove('hidden');
    } else {
      if (app) app.classList.add('hidden');
      if (gate) gate.classList.remove('hidden');
    }
    hideBootSplash();
  }

  function startInit() {
    // Give CEP/Chromium a paint cycle, then reveal a deterministic startup surface.
    nextFrame(function () {
      nextFrame(function () {
        ensureVisibleSurface();
        init();
      });
    });
  }

  if (document.readyState === 'complete') startInit();
  else {
    window.addEventListener('load', startInit);
    document.addEventListener('DOMContentLoaded', function () { window.setTimeout(startInit, 80); });
    // Fallback for CEP builds that delay load on first panel creation.
    window.setTimeout(startInit, 700);
    window.setTimeout(function () { ensureVisibleSurface(); init(); }, 1800);
  }
}());
